
import boto3
from botocore.exceptions import ClientError
import pprint
import time
import textwrap
import re
import json

kendra = boto3.client("kendra")
#kendra = boto3.client("kendra", aws_access_key_id='AKIAWXFZ2AJ3IQDOYV3B ',aws_secret_access_key='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','ap-southeast1')
index_role_arn = "arn:aws:iam::462098662006:role/service-role/AmazonKendra-us-east-1-kendra-production-role"

co_index_id = 'dda38fc1-1c69-4bb3-a451-9f330de5f77e'



# searching from particular user

def lambda_handler(event,context):
    #user_data =  event["queryStringparameters"]["para"]
    user_data=event["queryStringParameters"]["user_name"]
    testing_data=event["queryStringParameters"]["se_para"]
    #print(user_data)
    
    search_answers = ''
    #query = " what is icai?"
    
    
    response=kendra.query(
       QueryText = user_data,
       IndexId = '8e79eb53-bc50-4ab2-8c89-caa41f046182',
      
       
     
       
       AttributeFilter = {
            "OrAllFilters": [
                {
                    "EqualsTo": {
                        "Key": "_user_id",
                        "Value": {
                            "StringValue": testing_data
                        }
                     }
                }
                ]
        }
        
        
      
        
        
        
        )
    
       
      
    search_results=[]
    search_links=[]
    search_titles=[]
    search_pages=[]
    page_numbers=[]
    for query_result in response['ResultItems']:  
      
        #print(query_result['DocumentExcerpt']['Text'])
        #print(query_result['DocumentId'])
        wrapper = textwrap.TextWrapper(width=100)
  
        search_results.append(wrapper.wrap(text=query_result['DocumentExcerpt']['Text']))
       
        search_links.append(query_result['DocumentId'])
        search_titles.append(query_result['DocumentTitle']['Text'])
        page_numbers.append(query_result['DocumentAttributes'][1]['Value']['LongValue'])
        #search_Pages.append(query_result['DocumentAttributes'][1]['Value']['LongValue'])
        #search_Pages.append(query_result['DocumentAttributes'][1]['Value']['LongValue'])
        
        
    
    
    api_data={}
    api_response={}
    api_response['statusCode'] = 200
    api_response['header']={}
    api_response['header']['Content-Type'] = 'application/json'
    #api_response['user_data '] =[]
    api_response['user_data'] ={'Content': search_results,'Links': search_links,'Doctitle':search_titles,'page_numbers':page_numbers}
    
    
    
    
    
    #message = {'name':user_data}
    return {
        "statusCode": 200, 
        "body":   json.dumps(api_response)
        
    }
    

    