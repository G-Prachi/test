import flask
from flask import render_template
import requests
import json
import js2py
import boto3
from flask import Flask ,request
 
application = Flask(__name__ ,static_folder="app/static",template_folder="app/static")


s3=boto3.resource('s3',aws_access_key_id='AKIAWXFZ2AJ3FN6WZF66' , aws_secret_access_key='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')
links_masking={}
universal_drop_down_list=[]
user_data=[]





@application.route("/icaisearch")
def icaisearch():
   return  render_template("webpage.html")



@application.route('/link_data',methods=['GET','POST'])
def link_data():
    data=request.form.get("basic")
    file_to_download=links_masking[data]
    my_bucket = s3.Bucket('caartha')

    my_bucket.download_file(file_to_download, 'app/static/'+data)

    #print("donwloaded")

    
    

   
    #print(links_masking['1525-1526 ICAI in Media.pdf'])
    #print(links_masking[data])
    #var='84 Pathshala to Internationally benchmarked education.pdf'
    var=data
    
    # boto code starts

    # boto code to download data filr from s3
    return flask.send_file('app/static/'+var, attachment_filename=data)







@application.route('/another_grab_data',methods=['GET'])
def another_grab_data():
    global  user_data

    
    

    
    
    
    
    

    
    
    
    
    drop_down_reflected_data = []
    
    temp_list = []
    drop_down_data=request.args.get("cars")
    
    
    query=request.args.get("user_data")
    print(type(query))
    if len(query) == 0:
        
        
        query  = user_data.pop()
    
    
    user_data = [query]
    print(user_data)
       
    
  

    
    
         
   
    
    


    #query =request.form['user_data']
   

    
   
    chooose_dict={"ALL":"notall","JOURNALS":"pulkit","STUDENT PUBLICATIONS":"testing","ALL (3 Sub-Categories)":"membertesting","ACCOUNTING STANDARDS":"membertesting1","EAC VOLUMES":"membertesting2","OPTIMIZED JOURNALS":"restricted"}

    print(drop_down_data)
    #print(universal_drop_down_list)
    selected_data = universal_drop_down_list[int(drop_down_data)]
    #chooose_dict[selected_data]
    #return  chooose_dict[selected_data]
    

    
    #print(universal_drop_down_list)

    var = chooose_dict[selected_data]
    
    member_list =['ALL (3 Sub-Categories)','ACCOUNTING STANDARDS','EAC VOLUMES']
    if selected_data in member_list:
        #member_list.remove(selected_data)

        for items in  member_list:
            universal_drop_down_list.remove(items)
        member_list.remove(selected_data)
        drop_down_reflected_data.insert(0,selected_data)
        #drop_down_reflected_data.insert(1,member_list)
        drop_down_reflected_data.extend(universal_drop_down_list)
        temp_list.extend(drop_down_reflected_data)
        temp_list.extend(member_list)
        print("temp list")
        print(temp_list)
        #variable = universal_drop_down_list[int(drop_down_data)]
        #return variable
    

    
        #var = chooose_dict[variable]
        #print(temp_list)
        universal_drop_down_list.clear()
        #print(universal_drop_down_list)
        universal_drop_down_list.extend(temp_list)
        print("UNIVERSAL LIST")
        print(universal_drop_down_list)
        
       
        
        #print(universal_drop_down_list)
        #print(universal_drop_down_list)
        #variable = universal_drop_down_list[int(drop_down_data)]
        #var = chooose_dict[variable]

    
    else:
     
        
    
    #print(universal_drop_down_list)
       
        for items in member_list:
            universal_drop_down_list.remove(items)
        drop_down_reflected_data.insert(0,selected_data)
        universal_drop_down_list.remove(selected_data)
        drop_down_reflected_data.extend(universal_drop_down_list)
        temp_list.extend(drop_down_reflected_data)
        temp_list.extend(member_list)
        print("temp list")
        print(temp_list)
        universal_drop_down_list.clear()
        #print(universal_drop_down_list)
        universal_drop_down_list.extend(temp_list)
        print("jdvjsdfj list")
        print(universal_drop_down_list)
        print(drop_down_reflected_data)
        print(member_list)

        #print("uululululululu")
        #universal_drop_down_list.extend(drop_down_reflected_data)
        #universal_drop_down_list.extend(member_list)
        #print(universal_drop_down_list)


        
    
    
    user_query= ''
    #query = "what ic CA?"
    main_query = "https://eolrvhhdn1.execute-api.ap-southeast-1.amazonaws.com/testing-stage/kendra-config?user_name="+query+"&se_para="+var
    filtered_query="https://ildv1jwtni.execute-api.ap-southeast-1.amazonaws.com/Tuning/fast?user_name="+query
    memberquery = "https://y43rm0ovg6.execute-api.ap-southeast-1.amazonaws.com/memberaddedstage/csv_lambda?user_name="+query+"&se_para="+var
    all_query= "https://o9zknic9fj.execute-api.ap-southeast-1.amazonaws.com/allmember/allmemberresource?user_name="+query
    csv_query= ''
    if var == 'restricted':
        user_query = filtered_query

    if  var == 'pulkit' or var == 'testing':
        user_query = main_query
    if var == 'membertesting'or var == 'membertesting1' or var == 'membertesting2':
        user_query = memberquery

    if var == 'notall':
        user_query = all_query

    
        
       
   

    json_data = requests.get(user_query)
    #content=json.load(json_data)
    new_data=json_data.json()
    content=new_data["user_data"]["Content"]
    filtered_list=[]
    for data in content:
       filtered_list.append(''.join(data))
  

    links=new_data["user_data"]["Links"]
    page_numbers=new_data["user_data"]["page_numbers"]
    filtered_page_numbers=[]
    for  items in  page_numbers:
        filtered_page_numbers.append("Page Number.."+" "+str(items))
    
    
    

    

    filtered_links=[]
    for items in links:
       filtered_links.append(items.split('/')[-1])

    masking_data=list(zip(links,filtered_links))
    for items in masking_data:
       links_masking.update({items[1]:'/'.join(items[0].split('//')[1].split('/')[1:])})
    
   
    #print(links_masking['1525-1526 ICAI in Media.pdf'])
    # links dictionary has been masked
    title=new_data["user_data"]["Doctitle"]

    
    print(selected_data)
    print(universal_drop_down_list)
    print(var)
    return render_template("page_redirect.html",filtered_links=filtered_links,title=title,content=content,query=query,filtered_page_numbers=filtered_page_numbers,drop_down_reflected_data=drop_down_reflected_data,member_list=member_list)
    
    




        
        
        
    
    
  
    



       
       
   
    
  

        
   


    



    













@application.route("/grab_data",methods=['GET','POST'])
def grab_data():
    global user_data
    #return "hello"
    print("done")
    drop_down_reflected_data=[]
    results = request.form
    print(results)
    query=request.args.get("user_data")
    universal_drop_down_list.clear()
    user_data = [query]



    '''
    if len(query) == 0:
        query = "what is icai?"
    '''
    #query = request.form['user_data']
  
   
    #query = request.form.get('user_data')
    drop_down_data=request.args.get("cars")
    
    #print(drop_down_data)
    



    chooose_dict={"0":"notall","1":"pulkit","2":"testing","3":"membertesting","4":"membertesting1","5":"membertesting2","6":"restricted"}
    var=str(chooose_dict[drop_down_data])

    user_selection={"0":"ALL",'1':'JOURNALS','2':'STUDENT PUBLICATIONS','3':'ALL (3 Sub-Categories)','4':'ACCOUNTING STANDARDS','5':'EAC VOLUMES','6':'OPTIMIZED JOURNALS'}

    #### extra code for member selection


    member_list =['ALL (3 Sub-Categories)','ACCOUNTING STANDARDS','EAC VOLUMES']
    main_data=user_selection[drop_down_data]
    drop_down_user_data=['ALL','JOURNALS','STUDENT PUBLICATIONS','ALL (3 Sub-Categories)','ACCOUNTING STANDARDS','EAC VOLUMES','OPTIMIZED JOURNALS']
    selected_data=drop_down_user_data[drop_down_user_data.index(main_data)]

    #### extra code to be deleted ######
    #chooose_dict={"ALL":"notall","JOURNALS":"pulkit","STUDENT PUBLICATIONS":"testing","ALL (3 Sub-Categories)":"membertesting","ACCOUNTING STANDARDS":"membertesting1","EAC VOLUMES":"membertesting2","OPTIMIZED JOURNALS":"restricted"}
    
    #var = chooose_dict[selected_data]









    ###### extra code to be deleted #######


    if selected_data in member_list:
        #member_list.remove(selected_data)

        for items in  member_list:
            drop_down_user_data.remove(items)
        member_list.remove(selected_data)
        drop_down_reflected_data.insert(0,selected_data)
        #drop_down_reflected_data.insert(1,member_list)
        drop_down_reflected_data.extend(drop_down_user_data)
        universal_drop_down_list.extend(drop_down_reflected_data)
        universal_drop_down_list.extend(member_list)
        print("huylulullululuu")
        print(universal_drop_down_list)
        #print(drop_down_reflected_data)
        
        
      
        #drop_down_reflected_data.extend(member_list)
        
    else:
        member_list =['ALL (3 Sub-Categories)','ACCOUNTING STANDARDS','EAC VOLUMES']
        drop_down_user_data=['ALL','JOURNALS','STUDENT PUBLICATIONS','ALL (3 Sub-Categories)','ACCOUNTING STANDARDS','EAC VOLUMES','OPTIMIZED JOURNALS']
        for items in member_list:
            drop_down_user_data.remove(items)
        drop_down_reflected_data.insert(0,selected_data)
        drop_down_user_data.remove(selected_data)
        drop_down_reflected_data.extend(drop_down_user_data)
        print("uululululululu")
        universal_drop_down_list.extend(drop_down_reflected_data)
        universal_drop_down_list.extend(member_list)
        print(universal_drop_down_list)
        
    



        




    
      
        
    







    '''
    drop_down_user_data=['ALL','JOURNALS','STUDENT PUBLICATIONS','ALL (3 Sub-Categories)','ACCOUNTING STANDARDS','EAC VOLUMES','OPTIMIZED JOURNALS']
    main_data=user_selection[drop_down_data]
    selected_data=drop_down_user_data[drop_down_user_data.index(main_data)]
    drop_down_reflected_data.append(selected_data)
    drop_down_user_data.remove(selected_data)
    drop_down_reflected_data.extend(drop_down_user_data)
    universal_dropdown_list = drop_down_reflected_data
    print(universal_dropdown_list)
    print(drop_down_reflected_data)
    '''

    

    
    # taking user drop down data



   
    user_query= ''
    #query = "what ic CA?"
    main_query = "https://eolrvhhdn1.execute-api.ap-southeast-1.amazonaws.com/testing-stage/kendra-config?user_name="+query+"&se_para="+var
    filtered_query="https://ildv1jwtni.execute-api.ap-southeast-1.amazonaws.com/Tuning/fast?user_name="+query
    memberquery = "https://y43rm0ovg6.execute-api.ap-southeast-1.amazonaws.com/memberaddedstage/csv_lambda?user_name="+query+"&se_para="+var
    all_query= "https://o9zknic9fj.execute-api.ap-southeast-1.amazonaws.com/allmember/allmemberresource?user_name="+query
    csv_query= ''
    if var == 'restricted':
        user_query = filtered_query

    if  var == 'pulkit' or var == 'testing':
        user_query = main_query
    if var == 'membertesting'or var == 'membertesting1' or var == 'membertesting2':
        user_query = memberquery

    if var == 'notall':
        user_query = all_query

    '''
    else:
        
        user_query = main_query   
    '''  
       
        
       
   

    json_data = requests.get(user_query)
    #content=json.load(json_data)
    new_data=json_data.json()
    content=new_data["user_data"]["Content"]
    filtered_list=[]
    for data in content:
       filtered_list.append(''.join(data))
  

    links=new_data["user_data"]["Links"]
    page_numbers=new_data["user_data"]["page_numbers"]
    filtered_page_numbers=[]
    for  items in  page_numbers:
        filtered_page_numbers.append("Page Number.."+" "+str(items))
    
    
    

    

    filtered_links=[]
    for items in links:
       filtered_links.append(items.split('/')[-1])

    masking_data=list(zip(links,filtered_links))
    for items in masking_data:
       links_masking.update({items[1]:'/'.join(items[0].split('//')[1].split('/')[1:])})
    
   
    #print(links_masking['1525-1526 ICAI in Media.pdf'])
    # links dictionary has been masked
    title=new_data["user_data"]["Doctitle"]
    return render_template("page_redirect.html",filtered_links=filtered_links,title=title,content=content,query=query,filtered_page_numbers=filtered_page_numbers,drop_down_reflected_data=drop_down_reflected_data,member_list=member_list)
    #user_data = request.form['user_data']
    #print(user_data)
    #return "hello"
    
    
    #user_query = "https://eolrvhhdn1.execute-api.ap-southeast-1.amazonaws.com/testing-stage/kendra-config?user_name="+"what ic icai?"
    #json_data = requests.get(user_query)
   
    #data=request.form["user_data"]



    


if __name__ == "__main__":
    application.run(debug=True)




    



