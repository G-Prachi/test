
Problem faced:
I was getting error while creating React project using create-react-app thst i have higher version install in my root dir 
and create resct app require lower version

How I solve install
Go to your node_module root folder "/Users/clouddev01/node_modules/" and deleted the webpack folder from there and restart the current project yayyy it workes!

