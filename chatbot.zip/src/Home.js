import React from 'react'
import './App.css';
import Chat from './Chat'

export default function Home() {
    return (
        <div className="welcome-screen-back">
            <div className='motherson-logo'> </div>
            <div className='welcome-div'>
                <div className='welcome-ginnie'>
                    Welcome to Ginnie!
          </div>
                <div className='welcome-para'>
                    Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam
          </div>

                <button className='lets-chat-button' onClick={() => <Chat />} > Let's Chat </button>
            </div>
            <div className='group-icon'>
                <div className='path-img-2'>

                    <div className='svg-green-box-div '>
                        <div className='svg-green-rect'>
                            <div className='svg-green-rect2'></div>
                        </div>
                        <div className='svg-green-box'></div>
                        <div className='svg-laptop-box'>

                        </div>
                    </div>

                    <div className='svg-bot-icon '></div>
                    <div className='path-img-1'></div>
                </div>

            </div>




        </div>

    )
}