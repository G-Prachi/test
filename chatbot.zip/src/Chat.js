import React from 'react'
import Amplify from "aws-amplify";
import { AmplifyChatbot } from "@aws-amplify/ui-react";
import awsconfig from "./aws-exports";
import './App.css';

Amplify.configure(awsconfig);

export default function Chat(props) {
    console.log(props)


    return (


        <AmplifyChatbot
            title="Welcome to Covid Care Center.."
            botName="CovidTriageBot"
            botTitle="COVID Assessment Bot"
            welcomeMessage="Hello, how can I help you?"
            voiceEnabled={true} />
    )
}
