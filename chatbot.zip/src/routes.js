import React from "react";
import { BrowserRouter, Switch, Route } from "react-router-dom";
import App from './App'
import Chat from './Chat'


const Routes = () => {
  return (
    <BrowserRouter>
        <Switch>
          <Route path="/" component={App} exact={true} />
          <Route path="/chat" component={Chat} />
        </Switch>
    </BrowserRouter>
  );
};

export default Routes;
