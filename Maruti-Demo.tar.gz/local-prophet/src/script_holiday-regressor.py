import numpy as np
import pandas as pd
from fbprophet import Prophet
import pickle
import datetime as dt
import argparse
import os
from sklearn.metrics import mean_squared_error
import math
festival = pd.DataFrame({
  'holiday': 'festival',
  'ds':pd.to_datetime(['12-09-2016', '19-09-2016', '26-09-2016', '03-10-2016',
       '10-10-2016', '17-10-2016', '31-10-2016', '07-11-2016',
       '26-12-2016', '10-04-2017', '17-04-2017', '28-08-2017',
       '02-09-2017', '11-09-2017', '18-09-2017', '25-09-2017',
       '02-10-2017', '23-10-2017', '25-12-2017', '16-04-2018',
       '28-05-2018', '17-09-2018', '15-10-2018', '22-10-2018',
       '29-10-2018', '05-11-2018', '12-11-2018', '31-12-2018',
       '11-02-2019', '15-04-2019', '15-07-2019', '12-08-2019',
       '16-09-2019', '23-09-2019', '30-09-2019', '28-10-2019',
       '04-11-2019', '11-11-2019','25-12-2019','31-12-2019']),
'lower_window': -7,
  'upper_window': 2,
})

def mean_absolute_percentage_error(y_true, y_pred): 
    wmape = 0
    for i in range(len(y_true)):
        mape = (abs(y_true[i]-y_pred[i])/y_true[i])*100
        wmape += mape*(y_true[i]/35655)
    return wmape

if __name__ == "__main__":    
    parser = argparse.ArgumentParser()
    # Input and output arguments.
    parser.add_argument('--input-dir', type=str, default=os.environ.get('SM_CHANNEL_TRAIN'))
    parser.add_argument('--output-model-dir', type=str, default=os.environ.get('SM_MODEL_DIR'))

    temp = dt.datetime.today()
    nowtime = temp.isoformat()
    
    args = parser.parse_args()
    
    print(args.input_dir)
    print(os.listdir(args.input_dir))

    # Find all *.txt files in the input directory.
    input_files = [ os.path.join(args.input_dir, file) for file in os.listdir(args.input_dir) if file.lower().endswith('.csv') ]    
    model_name = os.path.splitext(os.path.basename(input_files[0]))[0]
    
    print(input_files[0])
        
    data = pd.read_csv(input_files[0],parse_dates=['Date'], date_parser = lambda d: pd.to_datetime(d, format="%d-%m-%Y", errors="coerce"))
    
    #data = pd.read_csv('dataset.csv',parse_dates=['Date'], date_parser = lambda d: pd.to_datetime(d, format="%d-%m-%Y", errors="coerce"))
    x = 'WagonR'
    one = -61
    two = -92
    data_item = data[['Date',x]]
    data_item = data_item.dropna()
    original = data_item[:]
    data_item= data_item[:one]
    df = data_item[['Date',x]]
    df.columns = ['ds','y']

    RBI_repo_rates = pd.DataFrame(data['RBI_repo_rates'].values)
    CPI= pd.DataFrame(data['CPI'].values)
    Capacity_utilization= pd.DataFrame(data['Capacity_utilization'].values)
    Fuel_rates= pd.DataFrame(data['Fuel_rates'].values)
    Bond_yields= pd.DataFrame(data['Bond_yields'].values)
    Bank_credit_growth= pd.DataFrame(data['Bank_credit_growth'].values)
    GDP= pd.DataFrame(data['GDP'].values)
    Stock=pd.DataFrame(data['Stock'].values)
    holiday = pd.DataFrame(data['Holidays'].values)

    if x == 'Swift':
        Mindshare= pd.DataFrame(data['S_Mindshare'].values)
        BTD= pd.DataFrame(data['S_BTD'].values)
        Discount= pd.DataFrame(data['S_Discount'].values)
        S_Positive_sentiment= pd.DataFrame(data['S_Positive_sentiment'].values)
        S_Showroom_visits= pd.DataFrame(data['S_Showroom_visits'].values)
    else:
        Mindshare= pd.DataFrame(data['W_Mindshare'].values)
        BTD= pd.DataFrame(data['W_BTD'].values)
        Discount= pd.DataFrame(data['W_Discount'].values)
        S_Positive_sentiment= pd.DataFrame(data['W_Positive_sentiment'].values)
        S_Showroom_visits= pd.DataFrame(data['W_Showroom_visits'].values)


    BTD=BTD.dropna()
    Stock=Stock.dropna()
    S_Showroom_visits=S_Showroom_visits.dropna()
    Mindshare=Mindshare.dropna()
    Discount=Discount.dropna()
    holiday=holiday.dropna()
    S_Positive_sentiment = S_Positive_sentiment.dropna()
    Capacity_utilization = Capacity_utilization.dropna()
    CPI = CPI.dropna()
    Fuel_rates = Fuel_rates.dropna()
    Bond_yields = Bond_yields.dropna()
    Bank_credit_growth = Bank_credit_growth.dropna()
    GDP = GDP.dropna()
    RBI_repo_rates=RBI_repo_rates.dropna()

    #df['RBI_repo_rates'] = RBI_repo_rates[:two].values
    df['Mindshare'] = Mindshare[:two].values
    df['Discount'] = Discount[:two].values
    #df['BTD'] = BTD[:two].values
    #df['Stock'] = Stock[:two].values
    #df['S_Positive_sentiment'] = S_Positive_sentiment[:two].values
    #df['holiday'] = holiday[:two].values
    #df['Capacity_utilization'] = Capacity_utilization[:two].values
    #df['CPI'] = CPI[:two].values
    #df['Fuel_rates'] = Fuel_rates[:two].values
    #df['Bond_yields'] = Bond_yields[:two].values
    #df['Bank_credit_growth'] = Bank_credit_growth[:two].values
    #df['GDP'] = GDP[:two].values
    #df['S_Showroom_visits'] = S_Showroom_visits[:two].values



    #m = Prophet(holidays=festival,changepoints=changepoints,changepoint_range=0.01)
    m = Prophet(holidays=festival,yearly_seasonality=20,daily_seasonality=False,weekly_seasonality=False)
    #m = Prophet(holidays=festival)
    m.add_seasonality(name='monthly', period=30.5, fourier_order=20)
    #m.add_seasonality(name='yearly', period=365, fourier_order=20)
    m.add_seasonality(name='weekly', period=7, fourier_order=10)
    m.add_regressor('Discount')
    #m.add_regressor('RBI_repo_rates')
    m.add_regressor('Mindshare')
    #m.add_regressor('BTD')
    #m.add_regressor('Stock')
    #m.add_regressor('holiday')
    #m.add_regressor('S_Positive_sentiment')
    #m.add_regressor('Capacity_utilization')
    #m.add_regressor('CPI')
    #m.add_regressor('Fuel_rates')
    #m.add_regressor('Bond_yields')
    #m.add_regressor('Bank_credit_growth')
    #m.add_regressor('GDP')
    #m.add_regressor('S_Showroom_visits')
    m.fit(df)


    future = m.make_future_dataframe(periods=abs(two),freq='D')

    future['Discount'] = Discount.values
    #future['RBI_repo_rates'] = RBI_repo_rates.values
    #future['holiday'] = holiday.values
    #future['BTD'] = BTD.values
    #future['Stock'] = Stock.values
    future['Mindshare'] = Mindshare.values
    #future['S_Positive_sentiment'] = S_Positive_sentiment.values
    #future['Capacity_utilization'] = Capacity_utilization.values
    #future['CPI'] =CPI.values
    #future['Fuel_rates'] =Fuel_rates.values
    #future['Bond_yields'] =Bond_yields.values
    #future['Bank_credit_growth'] =Bank_credit_growth.values
    #future['GDP'] =GDP.values
    #future['S_Showroom_visits'] =S_Showroom_visits.values
    forecast1 = m.predict(future)


    forecast = forecast1[['ds','yhat']]
    forecast['ds']=pd.to_datetime(forecast['ds'],format='%Y-%m-%d')
    forecast.set_index('ds',inplace=True)
    forecast = np.ceil(forecast)
    forecast[forecast <= 0] = 0 
    forecast.resample('M').sum()
    #forecast[-92:-31]

    original1 = original[one:][[x]]
    temp = forecast[two:-31]['yhat']


    print(original1[x].values)
    print(temp.values)
    print(mean_absolute_percentage_error(original1[x].values,temp.values))
    
    rmse = math.sqrt(mean_squared_error(original1, temp))   
    csv_path = os.path.join(args.output_model_dir, "-{}-{}.csv".format(nowtime, x))
    forecast.to_csv(csv_path)
    #forecast.to_csv('forecast.csv')
    print('RMSE : ------------------',rmse)
    #with open('model.pkl', 'w') as fout:
        #pickle.dump(m, fout)