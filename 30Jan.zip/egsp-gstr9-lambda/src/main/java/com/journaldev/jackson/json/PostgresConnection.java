package com.journaldev.jackson.json;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class PostgresConnection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 String url = "jdbc:postgresql://egspuat1.c6qmlqzk7usk.ap-south-1.rds.amazonaws.com:5432/egsptest"; 
	        String user = "egspuatadmin"; 
	        String pass = "uategsp1#"; 
	        Connection con =null; 
	        Statement stmt = null;
	        try
	        { 
	            Class.forName("org.postgresql.Driver");
	            con = DriverManager.getConnection(url,user,pass); 
	            stmt = con.createStatement();
	            ResultSet rs = stmt.executeQuery( "SELECT * FROM egsp_client_mst limit 1" );
	            while ( rs.next() ) {
	            	System.out.println("In the Database");
	            }
	            rs.close();
	            stmt.close();
	            con.close();
	  
		      } catch (Exception e) {
		         e.printStackTrace();
		         System.err.println(e.getClass().getName()+": "+e.getMessage());
		         System.exit(0);
		      }
		      System.out.println("Opened database successfully");

	}

}
