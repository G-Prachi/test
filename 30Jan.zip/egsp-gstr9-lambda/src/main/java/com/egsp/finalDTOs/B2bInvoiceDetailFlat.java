package com.egsp.finalDTOs;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.model.gstr1.B2bItem;
import com.mind.egsp.gstn.model.gstr1.B2bItemsComparator;

/**
 * The Class B2BInvoiceDetail.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class B2bInvoiceDetailFlat implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	
	/** Supplier Invoice Number. */
	private String inum;

	private String type;
	/** Supplier Invoice Date. */
	private String idt;
	
	private BigDecimal totaltxval = new BigDecimal(0);
	
	private BigDecimal totaliamt = new BigDecimal(0);
	
	private BigDecimal totalcamt =new BigDecimal(0);
	
	private BigDecimal totalsamt =new BigDecimal(0);
	
	private BigDecimal totalcsamt = new BigDecimal(0);
	/**
	 * Gets the Supplier Invoice Number.
	 *
	 * @return the inum
	 */
	public String getInum() {
		return inum;
	}

	
	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	/**
	 * Sets the Supplier Invoice Number.
	 *
	 * @param inum
	 *            the new inum
	 */
	public void setInum(String inum) {
		this.inum = inum;
	}

	public String getIdt() {
		return idt;
	}

	public void setIdt(String idt) {
		this.idt = idt;
	}

	public BigDecimal getTotaltxval() {
		return totaltxval;
	}

	public void setTotaltxval(BigDecimal totaltxval) {
		this.totaltxval = totaltxval;
	}

	public BigDecimal getTotaliamt() {
		return totaliamt;
	}

	public void setTotaliamt(BigDecimal totaliamt) {
		this.totaliamt = totaliamt;
	}

	public BigDecimal getTotalcamt() {
		return totalcamt;
	}

	public void setTotalcamt(BigDecimal totalcamt) {
		this.totalcamt = totalcamt;
	}

	public BigDecimal getTotalsamt() {
		return totalsamt;
	}

	public void setTotalsamt(BigDecimal totalsamt) {
		this.totalsamt = totalsamt;
	}

	public BigDecimal getTotalcsamt() {
		return totalcsamt;
	}

	public void setTotalcsamt(BigDecimal totalcsamt) {
		this.totalcsamt = totalcsamt;
	}

	@Override
	public String toString() {
		return "B2bInvoiceDetailFlat [inum=" + inum + ", idt=" + idt + ", totaltxval=" + totaltxval + ", totaliamt="
				+ totaliamt + ", totalcamt=" + totalcamt + ", totalsamt=" + totalsamt + ", totalcsamt=" + totalcsamt
				+ "]";
	}
	
	

}
