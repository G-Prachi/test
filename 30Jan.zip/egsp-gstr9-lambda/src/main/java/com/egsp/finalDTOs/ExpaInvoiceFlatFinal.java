

package com.egsp.finalDTOs;

import java.io.Serializable;
import java.math.BigDecimal;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class ExpaInvoiceFlatFinal implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** GSTIN/UID of the Receiver taxpayer/UN, Govt Bodies. */
	//private String ctin;
	public String getExTp() {
		return exTp;
	}

	public void setExTp(String exTp) {
		this.exTp = exTp;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private String exTp;
	private String oinum;

	/** The Original Invoice date. */
	private String oidt;

	/**
	 * Gets Original Invoice number Field
	 * 
	 * Specification: Alphanumeric (Max length:50)
	 * 
	 * Sample Data A38610200.
	 *
	 * @return the onum
	 */
	public String getOinum() {
		return oinum;
	}

	/**
	 * Sets Original Invoice number
	 * 
	 * Field Specification: Alphanumeric (Max length:50)
	 * 
	 * Sample Data A38610200.
	 *
	 * @param onum
	 *            the new onum
	 */
	public void setOinum(String oinum) {
		this.oinum = oinum;
	}

	/**
	 * Gets the Original Invoice number
	 * 
	 * Field Specification: Alphanumeric (Max length:50)
	 * 
	 * Sample Data A38610200.
	 *
	 * @return the odt
	 */
	public String getOidt() {
		return oidt;
	}

	/**
	 * Sets the Original Invoice number
	 * 
	 * Field Specification: Alphanumeric (Max length:50)
	 * 
	 * Sample Data A38610200.
	 *
	 * @param odt
	 *            the new odt
	 */
	public void setOidt(String oidt) {
		this.oidt = oidt;
	}
	


	/** Supplier Invoice Number. */
	private String inum;
	
	private String businessType;
	/** Supplier Invoice Value. */
	private BigDecimal val;
	
	/** Reverse Charge. */
	//private Character rchrg = 'N';
	
	/** The Invoice type. */
	//@JsonProperty("inv_typ")
	//private String invTyp;
	
	private String fp;
	
	/** Supplier Invoice Date. */
	private String idt;
	
	private BigDecimal totaltxval = new BigDecimal(0);
	
	private BigDecimal totaliamt = new BigDecimal(0);
	
	private BigDecimal totalcamt =new BigDecimal(0);
	
	private BigDecimal totalsamt =new BigDecimal(0);
	
	private BigDecimal totalcsamt = new BigDecimal(0);

	/*public String getCtin() {
		return ctin;
	}

	public void setCtin(String ctin) {
		this.ctin = ctin;
	}*/

	public String getInum() {
		return inum;
	}

	public void setInum(String inum) {
		this.inum = inum;
	}

	public BigDecimal getVal() {
		return val;
	}

	public void setVal(BigDecimal val) {
		this.val = val;
	}

	/*public Character getRchrg() {
		return rchrg;
	}

	public void setRchrg(Character rchrg) {
		this.rchrg = rchrg;
	}*/

/*	public String getInvTyp() {
		return invTyp;
	}

	public void setInvTyp(String invTyp) {
		this.invTyp = invTyp;
	}*/

	public String getIdt() {
		return idt;
	}

	public void setIdt(String idt) {
		this.idt = idt;
	}

	public BigDecimal getTotaltxval() {
		return totaltxval;
	}

	public void setTotaltxval(BigDecimal totaltxval) {
		this.totaltxval = totaltxval;
	}

	public BigDecimal getTotaliamt() {
		return totaliamt;
	}

	public void setTotaliamt(BigDecimal totaliamt) {
		this.totaliamt = totaliamt;
	}

	public BigDecimal getTotalcamt() {
		return totalcamt;
	}

	public void setTotalcamt(BigDecimal totalcamt) {
		this.totalcamt = totalcamt;
	}

	public BigDecimal getTotalsamt() {
		return totalsamt;
	}

	public void setTotalsamt(BigDecimal totalsamt) {
		this.totalsamt = totalsamt;
	}

	public BigDecimal getTotalcsamt() {
		return totalcsamt;
	}

	public void setTotalcsamt(BigDecimal totalcsamt) {
		this.totalcsamt = totalcsamt;
	}
	
	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public String getFp() {
		return fp;
	}

	public void setFp(String fp) {
		this.fp = fp;
	}
	
	@Override
	public String toString() {
		return "ExpInvoiceFlatFinal [inum=" + inum + ", val=" + val + ", idt=" + idt + ", totaltxval=" + totaltxval + ", totaliamt=" + totaliamt
				+ ", totalcamt=" + totalcamt + ", totalsamt=" + totalsamt + ", totalcsamt=" + totalcsamt + "]";
	}
	
}
