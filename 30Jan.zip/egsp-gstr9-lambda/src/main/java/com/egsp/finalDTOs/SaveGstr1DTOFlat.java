package com.egsp.finalDTOs;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import com.mind.egsp.gstn.model.gstr1.AtInvoice;
import com.mind.egsp.gstn.model.gstr1.AtaInvoice;
import com.mind.egsp.gstn.model.gstr1.B2bInvoice;
import com.mind.egsp.gstn.model.gstr1.B2baInvoice;
import com.mind.egsp.gstn.model.gstr1.B2csInvoice;
import com.mind.egsp.gstn.model.gstr1.B2csaInvoice;
import com.mind.egsp.gstn.model.gstr1.CdnrInvoice;
import com.mind.egsp.gstn.model.gstr1.CdnraInvoice;
import com.mind.egsp.gstn.model.gstr1.CdnurInvoiceDetail;
import com.mind.egsp.gstn.model.gstr1.CdnuraInvoiceDetail;
import com.mind.egsp.gstn.model.gstr1.DocIssueInvoice;
import com.mind.egsp.gstn.model.gstr1.ExpInvoice;
import com.mind.egsp.gstn.model.gstr1.ExpaInvoice;
import com.mind.egsp.gstn.model.gstr1.HsnSummary;
import com.mind.egsp.gstn.model.gstr1.NilSupply;
//import com.mind.egsp.gstn.model.gstr1.StateB2ClInvoices;
import com.mind.egsp.gstn.model.gstr1.TxpdInvoice;
import com.mind.egsp.gstn.model.gstr1.TxpdaInvoice;

// TODO: Auto-generated Javadoc
/**
 * The Gstr1 Save DTO.
 */

public class SaveGstr1DTOFlat implements Serializable {


	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/** The GSTIN of the Tax Payer. */
	private String gstin;

	/** Financial period. */
	private String fp;

	/** Gross Turn Over. */
	private BigDecimal gt;

	/** Gross Turnover - April to June, 2017 . */
	private BigDecimal curGt;

	/** B2B Invoices (represents table 5 of GSTR1). */
	private List<B2bInvoiceFlatFinal> b2bInvoices;

	/** The b 2 ba invoice. */
	private List<B2baInvoiceFlatFinal> b2baInvoices;
	//private List<B2claInvoiceFlatFinal> b2claInvoices;
	private List<B2clInvoiceFlatFinal> b2clInvoices;

	/** The B2cl invoice. */
	//private List<StateB2ClInvoices> stateB2ClInvoicesList;

	/** The B2cla invoice. */

	//private List<StateB2ClaInvoices> stateB2ClaInvoicesList;

	/** The B2cs invoice. */
	private List<B2csInvoiceFlatFinal> b2csInvoices;

	/** The b 2 csa invoices. */
	private List<B2csaInvoiceFlatFinal> b2csaInvoices;

	/** The Export invoice. */
	private List<ExpInvoiceFlatFinal> expInvoices;

	/** The expa invoices. */
	
	private List<ExpaInvoiceFlatFinal> expaInvoices;

	/** The Advance Tax invoice. */

	private List<AtInvoiceFlatFinal> atInvoices;

	/** The ata invoices. */

	private List<AtaInvoiceFlatFinal> ataInvoices;

	/** Advance Tax paid details. */

	private List<TxpdInvoiceFlatFinal> txpdInvoices;

	/** The Advance Tax paid details Ammendment. */

	private List<TxpdaInvoiceFlatFinal> txpdaInvoices;

	/** The Credit Debit Notes Registered Users invoice. */
	
	private List<CdnrInvoiceFlatFinal> cdnrInvoices;

	/** The amended Credit Debit Notes Registered Users invoice. */

	private List<CdnraInvoiceFlatFinal> cdnraInvoices;

	private List<CdnuraInvoiceFlatFinal> cdnuraInvoices;
	private List<CdnurInvoiceFlatFinal> cdnurInvoices;
	/** The Nil Supplies. */

	private NilInvoiceFlatFinal nilSupply;

	/** The HSN/SAC summary of outward supplies. */

	private HsnInvoiceFlatFinal hsnSummary;

	/** The Credit Debit Notes Un-Registered TaxPayers. */
	private List<CdnurInvoiceDetail> cdnurInvoiceDetails;

	/** The Credit Debit Notes Amendments Un-Registered TaxPayers. */
	private List<CdnuraInvoiceDetail> cdnuraInvoiceDetails;

	/** The doc issue invoices. */
	private DocIssueInvoice docIssueInvoice;



	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getFp() {
		return fp;
	}

	public void setFp(String fp) {
		this.fp = fp;
	}

	public BigDecimal getGt() {
		return gt;
	}

	public void setGt(BigDecimal gt) {
		this.gt = gt;
	}

	public BigDecimal getCurGt() {
		return curGt;
	}

	public void setCurGt(BigDecimal curGt) {
		this.curGt = curGt;
	}

	public List<B2bInvoiceFlatFinal> getB2bInvoices() {
		return b2bInvoices;
	}

	public void setB2bInvoices(List<B2bInvoiceFlatFinal> b2bInvoices) {
		this.b2bInvoices = b2bInvoices;
	}

	public List<B2baInvoiceFlatFinal> getB2baInvoices() {
		return b2baInvoices;
	}

	public void setB2baInvoices(List<B2baInvoiceFlatFinal> b2baInvoices) {
		this.b2baInvoices = b2baInvoices;
	}

/*	public List<B2claInvoiceFlatFinal> getB2claInvoices() {
		return b2claInvoices;
	}

	public void setB2claInvoices(List<B2claInvoiceFlatFinal> b2claInvoices) {
		this.b2claInvoices = b2claInvoices;
	}*/

	public List<B2clInvoiceFlatFinal> getB2clInvoices() {
		return b2clInvoices;
	}

	public void setB2clInvoices(List<B2clInvoiceFlatFinal> b2clInvoices) {
		this.b2clInvoices = b2clInvoices;
	}

	/*public List<StateB2ClInvoices> getStateB2ClInvoicesList() {
		return stateB2ClInvoicesList;
	}

	public void setStateB2ClInvoicesList(List<StateB2ClInvoices> stateB2ClInvoicesList) {
		this.stateB2ClInvoicesList = stateB2ClInvoicesList;
	}*/

	public List<B2csInvoiceFlatFinal> getB2csInvoices() {
		return b2csInvoices;
	}

	public void setB2csInvoices(List<B2csInvoiceFlatFinal> b2csInvoices) {
		this.b2csInvoices = b2csInvoices;
	}

	public List<B2csaInvoiceFlatFinal> getB2csaInvoices() {
		return b2csaInvoices;
	}

	public void setB2csaInvoices(List<B2csaInvoiceFlatFinal> b2csaInvoices) {
		this.b2csaInvoices = b2csaInvoices;
	}

	public List<ExpInvoiceFlatFinal> getExpInvoices() {
		return expInvoices;
	}

	public void setExpInvoices(List<ExpInvoiceFlatFinal> expInvoices) {
		this.expInvoices = expInvoices;
	}

	public List<ExpaInvoiceFlatFinal> getExpaInvoices() {
		return expaInvoices;
	}

	public void setExpaInvoices(List<ExpaInvoiceFlatFinal> expaInvoices) {
		this.expaInvoices = expaInvoices;
	}

	public List<AtInvoiceFlatFinal> getAtInvoices() {
		return atInvoices;
	}

	public void setAtInvoices(List<AtInvoiceFlatFinal> atInvoices) {
		this.atInvoices = atInvoices;
	}

	public List<AtaInvoiceFlatFinal> getAtaInvoices() {
		return ataInvoices;
	}

	public void setAtaInvoices(List<AtaInvoiceFlatFinal> ataInvoices) {
		this.ataInvoices = ataInvoices;
	}

	public List<TxpdInvoiceFlatFinal> getTxpdInvoices() {
		return txpdInvoices;
	}

	public void setTxpdInvoices(List<TxpdInvoiceFlatFinal> txpdInvoices) {
		this.txpdInvoices = txpdInvoices;
	}

	public List<TxpdaInvoiceFlatFinal> getTxpdaInvoices() {
		return txpdaInvoices;
	}

	public void setTxpdaInvoices(List<TxpdaInvoiceFlatFinal> txpdaInvoices) {
		this.txpdaInvoices = txpdaInvoices;
	}

	public List<CdnrInvoiceFlatFinal> getCdnrInvoices() {
		return cdnrInvoices;
	}

	public void setCdnrInvoices(List<CdnrInvoiceFlatFinal> cdnrInvoices) {
		this.cdnrInvoices = cdnrInvoices;
	}

	public List<CdnraInvoiceFlatFinal> getCdnraInvoices() {
		return cdnraInvoices;
	}

	public void setCdnraInvoices(List<CdnraInvoiceFlatFinal> cdnraInvoices) {
		this.cdnraInvoices = cdnraInvoices;
	}

	public List<CdnuraInvoiceFlatFinal> getCdnuraInvoices() {
		return cdnuraInvoices;
	}

	public void setCdnuraInvoices(List<CdnuraInvoiceFlatFinal> cdnuraInvoices) {
		this.cdnuraInvoices = cdnuraInvoices;
	}

	public List<CdnurInvoiceFlatFinal> getCdnurInvoices() {
		return cdnurInvoices;
	}

	public void setCdnurInvoices(List<CdnurInvoiceFlatFinal> cdnurInvoices) {
		this.cdnurInvoices = cdnurInvoices;
	}

	public NilInvoiceFlatFinal getNilSupply() {
		return nilSupply;
	}

	public void setNilSupply(NilInvoiceFlatFinal nilSupply) {
		this.nilSupply = nilSupply;
	}

	public HsnInvoiceFlatFinal getHsnSummary() {
		return hsnSummary;
	}

	public void setHsnSummary(HsnInvoiceFlatFinal hsnSummary) {
		this.hsnSummary = hsnSummary;
	}

	public List<CdnurInvoiceDetail> getCdnurInvoiceDetails() {
		return cdnurInvoiceDetails;
	}

	public void setCdnurInvoiceDetails(List<CdnurInvoiceDetail> cdnurInvoiceDetails) {
		this.cdnurInvoiceDetails = cdnurInvoiceDetails;
	}

	public List<CdnuraInvoiceDetail> getCdnuraInvoiceDetails() {
		return cdnuraInvoiceDetails;
	}

	public void setCdnuraInvoiceDetails(List<CdnuraInvoiceDetail> cdnuraInvoiceDetails) {
		this.cdnuraInvoiceDetails = cdnuraInvoiceDetails;
	}

	/**
	 * Gets the doc issue invoice.
	 *
	 * @return the doc issue invoice
	 */
	public DocIssueInvoice getDocIssueInvoice() {
		return docIssueInvoice;
	}

	/**
	 * Sets the doc issue invoice.
	 *
	 * @param docIssueInvoice
	 *            the new doc issue invoice
	 */
	public void setDocIssueInvoice(DocIssueInvoice docIssueInvoice) {
		this.docIssueInvoice = docIssueInvoice;
	}

	/**
	 * Gets the txpda invoices.
	 *
	 * @return the txpda invoices
	 */
	

	@Override
	public String toString() {
		return "SaveGstr1DTOFlat [fp=" + fp + ", b2bInvoices=" + b2bInvoices + "]";
	}

	
}
