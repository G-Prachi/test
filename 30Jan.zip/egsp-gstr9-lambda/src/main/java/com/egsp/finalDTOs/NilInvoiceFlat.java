package com.egsp.finalDTOs;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * The Class for NIL Invoice.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class NilInvoiceFlat implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** GSTIN/UID of the Receiver taxpayer/UN, Govt Bodies. */
	//private String ctin;

	/** Supplier Invoice Number. */
//	private String inum;
	
private List<NilInvoiceDetailFlat> nilInvoiceDetailFLat;
	/** Reverse Charge. */
	//private Character rchrg = 'N';
	
	/** The Invoice type. */
	@JsonProperty("inv_typ")
	//private String invTyp;
	

	/** Supplier Invoice Value. */
	
	private String fp;
	public String getFp() {
		return fp;
	}

	public void setFp(String fp) {
		this.fp = fp;
	}

	public BigDecimal getNilAmt() {
		return nilAmt;
	}

	public void setNilAmt(BigDecimal nilAmt) {
		this.nilAmt = nilAmt;
	}

	public BigDecimal getExptAmt() {
		return exptAmt;
	}

	public void setExptAmt(BigDecimal exptAmt) {
		this.exptAmt = exptAmt;
	}

	public BigDecimal getNgsupAmt() {
		return ngsupAmt;
	}

	public void setNgsupAmt(BigDecimal ngsupAmt) {
		this.ngsupAmt = ngsupAmt;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private BigDecimal nilAmt;

	/** The Total Exempted outward supplies. */
	@JsonProperty("expt_amt")
	private BigDecimal exptAmt;

	/** The Total Non GST outward supplies. */
	@JsonProperty("ngsup_amt")
	private BigDecimal ngsupAmt;

	public List<NilInvoiceDetailFlat> getNilInvoiceDetailFLat() {
		return nilInvoiceDetailFLat;
	}

	public void setNilInvoiceDetailFLat(List<NilInvoiceDetailFlat> nilInvoiceDetailFLat) {
		this.nilInvoiceDetailFLat = nilInvoiceDetailFLat;
	}

	//@Override
	//public String toString() {
		//return "NilInvoiceFlat [totaltxval=" + totaltxval + ", totaliamt=" + totaliamt + ", totalcamt="
			//	+ totalcamt + ", totalsamt=" + totalsamt + ", totalcsamt=" + totalcsamt + "]";
	//}
	
	
}
