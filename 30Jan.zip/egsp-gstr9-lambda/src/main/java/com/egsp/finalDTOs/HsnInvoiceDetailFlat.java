package com.egsp.finalDTOs;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
//import com.mind.egsp.gstn.model.gstr1.HsnItem;
//import com.mind.egsp.gstn.model.gstr1.HsnItemsComparator;

/**
 * The Class TXPDInvoiceDetail.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class HsnInvoiceDetailFlat implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	
	/** Supplier Invoice Number. */
	private String inum;
	
	private BigDecimal totalval = new BigDecimal(0);
	
	@JsonProperty("hsn_sc")
	private String hsnSc;

	public String getHsnSc() {
		return hsnSc;
	}

	public void setHsnSc(String hsnSc) {
		this.hsnSc = hsnSc;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getUqc() {
		return uqc;
	}

	public void setUqc(String uqc) {
		this.uqc = uqc;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/** The Description of goods sold. */
	private String desc;

	/** The UQC (Unit of Measure) of goods sold. */
	private String uqc;

	public BigDecimal getTotalval() {
		return totalval;
	}
	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	private String businessType;
	public void setTotalval(BigDecimal totalval) {
		this.totalval = totalval;
	}
	private String fp;
	
	public String getFp() {
		return fp;
	}

	public void setFp(String fp) {
		this.fp = fp;
	}

	private BigDecimal txval;
	public BigDecimal getTxval() {
		return txval;
	}

	public void setTxval(BigDecimal txval) {
		this.txval = txval;
	}

	private String type;
	/** Supplier Invoice Date. */
	private String idt;
	
	/*private BigDecimal totaltxval = new BigDecimal(0);
	
	private BigDecimal totaliamt = new BigDecimal(0);
	
	private BigDecimal totalcamt =new BigDecimal(0);
	
	private BigDecimal totalsamt =new BigDecimal(0);
	
	private BigDecimal totalcsamt = new BigDecimal(0);*/
	
	
	/*public void setVal(BigDecimal val) {
		this.val = val;
	}*/
	/** The IGST Rate as per invoice. */
	private BigDecimal irt;

	public BigDecimal getIrt() {
		return irt;
	}

	public void setIrt(BigDecimal irt) {
		this.irt = irt;
	}

	public BigDecimal getIamt() {
		return iamt;
	}

	public void setIamt(BigDecimal iamt) {
		this.iamt = iamt;
	}

	public BigDecimal getCrt() {
		return crt;
	}

	public void setCrt(BigDecimal crt) {
		this.crt = crt;
	}

	public BigDecimal getCamt() {
		return camt;
	}

	public void setCamt(BigDecimal camt) {
		this.camt = camt;
	}

	public BigDecimal getSrt() {
		return srt;
	}

	public void setSrt(BigDecimal srt) {
		this.srt = srt;
	}

	public BigDecimal getSamt() {
		return samt;
	}

	public void setSamt(BigDecimal samt) {
		this.samt = samt;
	}

	public BigDecimal getCsrt() {
		return csrt;
	}

	public void setCsrt(BigDecimal csrt) {
		this.csrt = csrt;
	}

	public BigDecimal getCsamt() {
		return csamt;
	}

	public void setCsamt(BigDecimal csamt) {
		this.csamt = csamt;
	}

	/** The IGST Amount as per invoice. */
	private BigDecimal iamt;

	/** The CGST Rate as per invoice. */
	private BigDecimal crt;

	/** The CGST Amount as per invoice. */
	private BigDecimal camt;

	/** The SGST Rate as per invoice. */
	private BigDecimal srt;

	/** The SGST Amount as per invoice. */
	private BigDecimal samt;

	/** The Cess Rate as per invoice. */
	private BigDecimal csrt;

	/** The Cess Amount as per invoice. */
	private BigDecimal csamt;
	/**
	 * Gets the Supplier Invoice Number.
	 *
	 * @return the inum
	 */
	public String getInum() {
		return inum;
	}
	
	public String getType() {
		return type;
	}
	private BigDecimal val;

	public BigDecimal getVal() {
		return val;
	}

	public void setVal(BigDecimal val) {
		this.val = val;
	}

	public void setType(String type) {
		this.type = type;
	}



	/**
	 * Sets the Supplier Invoice Number.
	 *
	 * @param inum
	 *            the new inum
	 */
	public void setInum(String inum) {
		this.inum = inum;
	}

	public String getIdt() {
		return idt;
	}

	public void setIdt(String idt) {
		this.idt = idt;
	}

	/*public BigDecimal getTotaltxval() {
		return totaltxval;
	}

	public void setTotaltxval(BigDecimal totaltxval) {
		this.totaltxval = totaltxval;
	}

	public BigDecimal getTotaliamt() {
		return totaliamt;
	}

	public void setTotaliamt(BigDecimal totaliamt) {
		this.totaliamt = totaliamt;
	}

	public BigDecimal getTotalcamt() {
		return totalcamt;
	}

	public void setTotalcamt(BigDecimal totalcamt) {
		this.totalcamt = totalcamt;
	}

	public BigDecimal getTotalsamt() {
		return totalsamt;
	}

	public void setTotalsamt(BigDecimal totalsamt) {
		this.totalsamt = totalsamt;
	}

	public BigDecimal getTotalcsamt() {
		return totalcsamt;
	}

	public void setTotalcsamt(BigDecimal totalcsamt) {
		this.totalcsamt = totalcsamt;
	}

	@Override
	public String toString() {
		return "HsnInvoiceDetailFlat [inum=" + inum + ", idt=" + idt + ", totaltxval=" + totaltxval + ", totaliamt="
				+ totaliamt + ", totalcamt=" + totalcamt + ", totalsamt=" + totalsamt + ", totalcsamt=" + totalcsamt
				+ "]";*/
	}
	
	
