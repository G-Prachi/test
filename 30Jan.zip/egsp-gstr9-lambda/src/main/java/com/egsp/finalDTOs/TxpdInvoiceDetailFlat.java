package com.egsp.finalDTOs;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
//import com.mind.egsp.gstn.model.gstr1.TxpdItem;
//import com.mind.egsp.gstn.model.gstr1.TxpdItemsComparator;

/**
 * The Class TXPDInvoiceDetail.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class TxpdInvoiceDetailFlat implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	private BigDecimal adAmt;
	public BigDecimal getAdAmt() {
		return adAmt;
	}
	public String getOmon() {
		return omon;
	}

	public void setOmon(String omon) {
		this.omon = omon;
	}
	private String omon;
	

	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public String getFp() {
		return fp;
	}

	public void setFp(String fp) {
		this.fp = fp;
	}


	private String businessType;
	/** Supplier Invoice Value. */
	//private BigDecimal val;
	
	/** Reverse Charge. */
	//private Character rchrg = 'N';
	
	/** The Invoice type. */
	@JsonProperty("inv_typ")
	//private String invTyp;
	
	private String fp;
	

	public void setAdAmt(BigDecimal adAmt) {
		this.adAmt = adAmt;
	}

	/** Supplier Invoice Number. */
	private String inum;
	
	private BigDecimal totaladAmt = new BigDecimal(0);

	public BigDecimal getTotaladAmt() {
		return totaladAmt;
	}

	public void setTotaladAmt(BigDecimal totaladAmt) {
		this.totaladAmt = totaladAmt;
	}

	private String type;
	/** Supplier Invoice Date. */
	private String idt;
	
	private BigDecimal totaltxval = new BigDecimal(0);
	
	private BigDecimal totaliamt = new BigDecimal(0);
	
	private BigDecimal totalcamt =new BigDecimal(0);
	
	private BigDecimal totalsamt =new BigDecimal(0);
	
	private BigDecimal totalcsamt = new BigDecimal(0);
	/**
	 * Gets the Supplier Invoice Number.
	 *
	 * @return the inum
	 */
	public String getInum() {
		return inum;
	}

	
	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	/**
	 * Sets the Supplier Invoice Number.
	 *
	 * @param inum
	 *            the new inum
	 */
	public void setInum(String inum) {
		this.inum = inum;
	}

	public String getIdt() {
		return idt;
	}

	public void setIdt(String idt) {
		this.idt = idt;
	}

	public BigDecimal getTotaltxval() {
		return totaltxval;
	}

	public void setTotaltxval(BigDecimal totaltxval) {
		this.totaltxval = totaltxval;
	}

	public BigDecimal getTotaliamt() {
		return totaliamt;
	}

	public void setTotaliamt(BigDecimal totaliamt) {
		this.totaliamt = totaliamt;
	}

	public BigDecimal getTotalcamt() {
		return totalcamt;
	}

	public void setTotalcamt(BigDecimal totalcamt) {
		this.totalcamt = totalcamt;
	}

	public BigDecimal getTotalsamt() {
		return totalsamt;
	}

	public void setTotalsamt(BigDecimal totalsamt) {
		this.totalsamt = totalsamt;
	}

	public BigDecimal getTotalcsamt() {
		return totalcsamt;
	}

	public void setTotalcsamt(BigDecimal totalcsamt) {
		this.totalcsamt = totalcsamt;
	}

	@Override
	public String toString() {
		return "TxpdInvoiceDetailFlat [inum=" + inum + ", idt=" + idt + ", totaltxval=" + totaltxval + ", totaliamt="
				+ totaliamt + ", totalcamt=" + totalcamt + ", totalsamt=" + totalsamt + ", totalcsamt=" + totalcsamt
				+ "]";
	}
	
	

}
