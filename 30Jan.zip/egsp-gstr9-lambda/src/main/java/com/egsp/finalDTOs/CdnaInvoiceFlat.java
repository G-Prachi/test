package com.egsp.finalDTOs;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * The Class for CDNA Invoice.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class CdnaInvoiceFlat implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** GSTIN/UID of the Receiver taxpayer/UN, Govt Bodies. */
	private String ctin;

	/** Supplier Invoice Number. */
	private String inum;
	
	private List<CdnaInvoiceDetailFlat> cdnaInvoiceDetailFLat;
	/** Reverse Charge. */
	private Character rchrg = 'N';
	
	/** The Invoice type. */
	@JsonProperty("inv_typ")
	private String invTyp;
	public String getOntNum() {
		return ontNum;
	}

	public void setOntNum(String ontNum) {
		this.ontNum = ontNum;
	}

	public String getOntDt() {
		return ontDt;
	}

	public void setOntDt(String ontDt) {
		this.ontDt = ontDt;
	}
	private String ontNum;

	private String ontDt;

	/** Supplier Invoice Value. */
	private BigDecimal val;

	private BigDecimal totaltxval = new BigDecimal(0);
	
	private BigDecimal totaliamt = new BigDecimal(0);
	
	private BigDecimal totalcamt =new BigDecimal(0);
	
	private BigDecimal totalsamt =new BigDecimal(0);
	
	private BigDecimal totalcsamt = new BigDecimal(0);

	public String getCtin() {
		return ctin;
	}

	public void setCtin(String ctin) {
		this.ctin = ctin;
	}

	public String getInum() {
		return inum;
	}

	public void setInum(String inum) {
		this.inum = inum;
	}

	public Character getRchrg() {
		return rchrg;
	}

	public void setRchrg(Character rchrg) {
		this.rchrg = rchrg;
	}
	
	public String getInvTyp() {
		return invTyp;
	}

	public void setInvTyp(String invTyp) {
		this.invTyp = invTyp;
	}

	public BigDecimal getVal() {
		return val;
	}

	public void setVal(BigDecimal val) {
		this.val = val;
	}

	public BigDecimal getTotaltxval() {
		return totaltxval;
	}

	public void setTotaltxval(BigDecimal totaltxval) {
		this.totaltxval = totaltxval;
	}

	public BigDecimal getTotaliamt() {
		return totaliamt;
	}

	public void setTotaliamt(BigDecimal totaliamt) {
		this.totaliamt = totaliamt;
	}

	public BigDecimal getTotalcamt() {
		return totalcamt;
	}

	public void setTotalcamt(BigDecimal totalcamt) {
		this.totalcamt = totalcamt;
	}

	public BigDecimal getTotalsamt() {
		return totalsamt;
	}

	public void setTotalsamt(BigDecimal totalsamt) {
		this.totalsamt = totalsamt;
	}

	public BigDecimal getTotalcsamt() {
		return totalcsamt;
	}

	public void setTotalcsamt(BigDecimal totalcsamt) {
		this.totalcsamt = totalcsamt;
	}

	public List<CdnaInvoiceDetailFlat> getCdnaInvoiceDetailFLat() {
		return cdnaInvoiceDetailFLat;
	}

	public void setCdnaInvoiceDetailFLat(List<CdnaInvoiceDetailFlat> cdnaInvoiceDetailFLat) {
		this.cdnaInvoiceDetailFLat = cdnaInvoiceDetailFLat;
	}
	private String ntNum;
	public String getNtNum() {
		return ntNum;
	}

	public void setNtNum(String ntNum) {
		this.ntNum = ntNum;
	}

	public String getNtDt() {
		return ntDt;
	}

	public void setNtDt(String ntDt) {
		this.ntDt = ntDt;
	}

	public Character getNtty() {
		return ntty;
	}

	public void setNtty(Character ntty) {
		this.ntty = ntty;
	}

	private String ntDt;
	private Character ntty;
	@Override
	public String toString() {
		return "CdnaInvoiceFlat [ctin=" + ctin + ", inum=" + inum + ", rchrg=" + rchrg + ", invTyp=" + invTyp + ", val="
				+ val + ", totaltxval=" + totaltxval + ", totaliamt=" + totaliamt + ", totalcamt="
				+ totalcamt + ", totalsamt=" + totalsamt + ", totalcsamt=" + totalcsamt + "]";
	}
	
	
}
