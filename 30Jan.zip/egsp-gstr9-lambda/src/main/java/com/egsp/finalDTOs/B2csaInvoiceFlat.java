package com.egsp.finalDTOs;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * The Class for B2csa Invoice.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class B2csaInvoiceFlat implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** GSTIN/UID of the Receiver taxpayer/UN, Govt Bodies. */
	private String ctin;

	/** Supplier Invoice Number. */
	private String inum;
	
	private List<B2csaInvoiceDetailFlat> b2csaInvoiceDetailFLat;
	/** Reverse Charge. */
	private Character rchrg = 'N';
	
	/** The Invoice type. */
	@JsonProperty("inv_typ")
	private String invTyp;
	

	/** Supplier Invoice Value. */
	private BigDecimal val;

	private BigDecimal totaltxval = new BigDecimal(0);
	
	private BigDecimal totaliamt = new BigDecimal(0);
	
	private BigDecimal totalcamt =new BigDecimal(0);
	
	private BigDecimal totalsamt =new BigDecimal(0);
	
	private BigDecimal totalcsamt = new BigDecimal(0);

	public String getCtin() {
		return ctin;
	}

	public void setCtin(String ctin) {
		this.ctin = ctin;
	}

	public String getInum() {
		return inum;
	}

	public void setInum(String inum) {
		this.inum = inum;
	}

	public Character getRchrg() {
		return rchrg;
	}

	public void setRchrg(Character rchrg) {
		this.rchrg = rchrg;
	}
	
	public String getInvTyp() {
		return invTyp;
	}

	public void setInvTyp(String invTyp) {
		this.invTyp = invTyp;
	}

	public BigDecimal getVal() {
		return val;
	}

	public void setVal(BigDecimal val) {
		this.val = val;
	}

	public BigDecimal getTotaltxval() {
		return totaltxval;
	}

	public void setTotaltxval(BigDecimal totaltxval) {
		this.totaltxval = totaltxval;
	}

	public BigDecimal getTotaliamt() {
		return totaliamt;
	}

	public void setTotaliamt(BigDecimal totaliamt) {
		this.totaliamt = totaliamt;
	}

	public BigDecimal getTotalcamt() {
		return totalcamt;
	}

	public void setTotalcamt(BigDecimal totalcamt) {
		this.totalcamt = totalcamt;
	}

	public BigDecimal getTotalsamt() {
		return totalsamt;
	}

	public void setTotalsamt(BigDecimal totalsamt) {
		this.totalsamt = totalsamt;
	}

	public BigDecimal getTotalcsamt() {
		return totalcsamt;
	}

	public void setTotalcsamt(BigDecimal totalcsamt) {
		this.totalcsamt = totalcsamt;
	}

	public List<B2csaInvoiceDetailFlat> getB2csaInvoiceDetailFLat() {
		return b2csaInvoiceDetailFLat;
	}

	public void setB2csaInvoiceDetailFLat(List<B2csaInvoiceDetailFlat> b2csaInvoiceDetailFLat) {
		this.b2csaInvoiceDetailFLat = b2csaInvoiceDetailFLat;
	}

	@Override
	public String toString() {
		return "B2csaInvoiceFlat [ctin=" + ctin + ", inum=" + inum + ", rchrg=" + rchrg + ", invTyp=" + invTyp + ", val="
				+ val + ", totaltxval=" + totaltxval + ", totaliamt=" + totaliamt + ", totalcamt="
				+ totalcamt + ", totalsamt=" + totalsamt + ", totalcsamt=" + totalcsamt + "]";
	}
	
	
}
