

package com.egsp.finalDTOs;

import java.io.Serializable;
import java.math.BigDecimal;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class TxpdaInvoiceFlatFinal implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** GSTIN/UID of the Receiver taxpayer/UN, Govt Bodies. */
	//private String ctin;
	private BigDecimal totaladAmt = new BigDecimal(0);

	public BigDecimal getTotaladAmt() {
		return totaladAmt;
	}
	
	private String omon;
	public String getOmon() {
		return omon;
	}

	/**
	 * Sets the Original Month
	 * 
	 * Field Specification: String(MMYYYY)
	 * 
	 * Sample Data: 032017
	 *
	 * @param typ
	 *            the new omon
	 */
	public void setOmon(String omon) {
		this.omon = omon;
	}


	public void setTotaladAmt(BigDecimal totaladAmt) {
		this.totaladAmt = totaladAmt;
	}
	/** Supplier Invoice Number. */
	//private String inum;
	
	private String businessType;
	/** Supplier Invoice Value. */
	//private BigDecimal val;
	
	/** Reverse Charge. */
	//private Character rchrg = 'N';
	
	/** The Invoice type. */
	@JsonProperty("inv_typ")
	//private String invTyp;
	
	private String fp;
	
	/** Supplier Invoice Date. */
	//private String idt;
	
	private BigDecimal totaltxval = new BigDecimal(0);
	
	private BigDecimal totaliamt = new BigDecimal(0);
	
	private BigDecimal totalcamt =new BigDecimal(0);
	
	private BigDecimal totalsamt =new BigDecimal(0);
	
	private BigDecimal totalcsamt = new BigDecimal(0);

	/*public String getCtin() {
		return ctin;
	}

	public void setCtin(String ctin) {
		this.ctin = ctin;
	}

	public String getInum() {
		return inum;
	}

	public void setInum(String inum) {
		this.inum = inum;
	}

	public BigDecimal getVal() {
		return val;
	}

	public void setVal(BigDecimal val) {
		this.val = val;
	}
*/
	/*public Character getRchrg() {
		return rchrg;
	}

	public void setRchrg(Character rchrg) {
		this.rchrg = rchrg;
	}*/
/*
	public String getInvTyp() {
		return invTyp;
	}

	public void setInvTyp(String invTyp) {
		this.invTyp = invTyp;
	}
*/
	/*public String getIdt() {
		return idt;
	}

	public void setIdt(String idt) {
		this.idt = idt;
	}
*/
	public BigDecimal getTotaltxval() {
		return totaltxval;
	}

	public void setTotaltxval(BigDecimal totaltxval) {
		this.totaltxval = totaltxval;
	}

	public BigDecimal getTotaliamt() {
		return totaliamt;
	}

	public void setTotaliamt(BigDecimal totaliamt) {
		this.totaliamt = totaliamt;
	}

	public BigDecimal getTotalcamt() {
		return totalcamt;
	}

	public void setTotalcamt(BigDecimal totalcamt) {
		this.totalcamt = totalcamt;
	}

	public BigDecimal getTotalsamt() {
		return totalsamt;
	}

	public void setTotalsamt(BigDecimal totalsamt) {
		this.totalsamt = totalsamt;
	}

	public BigDecimal getTotalcsamt() {
		return totalcsamt;
	}

	public void setTotalcsamt(BigDecimal totalcsamt) {
		this.totalcsamt = totalcsamt;
	}
	
	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public String getFp() {
		return fp;
	}

	public void setFp(String fp) {
		this.fp = fp;
	}
	
	@Override
	public String toString() {
		return "TxpdaInvoiceFlatFinal [ totaltxval=" + totaltxval + ", totaliamt=" + totaliamt
				+ ", totalcamt=" + totalcamt + ", totalsamt=" + totalsamt + ", totalcsamt=" + totalcsamt + "]";
	}
	
}
