

package com.egsp.finalDTOs;

import java.io.Serializable;
import java.math.BigDecimal;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class CdnraInvoiceFlatFinal implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** GSTIN/UID of the Receiver taxpayer/UN, Govt Bodies. */
	private String ctin;

	/** Supplier Invoice Number. */
	private String inum;
	
	private String businessType;
	/** Supplier Invoice Value. */
	private BigDecimal val;
	
	/** Reverse Charge. */
	//private Character rchrg = 'N';
	
	/** The Invoice type. */
	@JsonProperty("inv_typ")
	//private String invTyp;
	
	private String fp;
	
	/** Supplier Invoice Date. */
	private String idt;
	
	private BigDecimal totaltxval = new BigDecimal(0);
	
	private BigDecimal totaliamt = new BigDecimal(0);
	
	private BigDecimal totalcamt =new BigDecimal(0);
	
	private BigDecimal totalsamt =new BigDecimal(0);
	
	private BigDecimal totalcsamt = new BigDecimal(0);

	public String getCtin() {
		return ctin;
	}

	public void setCtin(String ctin) {
		this.ctin = ctin;
	}

	public String getInum() {
		return inum;
	}

	public void setInum(String inum) {
		this.inum = inum;
	}

	public BigDecimal getVal() {
		return val;
	}

	public void setVal(BigDecimal val) {
		this.val = val;
	}

	/*public Character getRchrg() {
		return rchrg;
	}

	public void setRchrg(Character rchrg) {
		this.rchrg = rchrg;
	}*/

	/*public String getInvTyp() {
		return invTyp;
	}

	public void setInvTyp(String invTyp) {
		this.invTyp = invTyp;
	}
*/
	public String getIdt() {
		return idt;
	}

	public void setIdt(String idt) {
		this.idt = idt;
	}

	public BigDecimal getTotaltxval() {
		return totaltxval;
	}

	public void setTotaltxval(BigDecimal totaltxval) {
		this.totaltxval = totaltxval;
	}

	public BigDecimal getTotaliamt() {
		return totaliamt;
	}

	public void setTotaliamt(BigDecimal totaliamt) {
		this.totaliamt = totaliamt;
	}

	public BigDecimal getTotalcamt() {
		return totalcamt;
	}

	public void setTotalcamt(BigDecimal totalcamt) {
		this.totalcamt = totalcamt;
	}

	public BigDecimal getTotalsamt() {
		return totalsamt;
	}

	public void setTotalsamt(BigDecimal totalsamt) {
		this.totalsamt = totalsamt;
	}

	public BigDecimal getTotalcsamt() {
		return totalcsamt;
	}

	public void setTotalcsamt(BigDecimal totalcsamt) {
		this.totalcsamt = totalcsamt;
	}
	
	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public String getFp() {
		return fp;
	}
	private String ontNum;
	public String getOntNum() {
		return ontNum;
	}

	public void setOntNum(String ontNum) {
		this.ontNum = ontNum;
	}
	@JsonProperty("nt_num")
	//private String invTyp;
	
	private String ntNum;
	public String getNtNum() {
		return ntNum;
	}

	public void setNtNum(String ntNum) {
		this.ntNum = ntNum;
	}

	public String getNtDt() {
		return ntDt;
	}

	public void setNtDt(String ntDt) {
		this.ntDt = ntDt;
	}

	public Character getNtty() {
		return ntty;
	}

	public void setNtty(Character ntty) {
		this.ntty = ntty;
	}

	private String ntDt;
	private Character ntty;
	

	public String getOntDt() {
		return ontDt;
	}

	public void setOntDt(String ontDt) {
		this.ontDt = ontDt;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private String ontDt;

	public void setFp(String fp) {
		this.fp = fp;
	}
	
	@Override
	public String toString() {
		return "CdnraInvoiceFlatFinal [ctin=" + ctin + ", inum=" + inum + ", val=" + val + ", idt=" + idt + ", totaltxval=" + totaltxval + ", totaliamt=" + totaliamt
				+ ", totalcamt=" + totalcamt + ", totalsamt=" + totalsamt + ", totalcsamt=" + totalcsamt + "]";
	}
	
}
