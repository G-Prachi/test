package com.mind.egsp.gstn.ledger;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.ledger.ClosingBalTaxLedger;
import com.mind.egsp.gstn.model.ledger.CreditSummary;
import com.mind.egsp.gstn.model.ledger.DebitSummary;
import com.mind.egsp.gstn.model.ledger.OpeningBalTaxLedgerSummary;

/**
 * The Class GetItcLedgerSummaryResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetItcLedgerSummaryResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The GSTIN of the Taxpayer. */
	private String gstin;

	/** The From Date. */
	@JsonProperty("fr_dt")
	private String frDt;

	/** The To Date. */
	@JsonProperty("to_dt")
	private String toDt;

	/** The Opening Balance. */
	@JsonProperty("op_bal")
	private OpeningBalTaxLedgerSummary opBal;

	/** The Closing Balance. */
	@JsonProperty("cl_bal")
	private ClosingBalTaxLedger clBal;

	/** The Credit. */
	@JsonProperty("cr")
	private List<CreditSummary> creditSummaries;

	/** The Debit. */
	@JsonProperty("db")
	private List<DebitSummary> debitSummaries;

	/**
	 * Gets the GSTIN of the Tax Payer.
	 *
	 * @return the GSTIN of the Tax Payer
	 */
	public String getGstin() {
		return gstin;
	}

	/**
	 * Sets the GSTIN of the Tax Payer.
	 *
	 * @param gstin
	 *            the new GSTIN of the Tax Payer
	 */
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the From Date.
	 *
	 * @return the From Date
	 */
	public String getFrDt() {
		return frDt;
	}

	/**
	 * Sets the From Date.
	 *
	 * @param frDt
	 *            the new From Date
	 */
	public void setFrDt(String frDt) {
		this.frDt = frDt;
	}

	/**
	 * Gets the To Date.
	 *
	 * @return the To Date
	 */
	public String getToDt() {
		return toDt;
	}

	/**
	 * Sets the To Date.
	 *
	 * @param toDt
	 *            the new To Date
	 */
	public void setToDt(String toDt) {
		this.toDt = toDt;
	}

	/**
	 * Gets the Opening Balance.
	 *
	 * @return the Opening Balance
	 */
	public OpeningBalTaxLedgerSummary getOpBal() {
		return opBal;
	}

	/**
	 * Sets the Opening Balance.
	 *
	 * @param opBal
	 *            the new Opening Balance
	 */
	public void setOpBal(OpeningBalTaxLedgerSummary opBal) {
		this.opBal = opBal;
	}

	/**
	 * Gets the Closing Balance.
	 *
	 * @return the Closing Balance
	 */
	public ClosingBalTaxLedger getClBal() {
		return clBal;
	}

	/**
	 * Sets the Closing Balance.
	 *
	 * @param clBal
	 *            the new Closing Balance
	 */
	public void setClBal(ClosingBalTaxLedger clBal) {
		this.clBal = clBal;
	}

	/**
	 * Gets the credit summaries.
	 *
	 * @return the credit summaries
	 */
	public List<CreditSummary> getCreditSummaries() {
		return creditSummaries;
	}

	/**
	 * Sets the credit summaries.
	 *
	 * @param creditSummaries
	 *            the new credit summaries
	 */
	public void setCreditSummaries(List<CreditSummary> creditSummaries) {
		this.creditSummaries = creditSummaries;
	}

	/**
	 * Gets the debit summaries.
	 *
	 * @return the debit summaries
	 */
	public List<DebitSummary> getDebitSummaries() {
		return debitSummaries;
	}

	/**
	 * Sets the debit summaries.
	 *
	 * @param debitSummaries
	 *            the new debit summaries
	 */
	public void setDebitSummaries(List<DebitSummary> debitSummaries) {
		this.debitSummaries = debitSummaries;
	}

}
