package com.mind.egsp.gstn.dto.gstr8;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Get B2Ba Invoices Response DTO.
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class Gstr8GetB2baInvoicesResponseDTO extends Gstr8GetB2bInvoicesResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
}
