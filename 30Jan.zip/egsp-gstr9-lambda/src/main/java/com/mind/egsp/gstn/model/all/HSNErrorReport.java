package com.mind.egsp.gstn.model.all;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.model.gstr1.HsnSummaryDetail;

/**
 * The Class HSNErrorReport.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class HSNErrorReport implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The Error Message .
	 */
	@JsonProperty("error_msg")
	private String errorMsg;

	/**
	 * The Error_cd .
	 */
	@JsonProperty("error_cd")
	private String errorCd;

	/**
	 * The HSN Summary List .
	 */
	@JsonProperty("data")
	private List<HsnSummaryDetail> hsnSummaryDetails;

	/**
	 * Gets the error msg.
	 *
	 * @return the error msg
	 */
	public String getErrorMsg() {
		return errorMsg;
	}

	/**
	 * Sets the error msg.
	 *
	 * @param errorMsg
	 *            the new error msg
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	/**
	 * Gets the error cd.
	 *
	 * @return the error cd
	 */
	public String getErrorCd() {
		return errorCd;
	}

	/**
	 * Sets the error cd.
	 *
	 * @param errorCd
	 *            the new error cd
	 */
	public void setErrorCd(String errorCd) {
		this.errorCd = errorCd;
	}

	/**
	 * Gets the hsn summary details.
	 *
	 * @return the hsn summary details
	 */
	public List<HsnSummaryDetail> getHsnSummaryDetails() {
		return hsnSummaryDetails;
	}

	/**
	 * Sets the hsn summary details.
	 *
	 * @param hsnSummaryDetails
	 *            the new hsn summary details
	 */
	public void setHsnSummaryDetails(List<HsnSummaryDetail> hsnSummaryDetails) {
		this.hsnSummaryDetails = hsnSummaryDetails;
	}


}
