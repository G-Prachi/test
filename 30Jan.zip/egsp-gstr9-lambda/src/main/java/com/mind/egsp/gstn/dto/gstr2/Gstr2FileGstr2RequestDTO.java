package com.mind.egsp.gstn.dto.gstr2;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mind.egsp.gstn.dto.BaseRequestDTO;
import com.mind.egsp.gstn.model.gstr2.Gstr2SummaryData;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Gstr2FileGstr2RequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The gstr 2 summary data. */
	private Gstr2SummaryData gstr2SummaryData;

	public Gstr2FileGstr2RequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	/**
	 * Gets the GSTR Summary
	 * 
	 * Field Specification: Gstr2 Summary Data
	 * 
	 * Mandatory: Y Sample Data: .
	 *
	 * @return the gstr 2 summary data
	 */
	public Gstr2SummaryData getGstrSummaryData() {
		return gstr2SummaryData;
	}

	/**
	 * Sets theGSTR Summary
	 * 
	 * Field Specification: Gstr2 Summary Data
	 * 
	 * Mandatory: Y Sample Data: .
	 *
	 * @param gstr1SummaryData
	 *            the new gstr 2 summary data
	 */
	public void setGstr2SummaryData(Gstr2SummaryData gstr2SummaryData) {
		this.gstr2SummaryData = gstr2SummaryData;
	}

	/**
	 * The PKCS#7 signature of SHA-256 hash of Base64 of response of
	 * getGSTR1Summary using private key of Tax Payer (Authorized signatory).
	 */
	private String sign;

	/** The Type of signature – DSC or ESIGN. */
	private String st;

	/**
	 * The PAN of authorized representative if st = DSC or AADHAR no. of
	 * authorized representative if st=ESIGN.
	 */
	private String sid;

	/**
	 * Gets the PKCS#7 signature of SHA-256 hash of Base64 of response of
	 * getGSTR1Summary using private key of Tax Payer (Authorized signatory)
	 * 
	 * Field Specification: String Mandatory: Y Sample Data: .
	 *
	 * @return the sign
	 */
	public String getSign() {
		return sign;
	}

	/**
	 * Sets the PKCS#7 signature of SHA-256 hash of Base64 of response of
	 * getGSTR1Summary using private key of Tax Payer (Authorized signatory)
	 * 
	 * Field Specification: String Mandatory: Y Sample Data: .
	 *
	 * @param sign
	 *            the new sign
	 */
	public void setSign(String sign) {
		this.sign = sign;
	}

	/**
	 * Gets the Type of signature – DSC or ESIGN
	 * 
	 * Field Specification: String (Maxlength:5)
	 * 
	 * Mandatory: Y Sample Data: DSC/ESIGN .
	 *
	 * @return the st
	 */
	public String getSt() {
		return st;
	}

	/**
	 * Sets the Type of signature – DSC or ESIGN
	 * 
	 * Field Specification: String (Maxlength:5)
	 * 
	 * Mandatory: Y Sample Data: DSC/ESIGN .
	 *
	 * @param st
	 *            the new st
	 */
	public void setSt(String st) {
		this.st = st;
	}

	/**
	 * Gets the PAN of authorized representative if st = DSC or AADHAR no. of
	 * authorized representative if st=ESIGN
	 * 
	 * Field Specification: Alphanumeric (Max Length:15)
	 * 
	 * Mandatory: Y Sample Data: .
	 *
	 * @return the sid
	 */
	public String getSid() {
		return sid;
	}

	/**
	 * Sets the PAN of authorized representative if st = DSC or AADHAR no. of
	 * authorized representative if st=ESIGN
	 * 
	 * Field Specification: Alphanumeric (Max Length:15)
	 * 
	 * Mandatory: Y Sample Data: .
	 *
	 * @param sid
	 *            the new sid
	 */
	public void setSid(String sid) {
		this.sid = sid;
	}

}
