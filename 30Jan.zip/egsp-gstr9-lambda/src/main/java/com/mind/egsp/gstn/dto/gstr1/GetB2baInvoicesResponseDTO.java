package com.mind.egsp.gstn.dto.gstr1;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr1.B2baInvoice;

/**
 * The Class GetB2baInvoicesResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetB2baInvoicesResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The B2ba invoices. */
	@JsonProperty("b2ba")
	private List<B2baInvoice> b2baInvoices;

	/** The Token. */
	private String token;

	/** The Estimated Time in minutes. */
	private String est;

	/**
	 * Gets the B2BA invoices.
	 *
	 * @return the B2BA invoices
	 */
	public List<B2baInvoice> getB2baInvoices() {
		return b2baInvoices;
	}

	/**
	 * Sets the B2BA invoices.
	 *
	 * @param b2baInvoices
	 *            the new B2BA invoices
	 */
	public void setB2baInvoices(List<B2baInvoice> b2baInvoices) {
		this.b2baInvoices = b2baInvoices;
	}

	/**
	 * Gets the token.
	 *
	 * Field Specification:String
	 *
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * Sets the token.
	 *
	 * Field Specification:String
	 *
	 * @param token
	 *            the new token
	 */
	public void setToken(String token) {
		this.token = token;
	}

	/**
	 * Gets the Estimated Time in minutes.
	 *
	 * Field Specification:String
	 *
	 * @return the est
	 */
	public String getEst() {
		return est;
	}

	/**
	 * Sets the Estimated Time in minutes.
	 *
	 * Field Specification:String
	 *
	 * @param est
	 *            the new est
	 */
	public void setEst(String est) {
		this.est = est;
	}

}
