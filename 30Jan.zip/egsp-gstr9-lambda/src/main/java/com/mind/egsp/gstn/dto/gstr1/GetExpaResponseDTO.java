package com.mind.egsp.gstn.dto.gstr1;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr1.ExpaInvoice;

// TODO: Auto-generated Javadoc
/**
 * The Class GetExpaResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetExpaResponseDTO extends BaseDataResponseDTO implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The expa invoice. */
	@JsonProperty("expa")
	private List<ExpaInvoice> expaInvoices;

	/**
	 * Gets the expa invoices.
	 *
	 * @return the expa invoices
	 */
	public List<ExpaInvoice> getExpaInvoices() {
		return expaInvoices;
	}

	/**
	 * Sets the expa invoices.
	 *
	 * @param expaInvoices
	 *            the new expa invoices
	 */
	public void setExpaInvoices(List<ExpaInvoice> expaInvoices) {
		this.expaInvoices = expaInvoices;
	}

}
