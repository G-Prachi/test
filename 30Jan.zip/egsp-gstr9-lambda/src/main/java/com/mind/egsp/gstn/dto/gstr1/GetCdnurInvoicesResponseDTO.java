package com.mind.egsp.gstn.dto.gstr1;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr1.CdnurInvoiceDetail;

/**
 * The Class GetCdnrInvoicesResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetCdnurInvoicesResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Credit Debit Note details. */
	@JsonProperty("cdnur")
	private List<CdnurInvoiceDetail> cdnurInvoiceDetails;

	/**
	 * Gets the cdnur invoice details.
	 *
	 * @return the cdnur invoice details
	 */
	public List<CdnurInvoiceDetail> getCdnurInvoiceDetails() {
		return cdnurInvoiceDetails;
	}

	/**
	 * Sets the cdnur invoice details.
	 *
	 * @param cdnurInvoiceDetails
	 *            the new cdnur invoice details
	 */
	public void setCdnurInvoiceDetails(List<CdnurInvoiceDetail> cdnurInvoiceDetails) {
		this.cdnurInvoiceDetails = cdnurInvoiceDetails;
	}

}
