package com.mind.egsp.gstn.dto.gstr3b;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;

/**
 * The Gstr1 Save Data Response DTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SaveGstr3bResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The reference id. */
	@JsonProperty("reference_id")
	private String referenceId;

	/** The trans id. */
	@JsonProperty("trans_id")
	private String transId;

	/**
	 * Gets the reference id.
	 *
	 * @return the reference id
	 */
	public String getReferenceId() {
		return referenceId;
	}

	/**
	 * Sets the reference id.
	 *
	 * @param referenceId
	 *            the new reference id
	 */
	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	/**
	 * Gets the trans id.
	 *
	 * @return the trans id
	 */
	public String getTransId() {
		return transId;
	}

	/**
	 * Sets the trans id.
	 *
	 * @param transId
	 *            the new trans id
	 */
	public void setTransId(String transId) {
		this.transId = transId;
	}

}
