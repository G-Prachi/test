package com.mind.egsp.gstn.dto.gstr3b;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;

// TODO: Auto-generated Javadoc
/**
 * The File Gstr3b Response DTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class FileGstr3bResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Acknowledgement Number. */
	@JsonProperty("ack_num")
	private String ackNum;

	/**
	 * Gets the ack num.
	 *
	 * @return the ack num
	 */
	public String getAckNum() {
		return ackNum;
	}

	/**
	 * Sets the ack num.
	 *
	 * @param ackNum
	 *            the new ack num
	 */
	public void setAckNum(String ackNum) {
		this.ackNum = ackNum;
	}

}
