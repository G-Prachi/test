package com.mind.egsp.gstn.dto.gstr1A;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.model.gstr1.B2bInvoice;
import com.mind.egsp.gstn.model.gstr1.B2baInvoice;
import com.mind.egsp.gstn.model.gstr1.CdnrInvoice;
import com.mind.egsp.gstn.model.gstr1.CdnraInvoice;

/**
 * The Gstr1a Save DTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class SaveGstr1aDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The GSTIN of the Tax Payer. */
	private String gstin;

	/** Financial period. */
	private String fp;

	/** B2B Invoices (represents table 5 of GSTR1). */
	@JsonProperty("b2b")
	private List<B2bInvoice> b2bInvoices;

	/** The b 2 ba invoice. */
	@JsonProperty("b2ba")
	private List<B2baInvoice> b2baInvoices;

	/** The Credit Debit Notes Registered Users invoice. */
	@JsonProperty("cdnr")
	private List<CdnrInvoice> cdnrInvoices;

	/** The amended Credit Debit Notes Registered Users invoice. */
	@JsonProperty("cdna")
	private List<CdnraInvoice> cdnraInvoices;

	/**
	 * Gets the gstin.
	 *
	 * @return the gstin
	 */
	public String getGstin() {
		return gstin;
	}

	/**
	 * Sets the gstin.
	 *
	 * @param gstin
	 *            the new gstin
	 */
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the fp.
	 *
	 * @return the fp
	 */
	public String getFp() {
		return fp;
	}

	/**
	 * Sets the fp.
	 *
	 * @param fp
	 *            the new fp
	 */
	public void setFp(String fp) {
		this.fp = fp;
	}

	/**
	 * Gets the B2B invoices.
	 *
	 * @return the B2B invoices
	 */

	public List<B2bInvoice> getB2bInvoices() {
		return b2bInvoices;
	}

	/**
	 * Sets the B2B invoices.
	 *
	 * @param b2bInvoices
	 *            the new B2B invoices
	 */
	public void setB2bInvoices(List<B2bInvoice> b2bInvoices) {
		this.b2bInvoices = b2bInvoices;
	}

	/**
	 * Gets the B2ba invoice.
	 *
	 * @return the B2ba invoice
	 */
	public List<B2baInvoice> getB2baInvoices() {
		return b2baInvoices;
	}

	/**
	 * Sets the B2ba invoice.
	 *
	 * @param b2baInvoices
	 *            the new b 2 ba invoices
	 */
	public void setB2baInvoices(List<B2baInvoice> b2baInvoices) {
		this.b2baInvoices = b2baInvoices;
	}

	/**
	 * Gets the Credit Debit Notes Registered Users invoices.
	 *
	 * @return the Credit Debit Notes Registered Users invoices
	 */
	public List<CdnrInvoice> getCdnrInvoices() {
		return cdnrInvoices;
	}

	/**
	 * Sets the Credit Debit Notes Registered Users invoices.
	 *
	 * @param cdnrInvoices
	 *            the new Credit Debit Notes Registered Users invoices
	 */
	public void setCdnrInvoices(List<CdnrInvoice> cdnrInvoices) {
		this.cdnrInvoices = cdnrInvoices;
	}

	/**
	 * Gets the cdnra invoices.
	 *
	 * @return the cdnra invoices
	 */
	public List<CdnraInvoice> getCdnraInvoices() {
		return cdnraInvoices;
	}

	/**
	 * Sets the cdnra invoices.
	 *
	 * @param cdnraInvoices
	 *            the new cdnra invoices
	 */
	public void setCdnraInvoices(List<CdnraInvoice> cdnraInvoices) {
		this.cdnraInvoices = cdnraInvoices;
	}

}
