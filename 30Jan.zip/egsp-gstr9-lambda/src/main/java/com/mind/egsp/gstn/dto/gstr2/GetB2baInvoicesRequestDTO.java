package com.mind.egsp.gstn.dto.gstr2;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

/**
 * The Class GetB2baInvoicesRequestDTO.
 */

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetB2baInvoicesRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The actionRequired URL Parameter. */
	private String actionRequired;

	/** The Counter party GSTIN */
	private String ctin;

	public GetB2baInvoicesRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	/**
	 * Gets the action required.
	 *
	 * Field Specification:Character (Y/N)
	 * 
	 * Mandatory: N Sample Data: Y
	 *
	 * @return the action required
	 */
	public String getActionRequired() {
		return actionRequired;
	}

	/**
	 * Sets the action required.
	 *
	 * Field Specification:Character (Y/N)
	 * 
	 * Mandatory: N Sample Data: Y
	 *
	 * @param actionRequired
	 *            the new action required
	 */
	public void setActionRequired(String actionRequired) {
		this.actionRequired = actionRequired;
	}

	/**
	 * Gets the Counter party GSTIN.
	 *
	 * Field Specification:Alphanumeric with 15 characters
	 * 
	 * Mandatory: N Sample Data: 20GRRHF2562D3A3
	 *
	 * @return the ctin
	 */
	public String getCtin() {
		return ctin;
	}

	/**
	 * Sets the Counter party GSTIN.
	 *
	 * Field Specification:Alphanumeric with 15 characters
	 * 
	 * Mandatory: N Sample Data: 20GRRHF2562D3A3
	 *
	 * @return the ctin
	 */

	public void setCtin(String ctin) {
		this.ctin = ctin;
	}

}
