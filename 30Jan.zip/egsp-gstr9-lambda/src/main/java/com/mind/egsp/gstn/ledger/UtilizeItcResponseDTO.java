package com.mind.egsp.gstn.ledger;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseResponseDTO;
import com.mind.egsp.gstn.model.ledger.ItcUtilizationDetail;

/**
 * The Class UtilizeItcResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class UtilizeItcResponseDTO extends BaseResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Status Code. */
	private String stscd;

	/** The Debit Number. */
	@JsonProperty("db_no")
	private String dbNo;

	/** The ITC Utilization. */
	@JsonProperty("itc_utl")
	private ItcUtilizationDetail itcUtilizationDetail;

	/**
	 * Gets the Status Code.
	 *
	 * @return the Status Code
	 */
	public String getStscd() {
		return stscd;
	}

	/**
	 * Sets the Status Code.
	 *
	 * @param stscd
	 *            the new Status Code
	 */
	public void setStscd(String stscd) {
		this.stscd = stscd;
	}

	/**
	 * Gets the Debit Number.
	 *
	 * @return the Debit Number
	 */
	public String getDbNo() {
		return dbNo;
	}

	/**
	 * Sets the Debit Number.
	 *
	 * @param dbNo
	 *            the new Debit Number
	 */
	public void setDbNo(String dbNo) {
		this.dbNo = dbNo;
	}

	/**
	 * Gets the itc utilization detail.
	 *
	 * @return the itc utilization detail
	 */
	public ItcUtilizationDetail getItcUtilizationDetail() {
		return itcUtilizationDetail;
	}

	/**
	 * Sets the itc utilization detail.
	 *
	 * @param itcUtilizationDetail
	 *            the new itc utilization detail
	 */
	public void setItcUtilizationDetail(ItcUtilizationDetail itcUtilizationDetail) {
		this.itcUtilizationDetail = itcUtilizationDetail;
	}

}
