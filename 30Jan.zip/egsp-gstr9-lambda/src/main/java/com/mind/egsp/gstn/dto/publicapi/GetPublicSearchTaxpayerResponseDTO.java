package com.mind.egsp.gstn.dto.publicapi;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * The Class GetSearchTaxpayerResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class GetPublicSearchTaxpayerResponseDTO implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	/**
	 * GSTIN of the Tax Payer .
	 */
	private String gstin;
	/** Legal Name of Business. */
	private String lgnm;

	/** State Jurisdiction. */
	private String stj;
	/** Centre Jurisdiction. */
	private String ctj;
	/** Date of Registration. */
	private String rgdt;
	/** Constitution of Business. */
	private String ctb;

	/** Taxpayer type. */
	private String dty;

	/** Nature of Business Activity. */
	private List<String> nba;

	/** GSTN status. */
	private String sts;

	/** Date Of Cancellation. */
	private String cxdt;

	/** Last Updated Date. */
	private String lstupdt;

	/** State Jurisdiction Code. */
	private String stjCd;

	/** Centre Jurisdiction Code. */
	private String ctjCd;

	/**
	 * Gets the gstin.
	 *
	 * @return the gstin
	 */
	public String getGstin() {
		return gstin;
	}

	/**
	 * Sets the gstin.
	 *
	 * @param gstin
	 *            the new gstin
	 */
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the lgnm.
	 *
	 * @return the lgnm
	 */
	public String getLgnm() {
		return lgnm;
	}

	/**
	 * Sets the lgnm.
	 *
	 * @param lgnm
	 *            the new lgnm
	 */
	public void setLgnm(String lgnm) {
		this.lgnm = lgnm;
	}

	/**
	 * Gets the stj.
	 *
	 * @return the stj
	 */
	public String getStj() {
		return stj;
	}

	/**
	 * Sets the stj.
	 *
	 * @param stj
	 *            the new stj
	 */
	public void setStj(String stj) {
		this.stj = stj;
	}

	/**
	 * Gets the ctj.
	 *
	 * @return the ctj
	 */
	public String getCtj() {
		return ctj;
	}

	/**
	 * Sets the ctj.
	 *
	 * @param ctj
	 *            the new ctj
	 */
	public void setCtj(String ctj) {
		this.ctj = ctj;
	}


	/**
	 * Gets the rgdt.
	 *
	 * @return the rgdt
	 */
	public String getRgdt() {
		return rgdt;
	}

	/**
	 * Sets the rgdt.
	 *
	 * @param rgdt
	 *            the new rgdt
	 */
	public void setRgdt(String rgdt) {
		this.rgdt = rgdt;
	}

	/**
	 * Gets the ctb.
	 *
	 * @return the ctb
	 */
	public String getCtb() {
		return ctb;
	}

	/**
	 * Sets the ctb.
	 *
	 * @param ctb
	 *            the new ctb
	 */
	public void setCtb(String ctb) {
		this.ctb = ctb;
	}

	/**
	 * Gets the dty.
	 *
	 * @return the dty
	 */
	public String getDty() {
		return dty;
	}

	/**
	 * Sets the dty.
	 *
	 * @param dty
	 *            the new dty
	 */
	public void setDty(String dty) {
		this.dty = dty;
	}

	/**
	 * Gets the nba.
	 *
	 * @return the nba
	 */
	public List<String> getNba() {
		return nba;
	}

	/**
	 * Sets the nba.
	 *
	 * @param nba
	 *            the new nba
	 */
	public void setNba(List<String> nba) {
		this.nba = nba;
	}

	/**
	 * Gets the sts.
	 *
	 * @return the sts
	 */
	public String getSts() {
		return sts;
	}

	/**
	 * Sets the sts.
	 *
	 * @param sts
	 *            the new sts
	 */
	public void setSts(String sts) {
		this.sts = sts;
	}


	/**
	 * Gets the cxdt.
	 *
	 * @return the cxdt
	 */
	public String getCxdt() {
		return cxdt;
	}

	/**
	 * Sets the cxdt.
	 *
	 * @param cxdt
	 *            the new cxdt
	 */
	public void setCxdt(String cxdt) {
		this.cxdt = cxdt;
	}

	/**
	 * Gets the lstupdt.
	 *
	 * @return the lstupdt
	 */
	public String getLstupdt() {
		return lstupdt;
	}

	/**
	 * Sets the lstupdt.
	 *
	 * @param lstupdt
	 *            the new lstupdt
	 */
	public void setLstupdt(String lstupdt) {
		this.lstupdt = lstupdt;
	}

	/**
	 * Gets the stj cd.
	 *
	 * @return the stj cd
	 */
	public String getStjCd() {
		return stjCd;
	}

	/**
	 * Sets the stj cd.
	 *
	 * @param stjCd
	 *            the new stj cd
	 */
	public void setStjCd(String stjCd) {
		this.stjCd = stjCd;
	}

	/**
	 * Gets the ctj cd.
	 *
	 * @return the ctj cd
	 */
	public String getCtjCd() {
		return ctjCd;
	}

	/**
	 * Sets the ctj cd.
	 *
	 * @param ctjCd
	 *            the new ctj cd
	 */
	public void setCtjCd(String ctjCd) {
		this.ctjCd = ctjCd;
	}

}
