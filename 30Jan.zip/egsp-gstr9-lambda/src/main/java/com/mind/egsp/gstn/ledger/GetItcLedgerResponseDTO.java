package com.mind.egsp.gstn.ledger;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.model.ledger.ITCLedgerDetails;
import com.mind.egsp.gstn.model.ledger.ProvisionalCreditBalanceLst;

/**
 * The Class GetItcLedgerResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class GetItcLedgerResponseDTO implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The i TC ledger details. */
	@JsonProperty("itcLdgDtls")
	private ITCLedgerDetails iTCLedgerDetails;

	/** The provisional credit balance. */
	@JsonProperty("provCrdBalList")
	private ProvisionalCreditBalanceLst provisionalCreditBalanceLst;

	/** The error msg. */
	private String errorMsg;

	/**
	 * Gets the i TC ledger details.
	 *
	 * @return the i TC ledger details
	 */
	public ITCLedgerDetails getiTCLedgerDetails() {
		return iTCLedgerDetails;
	}

	/**
	 * Sets the i TC ledger details.
	 *
	 * @param iTCLedgerDetails
	 *            the new i TC ledger details
	 */
	public void setiTCLedgerDetails(ITCLedgerDetails iTCLedgerDetails) {
		this.iTCLedgerDetails = iTCLedgerDetails;
	}

	public ProvisionalCreditBalanceLst getProvisionalCreditBalanceLst() {
		return provisionalCreditBalanceLst;
	}

	public void setProvisionalCreditBalanceLst(ProvisionalCreditBalanceLst provisionalCreditBalanceLst) {
		this.provisionalCreditBalanceLst = provisionalCreditBalanceLst;
	}

	/**
	 * Gets the error msg.
	 *
	 * @return the error msg
	 */
	public String getErrorMsg() {
		return errorMsg;
	}

	/**
	 * Sets the error msg.
	 *
	 * @param errorMsg
	 *            the new error msg
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

}
