package com.mind.egsp.gstn.dto.gstr2;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

/**
 * The Gstr2 Save Data Request DTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Gstr2GetRetStatusRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** reference id of the transaction. */
	@JsonIgnore
	private String intTranId;

	public Gstr2GetRetStatusRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	public String getIntTranId() {
		return intTranId;
	}

	public void setIntTranId(String intTranId) {
		this.intTranId = intTranId;
	}

}
