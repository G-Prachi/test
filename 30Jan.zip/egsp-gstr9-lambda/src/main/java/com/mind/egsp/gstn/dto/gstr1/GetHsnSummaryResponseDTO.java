package com.mind.egsp.gstn.dto.gstr1;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr1.HsnSummary;


/**
 * The Class GetHsnSummaryDetailsResponseDTO.
 */

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetHsnSummaryResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The get hsn data. */
	@JsonProperty("hsn")
	private HsnSummary hsnSummaries;

	/**
	 * Gets the hsn summaries.
	 *
	 * @return the hsn summaries
	 */
	public HsnSummary getHsnSummaries() {
		return hsnSummaries;
	}

	/**
	 * Sets the hsn summaries.
	 *
	 * @param hsnSummaries
	 *            the new hsn summaries
	 */
	public void setHsnSummaries(HsnSummary hsnSummaries) {
		this.hsnSummaries = hsnSummaries;
	}


}
