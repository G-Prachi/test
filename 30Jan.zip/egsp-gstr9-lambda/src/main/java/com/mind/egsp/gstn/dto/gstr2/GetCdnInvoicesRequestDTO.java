package com.mind.egsp.gstn.dto.gstr2;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetCdnInvoicesRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The Status filter for filtering the invoices. Action_required = Y,
	 * fetches the invoices where tax payer need to take action (Accept/Reject).
	 * Already accepted or uploaded invoices can be fetched by using
	 * action_required=N filter. .
	 */
	private String actionRequired;

	/** The Counter party GSTIN. */
	private String ctin;

	/** from which time taxpayer want Invoices. */
	private String fromTime;

	public GetCdnInvoicesRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	/**
	 * Gets GSTIN of the taxpayer.
	 *
	 * @return the action required
	 */
	public String getActionRequired() {
		return actionRequired;
	}

	/**
	 * Status filter for filtering the invoices. Action_required = Y, fetches
	 * the invoices where tax payer need to take action (Accept/Reject). Already
	 * accepted or uploaded invoices can be fetched by using action_required=N
	 * filter.
	 * 
	 * Field Specification: Character (Y/N), Mandatory: N
	 *
	 * @param actionRequired
	 *            the new action required
	 */
	public void setActionRequired(String actionRequired) {
		this.actionRequired = actionRequired;
	}

	/**
	 * Gets the ctin.
	 *
	 * @return the ctin
	 */
	public String getCtin() {
		return ctin;
	}

	/**
	 * Sets the Counter party GSTIN.
	 * 
	 * Field Specification: Alphanumeric with 15 characters, Mandatory: N
	 *
	 * @param ctin
	 *            the new ctin
	 */
	public void setCtin(String ctin) {
		this.ctin = ctin;
	}

	/**
	 * Gets the from time.
	 *
	 * @return the from time
	 */
	public String getFromTime() {
		return fromTime;
	}

	/**
	 * Sets the from time which taxpayer want Invoices.
	 * 
	 * Field Specification: String (dd-mm-yyyy:hh) 13 Characters, Mandatory: N
	 *
	 * @param fromTime
	 *            the new from time
	 */
	public void setFromTime(String fromTime) {
		this.fromTime = fromTime;
	}

}
