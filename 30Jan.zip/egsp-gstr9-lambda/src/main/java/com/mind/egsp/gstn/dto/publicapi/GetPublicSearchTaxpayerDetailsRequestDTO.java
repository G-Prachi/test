package com.mind.egsp.gstn.dto.publicapi;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mind.egsp.gstn.dto.BaseRequestDTO;


/**
 * The Class GetSearchTaxpayerDetailsRequestDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class GetPublicSearchTaxpayerDetailsRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new gets the search taxpayer details request DTO.
	 *
	 * @param username
	 *            the username
	 * @param password
	 *            the password
	 * @param gstin
	 *            the gstin
	 */
	public GetPublicSearchTaxpayerDetailsRequestDTO(String username, String password, String gstin) {
		super(username, password, gstin);
	}

	/** The from gstin. */
	@JsonIgnore
	private String fromGstin;

	/**
	 * Gets the from gstin.
	 *
	 * @return the from gstin
	 */
	public String getFromGstin() {
		return fromGstin;
	}

	/**
	 * Sets the from gstin.
	 *
	 * @param fromGstin
	 *            the new from gstin
	 */
	public void setFromGstin(String fromGstin) {
		this.fromGstin = fromGstin;
	}

}
