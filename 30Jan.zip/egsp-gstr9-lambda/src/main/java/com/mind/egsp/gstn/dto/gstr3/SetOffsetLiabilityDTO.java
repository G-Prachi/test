package com.mind.egsp.gstn.dto.gstr3;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.model.gstr3.TaxPaid;

/**
 * The Class SetOffsetLiabilityDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)

public class SetOffsetLiabilityDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The tax paid. */
	@JsonProperty("tpm")
	TaxPaid taxPaid;

	/**
	 * Gets the tax paid.
	 *
	 * @return the tax paid
	 */
	public TaxPaid getTaxPaid() {
		return taxPaid;
	}

	/**
	 * Sets the tax paid.
	 *
	 * @param taxPaid
	 *            the new tax paid
	 */
	public void setTaxPaid(TaxPaid taxPaid) {
		this.taxPaid = taxPaid;
	}

}
