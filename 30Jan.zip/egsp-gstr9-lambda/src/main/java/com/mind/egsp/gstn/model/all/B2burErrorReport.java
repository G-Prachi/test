package com.mind.egsp.gstn.model.all;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.model.gstr2.Gstr2B2burInvoiceDetail;

// TODO: Auto-generated Javadoc
/**
 * The Class B2burErrorReport.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class B2burErrorReport implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The B2B Invoice. */
	@JsonProperty("inv")
	private List<Gstr2B2burInvoiceDetail> gstr2b2burInvoiceDetails;

	/**
	 * The Error_cd .
	 */
	@JsonProperty("error_cd")
	private String errorCd;

	/**
	 * The Error Message .
	 */
	@JsonProperty("error_msg")
	private String errorMsg;

	/**
	 * Gets the Error_cd Field Specification: Alphanumeric (Max length:10)
	 * Sample Data: RET100 .
	 *
	 * @return the error cd
	 */
	public String getErrorCd() {
		return errorCd;
	}

	/**
	 * Sets the Error_cd Field Specification: Alphanumeric (Max length:10)
	 * Sample Data: RET100 .
	 *
	 * @param errorCd
	 *            the new error cd
	 */
	public void setErrorCd(String errorCd) {
		this.errorCd = errorCd;
	}

	/**
	 * Gets the Error Message Field Specification: Alphanumeric (Max length:100)
	 * Sample Data: Duplicate Invoice .
	 *
	 * @return the error msg
	 */
	public String getErrorMsg() {
		return errorMsg;
	}

	/**
	 * Sets the Error Message Field Specification: Alphanumeric (Max length:100)
	 * Sample Data: Duplicate Invoice .
	 *
	 * @param errorMsg
	 *            the new error msg
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	/**
	 * Gets the gstr 2 b 2 bur invoice details.
	 *
	 * @return the gstr 2 b 2 bur invoice details
	 */
	public List<Gstr2B2burInvoiceDetail> getGstr2b2burInvoiceDetails() {
		return gstr2b2burInvoiceDetails;
	}

	/**
	 * Sets the gstr 2 b 2 bur invoice details.
	 *
	 * @param gstr2b2burInvoiceDetails
	 *            the new gstr 2 b 2 bur invoice details
	 */
	public void setGstr2b2burInvoiceDetails(List<Gstr2B2burInvoiceDetail> gstr2b2burInvoiceDetails) {
		this.gstr2b2burInvoiceDetails = gstr2b2burInvoiceDetails;
	}

}
