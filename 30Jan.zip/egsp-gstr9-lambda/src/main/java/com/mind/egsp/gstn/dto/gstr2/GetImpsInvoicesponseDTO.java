package com.mind.egsp.gstn.dto.gstr2;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr2.ImpsInvoiceDetail;

/**
 * The Class GetImpOfServicesBillsResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetImpsInvoicesponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The imps invoice detail. */
	@JsonProperty("imp_s")
	private List<ImpsInvoiceDetail> impsInvoiceDetails;

	/**
	 * Gets the imps invoice details.
	 *
	 * @return the imps invoice details
	 */
	public List<ImpsInvoiceDetail> getImpsInvoiceDetails() {
		return impsInvoiceDetails;
	}

	/**
	 * Sets the imps invoice details.
	 *
	 * @param impsInvoiceDetails
	 *            the new imps invoice details
	 */
	public void setImpsInvoiceDetails(List<ImpsInvoiceDetail> impsInvoiceDetails) {
		this.impsInvoiceDetails = impsInvoiceDetails;
	}

}
