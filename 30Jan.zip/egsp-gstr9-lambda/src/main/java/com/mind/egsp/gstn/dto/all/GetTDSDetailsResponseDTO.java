package com.mind.egsp.gstn.dto.all;

import java.io.Serializable;
import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseResponseDTO;

/**
 * The Class GetTDSDetailsResponseDTO.
 */
public class GetTDSDetailsResponseDTO extends BaseResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The GSTIN of purchaser .
	 */
	private String gstin;

	/**
	 * The Invoice Number .
	 */
	@JsonProperty("inv_num")
	private String invNum;

	/**
	 * The Invoice Date .
	 */
	@JsonProperty("inv_dt")
	private BigDecimal invDt;

	/**
	 * The Invoice Value .
	 */
	@JsonProperty("inv_val")
	private BigDecimal invVal;

	/**
	 * The Tax Deducted at Source (As per GSTR 7 of deductor) .
	 */
	private BigDecimal tds;

	/**
	 * The IGST -Actual Amount .
	 */
	private BigDecimal igac;

	/**
	 * The IGST – Claimed Amount .
	 */
	private BigDecimal igcl;

	/**
	 * The CGST -Actual Amount .
	 */
	private BigDecimal cgac;

	/**
	 * The CGST – Claimed Amount .
	 */
	private BigDecimal cgcl;

	/**
	 * The SGST -Actual Amount .
	 */
	private BigDecimal sgac;

	/**
	 * The SGST – Claimed Amount .
	 */
	private BigDecimal sgcl;

	/**
	 * The Month and year in which credit received .
	 */
	private BigDecimal crdt;

	/**
	 * Gets the GSTIN of purchaser Field Specification: String (15 characters)
	 * Sample Data: 07ABCSR6898M5Z4 .
	 *
	 * @return the gstin
	 */
	public String getGstin() {
		return gstin;
	}

	/**
	 * Sets the GSTIN of purchaser Field Specification: String (15 characters)
	 * Sample Data: 07ABCSR6898M5Z4 .
	 *
	 * @param gstin
	 *            the new gstin
	 */
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the Invoice Number Field Specification: Alphanumeric (Max length:50
	 * Sample Data: 43628451 .
	 *
	 * @return the inv num
	 */
	public String getInvNum() {
		return invNum;
	}

	/**
	 * Sets the Invoice Number Field Specification: Alphanumeric (Max length:50
	 * Sample Data: 43628451 .
	 *
	 * @param invNum
	 *            the new inv num
	 */
	public void setInvNum(String invNum) {
		this.invNum = invNum;
	}

	/**
	 * Gets the Invoice Date Field Specification: Date [DD-MM-YYYY] Sample Data:
	 * 06-07-2016 .
	 *
	 * @return the inv dt
	 */
	public BigDecimal getInvDt() {
		return invDt;
	}

	/**
	 * Sets the Invoice Date Field Specification: Date [DD-MM-YYYY] Sample Data:
	 * 06-07-2016 .
	 *
	 * @param invDt
	 *            the new inv dt
	 */
	public void setInvDt(BigDecimal invDt) {
		this.invDt = invDt;
	}

	/**
	 * Gets the Invoice Value Field Specification: Decimal(p,2) Sample Data:
	 * 3800 .
	 *
	 * @return the inv val
	 */
	public BigDecimal getInvVal() {
		return invVal;
	}

	/**
	 * Sets the Invoice Value Field Specification: Decimal(p,2) Sample Data:
	 * 3800 .
	 *
	 * @param invVal
	 *            the new inv val
	 */
	public void setInvVal(BigDecimal invVal) {
		this.invVal = invVal;
	}

	/**
	 * Gets the Tax Deducted at Source (As per GSTR 7 of deductor) Field
	 * Specification: Decimal(p,2) Sample Data: 2500 .
	 *
	 * @return the tds
	 */
	public BigDecimal getTds() {
		return tds;
	}

	/**
	 * Sets the Tax Deducted at Source (As per GSTR 7 of deductor) Field
	 * Specification: Decimal(p,2) Sample Data: 2500 .
	 *
	 * @param tds
	 *            the new tds
	 */
	public void setTds(BigDecimal tds) {
		this.tds = tds;
	}

	/**
	 * Gets the IGST -Actual Amount Field Specification: Decimal(p,2) Sample
	 * Data: 0 .
	 *
	 * @return the igac
	 */
	public BigDecimal getIgac() {
		return igac;
	}

	/**
	 * Sets the IGST -Actual Amount Field Specification: Decimal(p,2) Sample
	 * Data: 0 .
	 *
	 * @param igac
	 *            the new igac
	 */
	public void setIgac(BigDecimal igac) {
		this.igac = igac;
	}

	/**
	 * Gets the IGST – Claimed Amount Field Specification: Decimal(p,2) Sample
	 * Data: 0 .
	 *
	 * @return the igcl
	 */
	public BigDecimal getIgcl() {
		return igcl;
	}

	/**
	 * Sets the IGST – Claimed Amount Field Specification: Decimal(p,2) Sample
	 * Data: 0 .
	 *
	 * @param igcl
	 *            the new igcl
	 */
	public void setIgcl(BigDecimal igcl) {
		this.igcl = igcl;
	}

	/**
	 * Gets the CGST -Actual Amount Field Specification: Decimal(p,2) Sample
	 * Data: 1000 .
	 *
	 * @return the cgac
	 */
	public BigDecimal getCgac() {
		return cgac;
	}

	/**
	 * Sets the CGST -Actual Amount Field Specification: Decimal(p,2) Sample
	 * Data: 1000 .
	 *
	 * @param cgac
	 *            the new cgac
	 */
	public void setCgac(BigDecimal cgac) {
		this.cgac = cgac;
	}

	/**
	 * Gets the CGST – Claimed Amount Field Specification: Decimal(p,2) Sample
	 * Data: 1000 .
	 *
	 * @return the cgcl
	 */
	public BigDecimal getCgcl() {
		return cgcl;
	}

	/**
	 * Sets the CGST – Claimed Amount Field Specification: Decimal(p,2) Sample
	 * Data: 1000 .
	 *
	 * @param cgcl
	 *            the new cgcl
	 */
	public void setCgcl(BigDecimal cgcl) {
		this.cgcl = cgcl;
	}

	/**
	 * Gets the SGST -Actual Amount Field Specification: Decimal(p,2) Sample
	 * Data: 1500.
	 *
	 * @return the sgac
	 */
	public BigDecimal getSgac() {
		return sgac;
	}

	/**
	 * Sets the SGST -Actual Amount Field Specification: Decimal(p,2) Sample
	 * Data: 1500 .
	 *
	 * @param sgac
	 *            the new sgac
	 */
	public void setSgac(BigDecimal sgac) {
		this.sgac = sgac;
	}

	/**
	 * Gets the SGST – Claimed Amount Field Specification: Decimal(p,2) Sample
	 * Data: 1500 .
	 *
	 * @return the sgcl
	 */
	public BigDecimal getSgcl() {
		return sgcl;
	}

	/**
	 * Sets the SGST – Claimed Amount Field Specification: Decimal(p,2) Sample
	 * Data: 1500 .
	 *
	 * @param sgcl
	 *            the new sgcl
	 */
	public void setSgcl(BigDecimal sgcl) {
		this.sgcl = sgcl;
	}

	/**
	 * Gets the Month and year in which credit received Field Specification:
	 * Date [MM/YYYY] Sample Data: 42522 .
	 *
	 * @return the crdt
	 */
	public BigDecimal getCrdt() {
		return crdt;
	}

	/**
	 * Sets the Month and year in which credit received Field Specification:
	 * Date [MM/YYYY] Sample Data: 42522 .
	 *
	 * @param crdt
	 *            the new crdt
	 */
	public void setCrdt(BigDecimal crdt) {
		this.crdt = crdt;
	}
}
