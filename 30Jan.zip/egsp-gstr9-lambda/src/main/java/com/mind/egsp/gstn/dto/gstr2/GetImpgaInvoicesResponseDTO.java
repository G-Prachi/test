package com.mind.egsp.gstn.dto.gstr2;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr2.ImpgaInvoiceDetail;

/**
 * The Class GetAmmendedImpOfGoodsInvoicesResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetImpgaInvoicesResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Token. */
	private String token;

	/** The Estimated Time in minutes. */
	private String est;

	/** The i MPG invoice detail. */
	@JsonProperty("imp_ga")
	private List<ImpgaInvoiceDetail> impgaInvoiceDetails;

	/**
	 * Gets the impga invoice details.
	 *
	 * @return the impga invoice details
	 */
	public List<ImpgaInvoiceDetail> getImpgaInvoiceDetails() {
		return impgaInvoiceDetails;
	}

	/**
	 * Sets the impga invoice details.
	 *
	 * @param impgaInvoiceDetails
	 *            the new impga invoice details
	 */
	public void setImpgaInvoiceDetails(List<ImpgaInvoiceDetail> impgaInvoiceDetails) {
		this.impgaInvoiceDetails = impgaInvoiceDetails;
	}

	/**
	 * Gets the token.
	 *
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * Sets the token.
	 *
	 * @param token
	 *            the new token
	 */
	public void setToken(String token) {
		this.token = token;
	}

	/**
	 * Gets the Estimated Time in minutes.
	 *
	 * @return the est
	 */
	public String getEst() {
		return est;
	}

	/**
	 * Sets the Estimated Time in minutes.
	 *
	 * @param est
	 *            the new est
	 */
	public void setEst(String est) {
		this.est = est;
	}
}
