package com.mind.egsp.gstn.dto.gstr8;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

/**
 * The Class GetB2caInvoicesRequestDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Gstr8GetB2caInvoicesRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	// Doubt : Their is no necessary of statecd in the excel file so mentioning
	// it is worth it or not
	public Gstr8GetB2caInvoicesRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}
}
