package com.mind.egsp.gstn.dto.gstr8;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

// TODO: Auto-generated Javadoc
/**
 * The Class Gstr8GetTcsaInvoicesRequestDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Gstr8GetTcsaInvoicesRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new gstr 8 get tcs invoices request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param gstin
	 *            the gstin
	 * @param retPeriod
	 *            the ret period
	 * @param username
	 *            the username
	 */
	public Gstr8GetTcsaInvoicesRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}
}
