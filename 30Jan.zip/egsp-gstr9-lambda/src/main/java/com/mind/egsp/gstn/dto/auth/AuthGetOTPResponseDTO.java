package com.mind.egsp.gstn.dto.auth;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mind.egsp.gstn.dto.BaseResponseDTO;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AuthGetOTPResponseDTO extends BaseResponseDTO implements Serializable {
	private static final long serialVersionUID = 1L;

}
