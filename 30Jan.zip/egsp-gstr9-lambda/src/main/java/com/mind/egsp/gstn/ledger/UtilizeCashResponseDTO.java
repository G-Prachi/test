package com.mind.egsp.gstn.ledger;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseResponseDTO;

// TODO: Auto-generated Javadoc
/**
 * The Class GetCashLedgerDetailsResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class UtilizeCashResponseDTO extends BaseResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Status Code. */
	@JsonProperty("stscd")
	private String stsCd;

	/** The Debit Number. */
	@JsonProperty("db_no")
	private String dbNo;

	/**
	 * Gets the Status Code.
	 *
	 * @return the Status Code
	 */
	public String getStsCd() {
		return stsCd;
	}

	/**
	 * Sets the Status Code.
	 *
	 * @param stsCd
	 *            the new Status Code
	 */
	public void setStsCd(String stsCd) {
		this.stsCd = stsCd;
	}

	/**
	 * Gets the Debit Number.
	 *
	 * @return the Debit Number
	 */
	public String getDbNo() {
		return dbNo;
	}

	/**
	 * Sets the Debit Number.
	 *
	 * @param dbNo
	 *            the new Debit Number
	 */
	public void setDbNo(String dbNo) {
		this.dbNo = dbNo;
	}

}
