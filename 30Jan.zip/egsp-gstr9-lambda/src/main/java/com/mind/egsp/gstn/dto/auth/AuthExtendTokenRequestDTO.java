package com.mind.egsp.gstn.dto.auth;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class AuthExtendTokenRequestDTO extends AuthBaseRequestDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("auth_token")
	private String authToken;

	public AuthExtendTokenRequestDTO(String stateCd, String ipUsr, String txn, String appKey, String username,
			String authToken) {
		super(stateCd, ipUsr, txn, appKey, username);
		this.authToken = authToken;
		// TODO Remove after GSTN bug is resolved
		this.setUsername(username.toLowerCase());
	}

	public String getAuthToken() {
		return authToken;
	}

	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}

}
