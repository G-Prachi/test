package com.mind.egsp.gstn.model.gstr1;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Class TXPErrorReport.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class TXPErrorReport extends ErrorReport implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The Invoice Number .
	 */
	@JsonProperty("i_num")
	private String iNum;

	/**
	 * The Document Number .
	 */
	@JsonProperty("doc_num")
	private String docNum;

	/**
	 * The Document Date .
	 */
	@JsonProperty("doc_dt")
	private String docDt;

	/**
	 * Gets the Invoice Number Field Specification: Alphanumeric (Max length:10)
	 * Sample Data: A88017 .
	 *
	 * @return the i num
	 */
	public String getiNum() {
		return iNum;
	}

	/**
	 * Sets the Invoice Number Field Specification: Alphanumeric (Max length:10)
	 * Sample Data: A88017 .
	 *
	 * @param iNum
	 *            the new i num
	 */
	public void setiNum(String iNum) {
		this.iNum = iNum;
	}

	/**
	 * Gets the Document Number Field Specification: Alphanumeric (Max
	 * length:50) Sample Data: 100012 .
	 *
	 * @return the doc num
	 */
	public String getDocNum() {
		return docNum;
	}

	/**
	 * Sets the Document Number Field Specification: Alphanumeric (Max
	 * length:50) Sample Data: 100012 .
	 *
	 * @param docNum
	 *            the new doc num
	 */
	public void setDocNum(String docNum) {
		this.docNum = docNum;
	}

	/**
	 * Gets the Document Date Field Specification: string (DD-MM-YYYY) Sample
	 * Data: 26-06-2016 .
	 *
	 * @return the doc dt
	 */
	public String getDocDt() {
		return docDt;
	}

	/**
	 * Sets the Document Date Field Specification: string (DD-MM-YYYY) Sample
	 * Data: 26-06-2016 .
	 *
	 * @param docDt
	 *            the new doc dt
	 */
	public void setDocDt(String docDt) {
		this.docDt = docDt;
	}

}
