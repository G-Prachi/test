package com.mind.egsp.gstn.dto.gstr2a;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr2a.Gstr2AB2baInvoice;

/**
 * The Class Gstr2AGetB2baInvoicesResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Gstr2AGetB2baInvoicesResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The b 2 ba invoices. */
	@JsonProperty("b2ba")
	private List<Gstr2AB2baInvoice> b2baInvoices;

	/**
	 * Gets the b 2 ba invoices.
	 *
	 * @return the b 2 ba invoices
	 */
	public List<Gstr2AB2baInvoice> getB2baInvoices() {
		return b2baInvoices;
	}

	/**
	 * Sets the b 2 ba invoices.
	 *
	 * @param b2baInvoices
	 *            the new b 2 ba invoices
	 */
	public void setB2baInvoices(List<Gstr2AB2baInvoice> b2baInvoices) {
		this.b2baInvoices = b2baInvoices;
	}

}
