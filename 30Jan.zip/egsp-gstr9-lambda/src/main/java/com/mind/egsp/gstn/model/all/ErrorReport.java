package com.mind.egsp.gstn.model.all;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.model.gstr1.B2CSErrorReport;

// TODO: Auto-generated Javadoc
/**
 * The Class ErrorReport.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class ErrorReport implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The b 2 b error reports. */
	@JsonProperty("b2b")
	private List<B2BErrorReport> b2bErrorReports;

	/** The cdn error reports. */
	@JsonProperty("cdnr")
	private List<CDNErrorReport> cdnErrorReports;

	/** The exp error reports. */
	@JsonProperty("exp")
	private List<EXPErrorReport> expErrorReports;

	/** The b2cl error reports. */
	@JsonProperty("b2cl")
	private List<B2CLErrorReport> b2clErrorReports;

	/** The b2cs error reports. */
	@JsonProperty("b2cs")
	private List<B2CSErrorReport> b2csErrorReports;

	/** The hsn error reports. */
	@JsonProperty("hsn")
	private HSNErrorReport hsnErrorReport;

	/** The nil error report. */
	@JsonProperty("nil")
	private NILErrorReport nilErrorReport;
	
	@JsonProperty("nil_supplies")
	private List<NILErrorReport> nilSupppliesErrorReport;

	/** The at error reports. */
	@JsonProperty("at")
	private List<ATErrorReport> atErrorReports;

	/** The txpd error reports. */
	@JsonProperty("txpd")
	private List<TXPDErrorReport> txpdErrorReports;

	/** The cdnur error reports. */
	@JsonProperty("cdnur")
	private List<CdnurErrorReport> cdnurErrorReports;

	/** The doc issue error reports. */
	@JsonProperty("doc_issue")
	private DocIssueErrorReport docIssueErrorReport;

	/** The Import of goods error reports. */
	@JsonProperty("imp_g")
	private List<IMPGErrorReport> impgErrorReports;

	/** The Import of services error reports. */
	@JsonProperty("imp_s")
	private List<IMPSErrorReport> impsErrorReports;

	/** The GSTR2 cdn error reports. */
	@JsonProperty("cdn")
	private List<Gstr2CDNErrorReport> gstr2cdnErrorReports;

	/** The GSTR2 b2bur error reports. */
	@JsonProperty("b2bur")
	private List<B2burErrorReport> b2burErrorReports;

	/** The GSTR2 hsnsum error reports. */
	@JsonProperty("hsnsum")
	private List<HsnsumErrorReport> hsnsumErrorReports;

	/** The GSTR2 txi error reports. */
	@JsonProperty("txi")
	private List<TxiErrorReport> txiErrorReports;
	@JsonProperty("error_msg")
	private String errorMsg;

	/**
	 * Gets the b 2 b error reports.
	 *
	 * @return the b 2 b error reports
	 */
	public List<B2BErrorReport> getB2bErrorReports() {
		return b2bErrorReports;
	}

	/**
	 * Sets the b 2 b error reports.
	 *
	 * @param b2bErrorReports
	 *            the new b 2 b error reports
	 */
	public void setB2bErrorReports(List<B2BErrorReport> b2bErrorReports) {
		this.b2bErrorReports = b2bErrorReports;
	}

	/**
	 * Gets the cdn error reports.
	 *
	 * @return the cdn error reports
	 */
	public List<CDNErrorReport> getCdnErrorReports() {
		return cdnErrorReports;
	}

	/**
	 * Sets the cdn error reports.
	 *
	 * @param cdnErrorReports
	 *            the new cdn error reports
	 */
	public void setCdnErrorReports(List<CDNErrorReport> cdnErrorReports) {
		this.cdnErrorReports = cdnErrorReports;
	}

	/**
	 * Gets the exp error reports.
	 *
	 * @return the exp error reports
	 */
	public List<EXPErrorReport> getExpErrorReports() {
		return expErrorReports;
	}

	/**
	 * Sets the exp error reports.
	 *
	 * @param expErrorReports
	 *            the new exp error reports
	 */
	public void setExpErrorReports(List<EXPErrorReport> expErrorReports) {
		this.expErrorReports = expErrorReports;
	}

	/**
	 * Gets the b 2 cl error reports.
	 *
	 * @return the b 2 cl error reports
	 */
	public List<B2CLErrorReport> getB2clErrorReports() {
		return b2clErrorReports;
	}

	/**
	 * Sets the b 2 cl error reports.
	 *
	 * @param b2clErrorReports
	 *            the new b 2 cl error reports
	 */
	public void setB2clErrorReports(List<B2CLErrorReport> b2clErrorReports) {
		this.b2clErrorReports = b2clErrorReports;
	}

	/**
	 * Gets the b 2 cs error reports.
	 *
	 * @return the b 2 cs error reports
	 */
	public List<B2CSErrorReport> getB2csErrorReports() {
		return b2csErrorReports;
	}

	/**
	 * Sets the b 2 cs error reports.
	 *
	 * @param b2csErrorReports
	 *            the new b 2 cs error reports
	 */
	public void setB2csErrorReports(List<B2CSErrorReport> b2csErrorReports) {
		this.b2csErrorReports = b2csErrorReports;
	}

	/**
	 * Gets the hsn error report.
	 *
	 * @return the hsn error report
	 */
	public HSNErrorReport getHsnErrorReport() {
		return hsnErrorReport;
	}

	/**
	 * Sets the hsn error report.
	 *
	 * @param hsnErrorReport
	 *            the new hsn error report
	 */
	public void setHsnErrorReport(HSNErrorReport hsnErrorReport) {
		this.hsnErrorReport = hsnErrorReport;
	}

	/**
	 * Gets the nil error report.
	 *
	 * @return the nil error report
	 */
	public NILErrorReport getNilErrorReport() {
		return nilErrorReport;
	}

	/**
	 * Sets the nil error report.
	 *
	 * @param nilErrorReport
	 *            the new nil error report
	 */
	public void setNilErrorReport(NILErrorReport nilErrorReport) {
		this.nilErrorReport = nilErrorReport;
	}

	/**
	 * Gets the at error reports.
	 *
	 * @return the at error reports
	 */
	public List<ATErrorReport> getAtErrorReports() {
		return atErrorReports;
	}

	/**
	 * Sets the at error reports.
	 *
	 * @param atErrorReports
	 *            the new at error reports
	 */
	public void setAtErrorReports(List<ATErrorReport> atErrorReports) {
		this.atErrorReports = atErrorReports;
	}

	/**
	 * Gets the txpd error reports.
	 *
	 * @return the txpd error reports
	 */
	public List<TXPDErrorReport> getTxpdErrorReports() {
		return txpdErrorReports;
	}

	/**
	 * Sets the txpd error reports.
	 *
	 * @param txpdErrorReports
	 *            the new txpd error reports
	 */
	public void setTxpdErrorReports(List<TXPDErrorReport> txpdErrorReports) {
		this.txpdErrorReports = txpdErrorReports;
	}

	/**
	 * Gets the cdnur error reports.
	 *
	 * @return the cdnur error reports
	 */
	public List<CdnurErrorReport> getCdnurErrorReports() {
		return cdnurErrorReports;
	}

	/**
	 * Sets the cdnur error reports.
	 *
	 * @param cdnurErrorReports
	 *            the new cdnur error reports
	 */
	public void setCdnurErrorReports(List<CdnurErrorReport> cdnurErrorReports) {
		this.cdnurErrorReports = cdnurErrorReports;
	}

	/**
	 * Gets the doc issue error report.
	 *
	 * @return the doc issue error report
	 */
	public DocIssueErrorReport getDocIssueErrorReport() {
		return docIssueErrorReport;
	}

	/**
	 * Sets the doc issue error report.
	 *
	 * @param docIssueErrorReport
	 *            the new doc issue error report
	 */
	public void setDocIssueErrorReport(DocIssueErrorReport docIssueErrorReport) {
		this.docIssueErrorReport = docIssueErrorReport;
	}

	/**
	 * Gets the impg error reports.
	 *
	 * @return the impg error reports
	 */
	public List<IMPGErrorReport> getImpgErrorReports() {
		return impgErrorReports;
	}

	/**
	 * Sets the impg error reports.
	 *
	 * @param impgErrorReports
	 *            the new impg error reports
	 */
	public void setImpgErrorReports(List<IMPGErrorReport> impgErrorReports) {
		this.impgErrorReports = impgErrorReports;
	}

	/**
	 * Gets the imps error reports.
	 *
	 * @return the imps error reports
	 */
	public List<IMPSErrorReport> getImpsErrorReports() {
		return impsErrorReports;
	}

	/**
	 * Sets the imps error reports.
	 *
	 * @param impsErrorReports
	 *            the new imps error reports
	 */
	public void setImpsErrorReports(List<IMPSErrorReport> impsErrorReports) {
		this.impsErrorReports = impsErrorReports;
	}

	/**
	 * Gets the gstr 2 cdn error reports.
	 *
	 * @return the gstr 2 cdn error reports
	 */
	public List<Gstr2CDNErrorReport> getGstr2cdnErrorReports() {
		return gstr2cdnErrorReports;
	}

	/**
	 * Sets the gstr 2 cdn error reports.
	 *
	 * @param gstr2cdnErrorReports
	 *            the new gstr 2 cdn error reports
	 */
	public void setGstr2cdnErrorReports(List<Gstr2CDNErrorReport> gstr2cdnErrorReports) {
		this.gstr2cdnErrorReports = gstr2cdnErrorReports;
	}

	/**
	 * Gets the b 2 bur error reports.
	 *
	 * @return the b 2 bur error reports
	 */
	public List<B2burErrorReport> getB2burErrorReports() {
		return b2burErrorReports;
	}

	/**
	 * Sets the b 2 bur error reports.
	 *
	 * @param b2burErrorReports
	 *            the new b 2 bur error reports
	 */
	public void setB2burErrorReports(List<B2burErrorReport> b2burErrorReports) {
		this.b2burErrorReports = b2burErrorReports;
	}


	/**
	 * Gets the hsnsum error reports.
	 *
	 * @return the hsnsum error reports
	 */
	public List<HsnsumErrorReport> getHsnsumErrorReports() {
		return hsnsumErrorReports;
	}

	/**
	 * Sets the hsnsum error reports.
	 *
	 * @param hsnsumErrorReports
	 *            the new hsnsum error reports
	 */
	public void setHsnsumErrorReports(List<HsnsumErrorReport> hsnsumErrorReports) {
		this.hsnsumErrorReports = hsnsumErrorReports;
	}

	/**
	 * Gets the txi error reports.
	 *
	 * @return the txi error reports
	 */
	public List<TxiErrorReport> getTxiErrorReports() {
		return txiErrorReports;
	}

	/**
	 * Sets the txi error reports.
	 *
	 * @param txiErrorReports
	 *            the new txi error reports
	 */
	public void setTxiErrorReports(List<TxiErrorReport> txiErrorReports) {
		this.txiErrorReports = txiErrorReports;
	}

	public List<NILErrorReport> getNilSupppliesErrorReport() {
		return nilSupppliesErrorReport;
	}

	public void setNilSupppliesErrorReport(List<NILErrorReport> nilSupppliesErrorReport) {
		this.nilSupppliesErrorReport = nilSupppliesErrorReport;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	
	
}
