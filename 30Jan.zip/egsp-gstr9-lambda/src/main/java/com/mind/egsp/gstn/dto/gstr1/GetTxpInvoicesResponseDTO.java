package com.mind.egsp.gstn.dto.gstr1;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr1.TxpdInvoice;

// TODO: Auto-generated Javadoc
/**
 * The Class GetTxpResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetTxpInvoicesResponseDTO extends BaseDataResponseDTO implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The txpd invoices detail. */
	@JsonProperty("txpd")
	private List<TxpdInvoice> txpdInvoices;

	/**
	 * Gets the txpd invoices.
	 *
	 * @return the txpd invoices
	 */
	public List<TxpdInvoice> getTxpdInvoices() {
		return txpdInvoices;
	}

	/**
	 * Sets the txpd invoices.
	 *
	 * @param txpdInvoices
	 *            the new txpd invoices
	 */
	public void setTxpdInvoices(List<TxpdInvoice> txpdInvoices) {
		this.txpdInvoices = txpdInvoices;
	}

}
