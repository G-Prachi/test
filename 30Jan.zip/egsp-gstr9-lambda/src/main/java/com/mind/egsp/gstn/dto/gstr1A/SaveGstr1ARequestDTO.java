package com.mind.egsp.gstn.dto.gstr1A;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

/**
 * The Class SaveGSTR1ADataRequestDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class SaveGstr1ARequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** HMAC-SHA256 of Base64 data using EK. */
	private String hmac;

	/** Data for invoices of all business types. */
	@JsonProperty("data")
	private SaveGstr1aDTO saveGstr1aDTO;

	/**
	 * Instantiates a new save gstr 1 request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param gstin
	 *            the gstin
	 * @param retPeriod
	 *            the ret period
	 * @param username
	 *            the username
	 */
	public SaveGstr1ARequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	/**
	 * Gets the hmac.
	 *
	 * @return the hmac
	 */
	public String getHmac() {
		return hmac;
	}

	/**
	 * Sets the hmac.
	 *
	 * @param hmac
	 *            the new hmac
	 */
	public void setHmac(String hmac) {
		this.hmac = hmac;
	}

	/**
	 * Gets the save gstr 1 a DTO.
	 *
	 * @return the save gstr 1 a DTO
	 */
	public SaveGstr1aDTO getSaveGstr1aDTO() {
		return saveGstr1aDTO;
	}

	/**
	 * Sets the save gstr 1 a DTO.
	 *
	 * @param saveGstr1aDTO
	 *            the new save gstr 1 a DTO
	 */
	public void setSaveGstr1aDTO(SaveGstr1aDTO saveGstr1aDTO) {
		this.saveGstr1aDTO = saveGstr1aDTO;
	}

}
