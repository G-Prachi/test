package com.mind.egsp.gstn.dto.gstr9;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

/**
 * The Class Gstr9GetAutocalculatedDetailsRequestDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Gstr9GetAutocalculatedDetailsRequestDTO extends BaseRequestDTO implements Serializable {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Instantiates a new gstr 9 get autocalculated details request DTO.
	 *
	 * @param stateCd the state cd
	 * @param ipUsr the ip usr
	 * @param txn the txn
	 * @param gstin the gstin
	 * @param retPeriod the ret period
	 * @param username the username
	 */
	public Gstr9GetAutocalculatedDetailsRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}
	
	
}
