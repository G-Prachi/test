package com.mind.egsp.gstn.dto.all;

import java.io.Serializable;

import com.mind.egsp.gstn.dto.BaseResponseDTO;

/**
 * The Class TrackARNStatusReaponseDTO.
 */
public class TrackARNStatusResponseDTO extends BaseResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The Status of API .
	 */
	private String status;

	/**
	 * Gets the Status of API Field Specification: String Sample Data:
	 * SUCCESS/FAILED/PENDING/NOT FILED .
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the Status of API Field Specification: String Sample Data:
	 * SUCCESS/FAILED/PENDING/NOT FILED .
	 *
	 * @param status
	 *            the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

}
