package com.mind.egsp.gstn.dto.gstr1;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetB2claInvoicesRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The GSTIN of the taxpayer. */
	private String gstin;

	/** The Return Period. */
	private String retPeriod;

	/** The State code. */
	private String stCd;

	public GetB2claInvoicesRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	/**
	 * Gets the GSTIN of the taxpayer.
	 * 
	 * Field Specification:Alphanumeric with 15 characters
	 * 
	 * Mandatory: Y Sample Data: 29HJKPS9689A8Z4
	 *
	 * @return the gstin
	 */
	@Override
	public String getGstin() {
		return gstin;
	}

	/**
	 * Sets the GSTIN of the taxpayer.
	 *
	 * Field Specification:Alphanumeric with 15 characters
	 * 
	 * Mandatory: Y Sample Data: 29HJKPS9689A8Z4
	 *
	 * @param gstin
	 *            the new gstin
	 */
	@Override
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the Return Period.
	 *
	 * Field Specification:MMYYYY
	 * 
	 * Mandatory: Y Sample Data: 072016
	 *
	 * @return the ret period
	 */
	@Override
	public String getRetPeriod() {
		return retPeriod;
	}

	/**
	 * Sets the Return Period.
	 *
	 * Field Specification:MMYYYY
	 * 
	 * Mandatory: Y Sample Data: 072016
	 *
	 * @param retPeriod
	 *            the new ret period
	 */
	@Override
	public void setRetPeriod(String retPeriod) {
		this.retPeriod = retPeriod;
	}

	/**
	 * Gets the State code.
	 *
	 * Field Specification:String(Max length:2)
	 * 
	 * Mandatory: N Sample Data: 4
	 *
	 * 
	 * @return the State code
	 */
	public String getStCd() {
		return stCd;
	}

	/**
	 * Sets the State code.
	 *
	 * Field Specification:String(Max length:2)
	 * 
	 * Mandatory: N Sample Data: 4
	 *
	 * @param stCd
	 *            the new State code
	 */
	public void setStCd(String stCd) {
		this.stCd = stCd;
	}

}
