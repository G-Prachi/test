package com.mind.egsp.gstn.dto.gstr1;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr1.NilSupply;

// TODO: Auto-generated Javadoc
/**
 * The Class GetNilRatedSuppliesResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetNilRatedSuppliesResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Nil supply. */
	@JsonProperty("nil")
	private NilSupply nilSupplies;

	/**
	 * Gets the nil supplies.
	 *
	 * @return the nil supplies
	 */
	public NilSupply getNilSupplies() {
		return nilSupplies;
	}

	/**
	 * Sets the nil supplies.
	 *
	 * @param nilSupplies
	 *            the new nil supplies
	 */
	public void setNilSupplies(NilSupply nilSupplies) {
		this.nilSupplies = nilSupplies;
	}


}
