package com.mind.egsp.gstn.dto.gstr1A;

import java.io.Serializable;
import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Class GSTR1ACounterPartySummary.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GSTR1ACounterPartySummary implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The Supplier TIN for B2B & CDN/ISD TIN for ISD/deductor TIN for TDS/
	 * Ecommerce Portal TIN for TCS/ .
	 */
	private String ctin;

	/**
	 * The Invoice Check sum value .
	 */
	private String checksum;

	/**
	 * The Total invoice value .
	 */
	@JsonProperty("ttl_inv")
	private BigDecimal ttl_inv;

	/**
	 * The Total Taxible Value .
	 */
	@JsonProperty("ttl_tax")
	private BigDecimal ttl_tax;

	/**
	 * The Total IGST .
	 */
	@JsonProperty("ttl_igst")
	private BigDecimal ttl_igst;

	/**
	 * The Total CGST .
	 */
	@JsonProperty("ttl_cgst")
	private BigDecimal ttl_cgst;

	/**
	 * The Total SGST .
	 */
	@JsonProperty("ttl_sgst")
	private BigDecimal ttl_sgst;

	/**
	 * Gets the Supplier TIN for B2B & CDN/ISD TIN for ISD/deductor TIN for TDS/
	 * Ecommerce Portal TIN for TCS/ Field Specification: Alphanumeric with 15
	 * char Sample Data: 20GRRHF2562D3A3 .
	 *
	 * @return the ctin
	 */
	public String getCtin() {
		return ctin;
	}

	/**
	 * Sets the Supplier TIN for B2B & CDN/ISD TIN for ISD/deductor TIN for TDS/
	 * Ecommerce Portal TIN for TCS/ Field Specification: Alphanumeric with 15
	 * char Sample Data: 20GRRHF2562D3A3 .
	 *
	 * @param ctin
	 *            the new ctin
	 */
	public void setCtin(String ctin) {
		this.ctin = ctin;
	}

	/**
	 * Gets the Invoice Check sum value Field Specification: string(Max
	 * length:15) Sample Data: AflJufPlFStqKBZ .
	 *
	 * @return the checksum
	 */
	public String getChecksum() {
		return checksum;
	}

	/**
	 * Sets the Invoice Check sum value Field Specification: string(Max
	 * length:15) Sample Data: AflJufPlFStqKBZ .
	 *
	 * @param checksum
	 *            the new checksum
	 */
	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}

	/**
	 * Gets the Total invoice value Field Specification: Decimal(p,2) Sample
	 * Data: 1000 .
	 *
	 * @return the ttl inv
	 */
	public BigDecimal getTtl_inv() {
		return ttl_inv;
	}

	/**
	 * Sets the Total invoice value Field Specification: Decimal(p,2) Sample
	 * Data: 1000 .
	 *
	 * @param ttl_inv
	 *            the new ttl inv
	 */
	public void setTtl_inv(BigDecimal ttl_inv) {
		this.ttl_inv = ttl_inv;
	}

	/**
	 * Gets the Total Taxible Value Field Specification: Decimal(p,2) Sample
	 * Data: 500 .
	 *
	 * @return the ttl tax
	 */
	public BigDecimal getTtl_tax() {
		return ttl_tax;
	}

	/**
	 * Sets the Total Taxible Value Field Specification: Decimal(p,2) Sample
	 * Data: 500 .
	 *
	 * @param ttl_tax
	 *            the new ttl tax
	 */
	public void setTtl_tax(BigDecimal ttl_tax) {
		this.ttl_tax = ttl_tax;
	}

	/**
	 * Gets the Total IGST Field Specification: Decimal(p,2) Sample Data: 100 .
	 *
	 * @return the ttl igst
	 */
	public BigDecimal getTtl_igst() {
		return ttl_igst;
	}

	/**
	 * Sets the Total IGST Field Specification: Decimal(p,2) Sample Data: 100 .
	 *
	 * @param ttl_igst
	 *            the new ttl igst
	 */
	public void setTtl_igst(BigDecimal ttl_igst) {
		this.ttl_igst = ttl_igst;
	}

	/**
	 * Gets the Total CGST Field Specification: Decimal(p,2) Sample Data: 100.9
	 * .
	 *
	 * @return the ttl cgst
	 */
	public BigDecimal getTtl_cgst() {
		return ttl_cgst;
	}

	/**
	 * Sets the Total CGST Field Specification: Decimal(p,2) Sample Data: 100.9
	 * .
	 *
	 * @param ttl_cgst
	 *            the new ttl cgst
	 */
	public void setTtl_cgst(BigDecimal ttl_cgst) {
		this.ttl_cgst = ttl_cgst;
	}

	/**
	 * Gets the Total SGST Field Specification: Decimal(p,2) Sample Data: 100.67
	 * .
	 *
	 * @return the ttl sgst
	 */
	public BigDecimal getTtl_sgst() {
		return ttl_sgst;
	}

	/**
	 * Sets the Total SGST Field Specification: Decimal(p,2) Sample Data: 100.67
	 * .
	 *
	 * @param ttl_sgst
	 *            the new ttl sgst
	 */
	public void setTtl_sgst(BigDecimal ttl_sgst) {
		this.ttl_sgst = ttl_sgst;
	}

}
