package com.mind.egsp.flatfile.convert;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.amazonaws.services.s3.AmazonS3;
import com.egsp.finalDTOs.B2bInvoiceDetailFlat;
import com.egsp.finalDTOs.B2baInvoiceDetailFlat;
import com.egsp.finalDTOs.B2baInvoiceFlat;
import com.egsp.finalDTOs.B2baInvoiceFlatFinal;
import com.egsp.finalDTOs.B2clInvoiceDetailFlat;
import com.egsp.finalDTOs.B2clInvoiceFlat;
import com.egsp.finalDTOs.B2clInvoiceFlatFinal;
import com.egsp.finalDTOs.SaveGstr1DTOFlat;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mind.egsp.gstn.dto.gstr1.SaveGstr1DTO;
import com.mind.egsp.gstn.model.gstr1.B2clItem;
import com.mind.egsp.gstn.model.gstr1.B2clInvoice;
import com.mind.egsp.gstn.model.gstr1.B2clInvoiceDetail;

public class b2cljsonConverter {
	static List<B2clInvoiceDetailFlat> flatB2clDetiallist =  new ArrayList<B2clInvoiceDetailFlat>();		
	static List<B2clInvoiceFlat>  flatB2cllist = new ArrayList<B2clInvoiceFlat>();
	static List<B2clInvoiceFlatFinal> b2clInvFlatFinal = new ArrayList<B2clInvoiceFlatFinal>();
	
	public static String b2bJsonConverter(SaveGstr1DTO gstriObj,String bucketName,String filePath,String fileName,AmazonS3 s3, String str2)
	{
	
		//***************************Declaration for B2ba*************
		try
		{
				//List<B2bInvoiceFlat>  flatB2blist = new ArrayList<B2bInvoiceFlat>();				
				//byte[] jsonData1 = Files.readAllBytes(Paths.get("B2b-sample.json"));
				//create ObjectMapper instance
				//ObjectMapper objectMapper = new ObjectMapper();
				SaveGstr1DTOFlat savedtoflat  = new SaveGstr1DTOFlat();
				//SaveGstr1DTO gstriObj = objectMapper.readValue(jsonData1, SaveGstr1DTO.class);
				savedtoflat.setFp(gstriObj.getFp());
				//B2BInvoice================
				List<B2clInvoice> listb2cl=gstriObj.getB2clInvoices();
				List<B2clInvoiceDetailFlat> flatB2bDetiallist = new ArrayList<B2clInvoiceDetailFlat>();
				BigDecimal totaltxval = new BigDecimal(0);
				BigDecimal totaliamt = new BigDecimal(0);;
				BigDecimal totalcamt =new BigDecimal(0);
				BigDecimal totalsamt =new BigDecimal(0);
				BigDecimal totalcsamt = new BigDecimal(0);
				if(listb2cl!=null)
				{
					for(B2clInvoice item : listb2cl)
					{
						flatB2clDetiallist = new ArrayList<B2clInvoiceDetailFlat>();
						B2clInvoiceFlat b2clflat = new B2clInvoiceFlat();
						b2clflat.setCtin(item.getCtin());
						for(B2clInvoiceDetail invDetail : item.getInvoiceDetails()) {
							B2clInvoiceDetailFlat b2clInvoiceDetailFLat = new B2clInvoiceDetailFlat();
							b2clInvoiceDetailFLat.setInum(invDetail.getInum());
							b2clflat.setRchrg(invDetail.getRchrg());
							b2clflat.setInvTyp(invDetail.getInvTyp());
							b2clflat.setVal(invDetail.getVal());
							
							b2clInvoiceDetailFLat.setIdt(invDetail.getIdt());
							for (B2clItem item1 :invDetail.getB2clItems()) {
								totaltxval = totaltxval.add(item1.getB2clItemDetail().getTxval());
								totaliamt = totaliamt.add(item1.getB2clItemDetail().getIamt());
								totalcamt = totalcamt.add(item1.getB2clItemDetail().getCamt());
								totalsamt = totalsamt.add(item1.getB2clItemDetail().getSamt());
								totalcsamt = totalcsamt.add(item1.getB2clItemDetail().getCsamt());
								
							}
								b2clInvoiceDetailFLat.setTotaltxval(totaltxval);
								b2clInvoiceDetailFLat.setTotaliamt(totaliamt);
								b2clInvoiceDetailFLat.setTotalcamt(totalcamt);
								b2clInvoiceDetailFLat.setTotalcsamt(totalcsamt);
								b2clInvoiceDetailFLat.setTotalsamt(totalsamt);
								flatB2clDetiallist.add(b2clInvoiceDetailFLat);
							
						}
						b2clflat.setB2clInvoiceDetailFLat(flatB2clDetiallist);
						flatB2cllist.add(b2clflat);
					}
				//	System.out.println("flatB2blist "+flatB2blist);
					List<B2clInvoiceFlatFinal> b2clfinalList = new ArrayList<B2clInvoiceFlatFinal>();
					
					for(B2clInvoiceFlat flatList : flatB2cllist)
					{
						for(B2clInvoiceDetailFlat b2clInvoiceFlat : flatList.getB2clInvoiceDetailFLat()) {
							B2clInvoiceFlatFinal b2clInvoiceFlatFinal = new B2clInvoiceFlatFinal();
							b2clInvoiceFlatFinal.setFp(gstriObj.getFp());
							b2clInvoiceFlatFinal.setBusinessType("b2ba");
							b2clInvoiceFlatFinal.setCtin(flatList.getCtin());
							//b2baInvoiceFlatFinal.setRchrg(flatList.getRchrg());
							b2clInvoiceFlatFinal.setInvTyp(flatList.getInvTyp());
							b2clInvoiceFlatFinal.setVal(flatList.getVal());
							b2clInvoiceFlatFinal.setInum(b2clInvoiceFlat.getInum());
							b2clInvoiceFlatFinal.setIdt(b2clInvoiceFlat.getIdt());
							b2clInvoiceFlatFinal.setTotalcamt(b2clInvoiceFlat.getTotalcamt());
							b2clInvoiceFlatFinal.setTotalcsamt(b2clInvoiceFlat.getTotalcsamt());
						
							b2clInvoiceFlatFinal.setTotalsamt(b2clInvoiceFlat.getTotalsamt());
							b2clInvoiceFlatFinal.setTotaltxval(b2clInvoiceFlat.getTotaltxval());
							
							b2clInvoiceFlatFinal.setTotaliamt(b2clInvoiceFlat.getTotaliamt());
							//b2clInvoiceFlatFinal.setOinum(flatList.getOinum());
							//b2clInvoiceFlatFinal.setOidt(flatList.getOidt());
							b2clfinalList.add(b2clInvoiceFlatFinal);
						}
					}
					
					final ByteArrayOutputStream out = new ByteArrayOutputStream();
				    final ObjectMapper mapper = new ObjectMapper();
				    
				    mapper.writeValue(out, b2clfinalList);
			        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
			        StringBuilder tempFile = new StringBuilder();
			        Random rnd = new Random();
			        while (tempFile.length() < 18) { // length of the random string.
			            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
			            tempFile.append(SALTCHARS.charAt(index));
			        }
			        String tempFil = tempFile.toString();
			        File tempFileName = new File(tempFil+".json");
			        //return saltStr;
					mapper.writeValue(tempFileName, b2clfinalList);
					InputStream is = new FileInputStream(tempFileName);
					String contents = new BufferedReader(new InputStreamReader(is)).readLine();
					is.close(); 
					
						String str = contents.substring(1, contents.length()-1);
						String str1=str.replaceAll("},", "}\n");
						System.out.println(str1);
						str2= str2.concat(str1);
						return(str2);
						/*PrintWriter pr = new PrintWriter(new BufferedWriter(new FileWriter(new File(fileName), true)));
						pr.write(str1);
						pr.append("\n");
						pr.close();
						s3.putObject(bucketName, filePath+"/"+fileName, str1);
						System.out.println("sucess");*/
				    
				    
								
				}						
		}
				catch(Exception ex)
				{
					
				}
		return (str2);
	}
}
		
	