package com.mind.egsp.gstn.dto.gstr3;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;

/**
 * The Class GenerateGSTR3ResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class GenerateResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The reference id. */
	@JsonProperty("ref_id")
	private String referenceId;

	/**
	 * Gets the ReferenceId for the repsonse Field Specification:Alphanumeric
	 * Sample Data:"GSTR3 is generated"
	 * 
	 * .
	 *
	 * @return the message
	 */
	public String getReferenceId() {
		return referenceId;
	}

	/**
	 * Sets the Gets the ReferenceId for the repsonse Field
	 * Specification:Alphanumeric Sample Data:"GSTR3 is generated".
	 *
	 * @param message
	 *            the new message
	 */
	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

}
