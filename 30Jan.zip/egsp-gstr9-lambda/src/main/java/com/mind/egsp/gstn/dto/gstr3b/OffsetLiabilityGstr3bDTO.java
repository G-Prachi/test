package com.mind.egsp.gstn.dto.gstr3b;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.model.gstr3b.Gstr3bTaxPaidByCash;
import com.mind.egsp.gstn.model.gstr3b.Gstr3bTaxPaidByCredit;

// TODO: Auto-generated Javadoc
/**
 * The Class OffsetLiabilityGstr3bDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class OffsetLiabilityGstr3bDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** Supplier GSTIN. */
	private String gstin;

	/** Supplier Invoice Date. */
	@JsonProperty("ret_period")
	private String retPeriod;

	/** The List of Paid Through Cash. */
	@JsonProperty("pdcash")
	private List<Gstr3bTaxPaidByCash> paidByCashs;

	/** The List of Paid Through Credit. */
	@JsonProperty("pditc")
	private List<Gstr3bTaxPaidByCredit> paidByCredits;

	/**
	 * Gets the gstin.
	 *
	 * @return the gstin
	 */
	public String getGstin() {
		return gstin;
	}

	/**
	 * Sets the gstin.
	 *
	 * @param gstin
	 *            the new gstin
	 */
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the ret period.
	 *
	 * @return the ret period
	 */
	public String getRetPeriod() {
		return retPeriod;
	}

	/**
	 * Sets the ret period.
	 *
	 * @param retPeriod
	 *            the new ret period
	 */
	public void setRetPeriod(String retPeriod) {
		this.retPeriod = retPeriod;
	}

	/**
	 * Gets the paid by cashs.
	 *
	 * @return the paid by cashs
	 */
	public List<Gstr3bTaxPaidByCash> getPaidByCashs() {
		return paidByCashs;
	}

	/**
	 * Sets the paid by cashs.
	 *
	 * @param paidByCashs
	 *            the new paid by cashs
	 */
	public void setPaidByCashs(List<Gstr3bTaxPaidByCash> paidByCashs) {
		this.paidByCashs = paidByCashs;
	}

	/**
	 * Gets the paid by credits.
	 *
	 * @return the paid by credits
	 */
	public List<Gstr3bTaxPaidByCredit> getPaidByCredits() {
		return paidByCredits;
	}

	/**
	 * Sets the paid by credits.
	 *
	 * @param paidByCredits
	 *            the new paid by credits
	 */
	public void setPaidByCredits(List<Gstr3bTaxPaidByCredit> paidByCredits) {
		this.paidByCredits = paidByCredits;
	}

}
