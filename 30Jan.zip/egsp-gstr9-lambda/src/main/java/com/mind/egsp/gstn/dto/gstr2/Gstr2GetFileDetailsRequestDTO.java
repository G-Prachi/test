package com.mind.egsp.gstn.dto.gstr2;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

/**
 * The Gstr2 Get File Details Request DTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Gstr2GetFileDetailsRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The token for getting the file details. */
	@JsonIgnore
	private String token;

	/**
	 * Instantiates a new Gstr2 Get File Details Request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param gstin
	 *            the gstin
	 * @param retPeriod
	 *            the ret period
	 * @param username
	 *            the username
	 */
	public Gstr2GetFileDetailsRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username, String token) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
		this.token = token;
	}

	/**
	 * Gets the token.
	 *
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * Sets the token.
	 *
	 * @param token
	 *            the new token
	 */
	public void setToken(String token) {
		this.token = token;
	}

}
