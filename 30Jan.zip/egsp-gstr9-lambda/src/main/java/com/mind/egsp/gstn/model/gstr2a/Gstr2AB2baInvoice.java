package com.mind.egsp.gstn.model.gstr2a;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Class Gstr2B2BInvoice.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Gstr2AB2baInvoice implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The ctin. */
	private String ctin;

	/** The cfs. */
	private String cfs;

	/** The gstr 2 AB 2 b invoice details. */
	@JsonProperty("inv")
	private List<Gstr2AB2baInvoiceDetail> gstr2AB2baInvoiceDetails;

	/**
	 * Gets the ctin.
	 *
	 * @return the ctin
	 */
	public String getCtin() {
		return ctin;
	}

	/**
	 * Sets the ctin.
	 *
	 * @param ctin
	 *            the new ctin
	 */
	public void setCtin(String ctin) {
		this.ctin = ctin;
	}

	/**
	 * Gets the cfs.
	 *
	 * @return the cfs
	 */
	public String getCfs() {
		return cfs;
	}

	/**
	 * Sets the cfs.
	 *
	 * @param cfs
	 *            the new cfs
	 */
	public void setCfs(String cfs) {
		this.cfs = cfs;
	}

	/**
	 * Gets the gstr 2 AB 2 ba invoice details.
	 *
	 * @return the gstr 2 AB 2 ba invoice details
	 */
	public List<Gstr2AB2baInvoiceDetail> getGstr2AB2baInvoiceDetails() {
		return gstr2AB2baInvoiceDetails;
	}

	/**
	 * Sets the gstr 2 AB 2 ba invoice details.
	 *
	 * @param gstr2ab2baInvoiceDetails
	 *            the new gstr 2 AB 2 ba invoice details
	 */
	public void setGstr2AB2baInvoiceDetails(List<Gstr2AB2baInvoiceDetail> gstr2ab2baInvoiceDetails) {
		gstr2AB2baInvoiceDetails = gstr2ab2baInvoiceDetails;
	}

}
