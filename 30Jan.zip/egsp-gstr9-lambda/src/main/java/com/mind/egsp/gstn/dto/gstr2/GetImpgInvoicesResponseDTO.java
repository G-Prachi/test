package com.mind.egsp.gstn.dto.gstr2;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr2.ImpgInvoiceDetail;

/**
 * The Class GetImpgInvoicesResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetImpgInvoicesResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The i MPG invoice detail. */
	@JsonProperty("imp_g")
	private List<ImpgInvoiceDetail> impgInvoiceDetails;

	/**
	 * Gets the impg invoice details.
	 *
	 * @return the impg invoice details
	 */
	public List<ImpgInvoiceDetail> getImpgInvoiceDetails() {
		return impgInvoiceDetails;
	}

	/**
	 * Sets the impg invoice details.
	 *
	 * @param impgInvoiceDetails
	 *            the new impg invoice details
	 */
	public void setImpgInvoiceDetails(List<ImpgInvoiceDetail> impgInvoiceDetails) {
		this.impgInvoiceDetails = impgInvoiceDetails;
	}

}
