package com.mind.egsp.gstn.dto.gstr2;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.model.gstr2.AmendedTaxliabilityDetail;
import com.mind.egsp.gstn.model.gstr2.Gstr2B2bInvoice;
import com.mind.egsp.gstn.model.gstr2.Gstr2B2baInvoice;
import com.mind.egsp.gstn.model.gstr2.Gstr2B2burInvoice;
import com.mind.egsp.gstn.model.gstr2.Gstr2B2buraInvoice;
import com.mind.egsp.gstn.model.gstr2.Gstr2CdnInvoice;
import com.mind.egsp.gstn.model.gstr2.Gstr2CdnaInvoice;
import com.mind.egsp.gstn.model.gstr2.Gstr2CdnurInvoice;
import com.mind.egsp.gstn.model.gstr2.Gstr2HsnSummaries;
import com.mind.egsp.gstn.model.gstr2.Gstr2InvNotPaidInvoice;
import com.mind.egsp.gstn.model.gstr2.Gstr2InvPaidLaterInvoice;
import com.mind.egsp.gstn.model.gstr2.Gstr2ItcReversalInvoice;
import com.mind.egsp.gstn.model.gstr2.Gstr2NilSupply;
import com.mind.egsp.gstn.model.gstr2.ImpgInvoiceDetail;
import com.mind.egsp.gstn.model.gstr2.ImpgaInvoiceDetail;
import com.mind.egsp.gstn.model.gstr2.ImpsInvoiceDetail;
import com.mind.egsp.gstn.model.gstr2.ImpsaInvoiceDetail;
import com.mind.egsp.gstn.model.gstr2.ItcReceived;
import com.mind.egsp.gstn.model.gstr2.TaxliabilityDetail;

// TODO: Auto-generated Javadoc
/**
 * The Class SaveGstr2DTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class SaveGstr2DTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The GSTIN of the Tax Payer. */
	private String gstin;

	/** The Financial period. */
	private String fp;

	/** The B2B Invoices. */
	@JsonProperty("b2b")
	private List<Gstr2B2bInvoice> b2bInvoices;

	/** The B2BA Invoices. */
	@JsonProperty("b2ba")
	private List<Gstr2B2baInvoice> b2baInvoices;

	/** The import of goods invoices. */
	@JsonProperty("imp_g")
	private List<ImpgInvoiceDetail> impgInvoiceDetails;

	/** Amended imp of goods Invoices. */
	@JsonProperty("imp_ga")
	private List<ImpgaInvoiceDetail> impgaInvoiceDetails;

	/** The imp of services bills. */
	@JsonProperty("imp_s")
	private List<ImpsInvoiceDetail> impsInvoiceDetails;

	/** The Amended imp of services bills. */
	@JsonProperty("imp_sa")
	private List<ImpsaInvoiceDetail> impsaInvoiceDetails;

	/** The CDN Invoices. */
	@JsonProperty("cdn")
	private List<Gstr2CdnInvoice> cdnInvoices;

	/** The CDNA Invoices. */
	@JsonProperty("cdna")
	private List<Gstr2CdnaInvoice> cdnaInvoices;

	/** The Nil Rated invoices. */
	@JsonProperty("nil_supplies")
	private Gstr2NilSupply nilSupplies;

	/** The ITC Partial Credit. */
	@JsonProperty("itc_rcd")
	private List<ItcReceived> itcReceiveds;

	/** The Tax Liability under reverse charge. */
	@JsonProperty("txi")
	private List<TaxliabilityDetail> taxliabilityDetails;

	/** The Amended Tax Liability under reverse charge. */
	@JsonProperty("atxi")
	private List<AmendedTaxliabilityDetail> amendedTaxliabilityDetails;

	/** The Tax Paid Under Reverse Charge. */
	@JsonProperty("txpd")
	private List<TaxliabilityDetail> taxPaidUnderReverseCharges;

	/** The HSN summary of outward supplies. */
	@JsonProperty("hsnsum")
	private Gstr2HsnSummaries hsnSummaries;

	/** The B2B Unregistered Invoices. */
	@JsonProperty("b2bur")
	private List<Gstr2B2burInvoice> b2burInvoices;

	/** The B2BA Unregistered Invoices. */
	@JsonProperty("b2bura")
	private List<Gstr2B2buraInvoice> b2buraInvoices;

	/** The CDN Invoices. */
	@JsonProperty("cdnur")
	private List<Gstr2CdnurInvoice> cdnurInvoices;

	/** The ITC Reversal Invoices. */
	@JsonProperty("itc_rvsl")
	private Gstr2ItcReversalInvoice itcReversalInvoice;

	/** The ITC Reversal Amendments Invoices. */
	@JsonProperty("itc_rvsla")
	private List<Gstr2ItcReversalInvoice> itcReversalAmdInvoices;

	/** The Invoice Paid Later Invoices. */
	@JsonProperty("inv_pd")
	private List<Gstr2InvPaidLaterInvoice> invPaidLaterInvoices;

	/** The Invoice Not Paid Invoices. */
	@JsonProperty("inv_upd")
	private List<Gstr2InvNotPaidInvoice> invNotPaidInvoices;

	/**
	 * Gets the gstin.
	 *
	 * @return the gstin
	 */
	public String getGstin() {
		return gstin;
	}

	/**
	 * Sets the gstin.
	 *
	 * @param gstin
	 *            the new gstin
	 */
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the Financial period Field Specification: String (MMYYYY) Sample
	 * Data: 082016 .
	 *
	 * @return the fp
	 */
	public String getFp() {
		return fp;
	}

	/**
	 * Sets the Financial period Field Specification: String (MMYYYY) Sample
	 * Data: 082016 .
	 *
	 * @param fp
	 *            the new fp
	 */
	public void setFp(String fp) {
		this.fp = fp;
	}



	/**
	 * Gets the B2B invoices.
	 *
	 * @return the B2B invoices
	 */
	public List<Gstr2B2bInvoice> getB2bInvoices() {
		return b2bInvoices;
	}

	/**
	 * Sets the B2B invoices.
	 *
	 * @param b2bInvoices
	 *            the new B2Binvoices
	 */
	public void setB2bInvoices(List<Gstr2B2bInvoice> b2bInvoices) {
		this.b2bInvoices = b2bInvoices;
	}

	/**
	 * Gets the B2BA Invoices.
	 *
	 * @return the B2BA Invoices
	 */
	public List<Gstr2B2baInvoice> getB2baInvoices() {
		return b2baInvoices;
	}

	/**
	 * Sets the B2BA Invoices.
	 *
	 * @param b2baInvoices
	 *            the new B2BA Invoices
	 */
	public void setB2baInvoices(List<Gstr2B2baInvoice> b2baInvoices) {
		this.b2baInvoices = b2baInvoices;
	}

	/**
	 * Gets the Import of goods Invoices.
	 *
	 * @return the Import of goods Invoices
	 */
	public List<ImpgInvoiceDetail> getImpgInvoiceDetails() {
		return impgInvoiceDetails;
	}

	/**
	 * Sets the Import of goods Invoices.
	 *
	 * @param impgInvoiceDetails
	 *            the new Import of goods Invoices
	 */
	public void setImpgInvoiceDetails(List<ImpgInvoiceDetail> impgInvoiceDetails) {
		this.impgInvoiceDetails = impgInvoiceDetails;
	}

	/**
	 * Gets the Ammended imp of goods Invoices.
	 *
	 * @return the Ammended imp of goods Invoices
	 */
	public List<ImpgaInvoiceDetail> getImpgaInvoiceDetails() {
		return impgaInvoiceDetails;
	}

	/**
	 * Sets the Amended imp of goods Invoices.
	 *
	 * @param impgaInvoiceDetails
	 *            the new Amended imp of goods Invoices
	 */
	public void setImpgaInvoiceDetails(List<ImpgaInvoiceDetail> impgaInvoiceDetails) {
		this.impgaInvoiceDetails = impgaInvoiceDetails;
	}

	/**
	 * Gets the Imp of services bills.
	 *
	 * @return the Imp of services bills
	 */
	public List<ImpsInvoiceDetail> getImpsInvoiceDetails() {
		return impsInvoiceDetails;
	}

	/**
	 * Sets the Imp of services bills.
	 *
	 * @param impsInvoiceDetails
	 *            the new Imp of services bills
	 */
	public void setImpsInvoiceDetails(List<ImpsInvoiceDetail> impsInvoiceDetails) {
		this.impsInvoiceDetails = impsInvoiceDetails;
	}

	/**
	 * Gets the Ammended imp of services bills.
	 *
	 * @return the Ammended imp of services bills
	 */
	public List<ImpsaInvoiceDetail> getImpsaInvoiceDetails() {
		return impsaInvoiceDetails;
	}

	/**
	 * Sets the Ammended imp of services bills.
	 *
	 * @param impsaInvoiceDetails
	 *            the new Ammended imp of services bills
	 */
	public void setImpsaInvoiceDetails(List<ImpsaInvoiceDetail> impsaInvoiceDetails) {
		this.impsaInvoiceDetails = impsaInvoiceDetails;
	}

	/**
	 * Gets the cdn invoices.
	 *
	 * @return the cdn invoices
	 */
	public List<Gstr2CdnInvoice> getCdnInvoices() {
		return cdnInvoices;
	}

	/**
	 * Sets the cdn invoices.
	 *
	 * @param cdnInvoices
	 *            the new cdn invoices
	 */
	public void setCdnInvoices(List<Gstr2CdnInvoice> cdnInvoices) {
		this.cdnInvoices = cdnInvoices;
	}

	/**
	 * Gets the cdna invoices.
	 *
	 * @return the cdna invoices
	 */
	public List<Gstr2CdnaInvoice> getCdnaInvoices() {
		return cdnaInvoices;
	}

	/**
	 * Sets the cdna invoices.
	 *
	 * @param cdnaInvoices
	 *            the new cdna invoices
	 */
	public void setCdnaInvoices(List<Gstr2CdnaInvoice> cdnaInvoices) {
		this.cdnaInvoices = cdnaInvoices;
	}

	/**
	 * Gets the nil supplies.
	 *
	 * @return the nil supplies
	 */
	public Gstr2NilSupply getNilSupplies() {
		return nilSupplies;
	}

	/**
	 * Sets the nil supplies.
	 *
	 * @param nilSupplies
	 *            the new nil supplies
	 */
	public void setNilSupplies(Gstr2NilSupply nilSupplies) {
		this.nilSupplies = nilSupplies;
	}

	/**
	 * Gets the itc receiveds.
	 *
	 * @return the itc receiveds
	 */
	public List<ItcReceived> getItcReceiveds() {
		return itcReceiveds;
	}

	/**
	 * Sets the itc receiveds.
	 *
	 * @param itcReceiveds
	 *            the new itc receiveds
	 */
	public void setItcReceiveds(List<ItcReceived> itcReceiveds) {
		this.itcReceiveds = itcReceiveds;
	}

	/**
	 * Gets the taxliability details.
	 *
	 * @return the taxliability details
	 */
	public List<TaxliabilityDetail> getTaxliabilityDetails() {
		return taxliabilityDetails;
	}

	/**
	 * Sets the taxliability details.
	 *
	 * @param taxliabilityDetails
	 *            the new taxliability details
	 */
	public void setTaxliabilityDetails(List<TaxliabilityDetail> taxliabilityDetails) {
		this.taxliabilityDetails = taxliabilityDetails;
	}

	/**
	 * Gets the amended taxliability details.
	 *
	 * @return the amended taxliability details
	 */
	public List<AmendedTaxliabilityDetail> getAmendedTaxliabilityDetails() {
		return amendedTaxliabilityDetails;
	}

	/**
	 * Sets the amended taxliability details.
	 *
	 * @param amendedTaxliabilityDetails
	 *            the new amended taxliability details
	 */
	public void setAmendedTaxliabilityDetails(List<AmendedTaxliabilityDetail> amendedTaxliabilityDetails) {
		this.amendedTaxliabilityDetails = amendedTaxliabilityDetails;
	}

	/**
	 * Gets the tax paid under reverse charges.
	 *
	 * @return the tax paid under reverse charges
	 */
	public List<TaxliabilityDetail> getTaxPaidUnderReverseCharges() {
		return taxPaidUnderReverseCharges;
	}

	/**
	 * Sets the tax paid under reverse charges.
	 *
	 * @param taxPaidUnderReverseCharges
	 *            the new tax paid under reverse charges
	 */
	public void setTaxPaidUnderReverseCharges(List<TaxliabilityDetail> taxPaidUnderReverseCharges) {
		this.taxPaidUnderReverseCharges = taxPaidUnderReverseCharges;
	}

	/**
	 * Gets the hsn summaries.
	 *
	 * @return the hsn summaries
	 */
	public Gstr2HsnSummaries getHsnSummaries() {
		return hsnSummaries;
	}

	/**
	 * Sets the hsn summaries.
	 *
	 * @param hsnSummaries
	 *            the new hsn summaries
	 */
	public void setHsnSummaries(Gstr2HsnSummaries hsnSummaries) {
		this.hsnSummaries = hsnSummaries;
	}

	/**
	 * Gets the cdnur invoices.
	 *
	 * @return the cdnur invoices
	 */
	public List<Gstr2CdnurInvoice> getCdnurInvoices() {
		return cdnurInvoices;
	}

	/**
	 * Sets the cdnur invoices.
	 *
	 * @param cdnurInvoices
	 *            the new cdnur invoices
	 */
	public void setCdnurInvoices(List<Gstr2CdnurInvoice> cdnurInvoices) {
		this.cdnurInvoices = cdnurInvoices;
	}

	/**
	 * Gets the B2B Unregistered Invoices.
	 *
	 * @return the B2B Unregistered Invoices
	 */
	public List<Gstr2B2burInvoice> getB2burInvoices() {
		return b2burInvoices;
	}

	/**
	 * Sets the B2B Unregistered Invoices.
	 *
	 * @param b2burInvoices
	 *            the new B2B Unregistered Invoices
	 */
	public void setB2burInvoices(List<Gstr2B2burInvoice> b2burInvoices) {
		this.b2burInvoices = b2burInvoices;
	}

	/**
	 * Gets the B2BA Unregistered Invoices.
	 *
	 * @return the B2BA Unregistered Invoices
	 */
	public List<Gstr2B2buraInvoice> getB2buraInvoices() {
		return b2buraInvoices;
	}

	/**
	 * Sets the B2BA Unregistered Invoices.
	 *
	 * @param b2buraInvoices
	 *            the new B2BA Unregistered Invoices
	 */
	public void setB2buraInvoices(List<Gstr2B2buraInvoice> b2buraInvoices) {
		this.b2buraInvoices = b2buraInvoices;
	}


	/**
	 * Gets the itc reversal invoice.
	 *
	 * @return the itc reversal invoice
	 */
	public Gstr2ItcReversalInvoice getItcReversalInvoice() {
		return itcReversalInvoice;
	}

	/**
	 * Sets the itc reversal invoice.
	 *
	 * @param itcReversalInvoice
	 *            the new itc reversal invoice
	 */
	public void setItcReversalInvoice(Gstr2ItcReversalInvoice itcReversalInvoice) {
		this.itcReversalInvoice = itcReversalInvoice;
	}

	/**
	 * Gets the itc reversal amd invoices.
	 *
	 * @return the itc reversal amd invoices
	 */
	public List<Gstr2ItcReversalInvoice> getItcReversalAmdInvoices() {
		return itcReversalAmdInvoices;
	}

	/**
	 * Sets the itc reversal amd invoices.
	 *
	 * @param itcReversalAmdInvoices
	 *            the new itc reversal amd invoices
	 */
	public void setItcReversalAmdInvoices(List<Gstr2ItcReversalInvoice> itcReversalAmdInvoices) {
		this.itcReversalAmdInvoices = itcReversalAmdInvoices;
	}

	/**
	 * Gets the inv paid later invoices.
	 *
	 * @return the inv paid later invoices
	 */
	public List<Gstr2InvPaidLaterInvoice> getInvPaidLaterInvoices() {
		return invPaidLaterInvoices;
	}

	/**
	 * Sets the inv paid later invoices.
	 *
	 * @param invPaidLaterInvoices
	 *            the new inv paid later invoices
	 */
	public void setInvPaidLaterInvoices(List<Gstr2InvPaidLaterInvoice> invPaidLaterInvoices) {
		this.invPaidLaterInvoices = invPaidLaterInvoices;
	}

	/**
	 * Gets the inv not paid invoices.
	 *
	 * @return the inv not paid invoices
	 */
	public List<Gstr2InvNotPaidInvoice> getInvNotPaidInvoices() {
		return invNotPaidInvoices;
	}

	/**
	 * Sets the inv not paid invoices.
	 *
	 * @param invNotPaidInvoices
	 *            the new inv not paid invoices
	 */
	public void setInvNotPaidInvoices(List<Gstr2InvNotPaidInvoice> invNotPaidInvoices) {
		this.invNotPaidInvoices = invNotPaidInvoices;
	}

}
