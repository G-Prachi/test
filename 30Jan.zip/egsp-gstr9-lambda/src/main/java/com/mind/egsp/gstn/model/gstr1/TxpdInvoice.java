package com.mind.egsp.gstn.model.gstr1;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Class TxpdInvoicesDetail.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class TxpdInvoice implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Invoice tax payer action. */
	private String flag;

	/** The pos. */
	private String pos;

	/** The sply ty. */
	@JsonProperty("sply_ty")
	private String splyTy;

	/** The Invoice Check sum value Field. */
	private String chksum;

	/** The Invoice type. */
	@JsonIgnore
	private String typ;

	/** The Counter Party GSTIN / Name. */
	@JsonIgnore
	private String cpty;

	/** The Invoice date. */
	@JsonIgnore
	private String idt;

	/** The Supplier Invoice Number. */
	@JsonIgnore
	private String inum;

	/** The Supplier Document Number. */

	// @JsonProperty("doc_num")
	@JsonIgnore
	private String docNum;

	/** The Supplier Document Date. */
	// @JsonProperty("doc_dt")
	@JsonIgnore
	private String docDt;

	/** TheIGST Rate as per invoice. */
	@JsonIgnore
	private BigDecimal irt;

	/** The IGST Amount as per invoice. */
	@JsonIgnore
	private BigDecimal iamt;

	/** The CGST Rate as per invoice. */
	@JsonIgnore
	private BigDecimal crt;

	/** The CGST Amount as per invoice. */
	@JsonIgnore
	private BigDecimal camt;

	/** The SGST Rate as per invoice. */
	@JsonIgnore
	private BigDecimal srt;

	/** The SGST Amount as per invoice. */
	@JsonIgnore
	private BigDecimal samt;

	/** The Cess Rate. */
	@JsonIgnore
	private BigDecimal csrt;

	/** The Cess Amount. */
	@JsonIgnore
	private BigDecimal csamt;

	@JsonProperty("diff_percent")
	private BigDecimal diffPercent;

	/** The txpd item detail. */
	@JsonProperty("itms")
	private List<TxpdItemDetail> txpdItemDetail;

	/**
	 * Gets the Invoice Check sum value
	 * 
	 * Field Specification: String (Max length:15)
	 * 
	 * Sample Data: AflJufPlFStqKBZ.
	 *
	 * @return the chksum
	 */
	public String getChksum() {
		return chksum;
	}

	/**
	 * Sets the Invoice Check sum value
	 * 
	 * Field Specification: String (Max length:15)
	 * 
	 * Sample Data: AflJufPlFStqKBZ.
	 *
	 * @param chksum
	 *            the new chksum
	 */
	public void setChksum(String chksum) {
		this.chksum = chksum;
	}

	/**
	 * Gets the Invoice type
	 * 
	 * Field Specification: String (Max length:3) B2B/ B2C
	 * 
	 * Sample Data: B2B .
	 *
	 * @return the typ
	 */
	public String getTyp() {
		return typ;
	}

	/**
	 * Sets the Invoice type
	 * 
	 * Field Specification: String (Max length:3) B2B/ B2C
	 * 
	 * Sample Data: B2B .
	 *
	 * @param typ
	 *            the new typ
	 */
	public void setTyp(String typ) {
		this.typ = typ;
	}

	/**
	 * Gets the Counter Party GSTIN / Name
	 * 
	 * Field Specification: Alphanumeric (Max length:50)
	 * 
	 * Sample Data: 27ABCDE7588L1ZJ .
	 *
	 * @return the cpty
	 */
	public String getCpty() {
		return cpty;
	}

	/**
	 * Sets the Counter Party GSTIN / Name
	 * 
	 * Field Specification: Alphanumeric (Max length:50)
	 * 
	 * Sample Data: 27ABCDE7588L1ZJ.
	 *
	 * @param cpty
	 *            the new cpty
	 */
	public void setCpty(String cpty) {
		this.cpty = cpty;
	}

	/**
	 * Gets the Invoice date
	 * 
	 * Field Specification: string (DD-MM-YYYY)
	 * 
	 * Sample Data: 26-06-2016 .
	 *
	 * @return the idt
	 */
	public String getIdt() {
		return idt;
	}

	/**
	 * Sets the Invoice date
	 * 
	 * Field Specification: string (DD-MM-YYYY)
	 * 
	 * Sample Data: 26-06-2016 .
	 *
	 * @param idt
	 *            the new idt
	 */
	public void setIdt(String idt) {
		this.idt = idt;
	}

	/**
	 * Gets the Supplier Invoice Number
	 * 
	 * Field Specification: Alphanumeric (Max length:50)
	 * 
	 * Sample Data: S008400 .
	 *
	 * @return the inum
	 */
	public String getInum() {
		return inum;
	}

	/**
	 * the Supplier Invoice Number
	 * 
	 * Field Specification: Alphanumeric (Max length:50)
	 * 
	 * Sample Data: S008400 .
	 *
	 * @param inum
	 *            the new inum
	 * @return the inum
	 */
	public void setInum(String inum) {
		this.inum = inum;
	}

	/**
	 * Gets the Supplier Document Number
	 * 
	 * Field Specification: Alphanumeric (Max length:50)
	 * 
	 * Sample Data: 100012 .
	 *
	 * @return the doc num
	 */
	public String getDocNum() {
		return docNum;
	}

	/**
	 * Sets the Supplier Document Number
	 * 
	 * Field Specification: Alphanumeric (Max length:50)
	 * 
	 * Sample Data: 100012 .
	 *
	 * @param docNum
	 *            the new doc num
	 */
	public void setDocNum(String docNum) {
		this.docNum = docNum;
	}

	/**
	 * Gets the Supplier Document Date
	 * 
	 * Field Specification: string (DD-MM-YYYY)
	 * 
	 * Sample Data: 26-06-2016 .
	 *
	 * @return the doc dt
	 */
	public String getDocDt() {
		return docDt;
	}

	/**
	 * Sets the Supplier Document Date
	 * 
	 * Field Specification: string (DD-MM-YYYY) S ample Data: 26-06-2016 .
	 *
	 * @param docDt
	 *            the new doc dt
	 */
	public void setDocDt(String docDt) {
		this.docDt = docDt;
	}

	/**
	 * Gets the IGST Rate as per invoice
	 * 
	 * Field Specification: Decimal(p,2)
	 * 
	 * Sample Data: 10.00.
	 *
	 * @return the irt
	 */
	public BigDecimal getIrt() {
		return irt;
	}

	/**
	 * Sets the IGST Rate as per invoice
	 * 
	 * Field Specification: Decimal(p,2)
	 * 
	 * Sample Data: 10.00.
	 *
	 * @param irt
	 *            the new irt
	 */
	public void setIrt(BigDecimal irt) {
		this.irt = irt;
	}

	/**
	 * Gets the IGST Amount as per invoice
	 * 
	 * Field Specification: Decimal(p,2)
	 * 
	 * Sample Data: 1000.00 .
	 *
	 * @return the iamt
	 */
	public BigDecimal getIamt() {
		return iamt;
	}

	/**
	 * Sets the IGST Amount as per invoice
	 * 
	 * Field Specification: Decimal(p,2)
	 * 
	 * Sample Data: 1000.00 .
	 *
	 * @param iamt
	 *            the new iamt
	 */
	public void setIamt(BigDecimal iamt) {
		this.iamt = iamt;
	}

	/**
	 * Gets the CGST Rate as per invoice
	 * 
	 * Field Specification: Decimal(p,2)
	 * 
	 * Sample Data: 10.00 .
	 *
	 * @return the crt
	 */
	public BigDecimal getCrt() {
		return crt;
	}

	/**
	 * Sets the CGST Rate as per invoice
	 * 
	 * Field Specification: Decimal(p,2)
	 * 
	 * Sample Data: 10.00 .
	 *
	 * @param crt
	 *            the new crt
	 */
	public void setCrt(BigDecimal crt) {
		this.crt = crt;
	}

	/**
	 * Gets the CGST Amount as per invoice
	 * 
	 * Field Specification: Decimal(p,2)
	 * 
	 * Sample Data: 1000.00 .
	 *
	 * @return the camt
	 */
	public BigDecimal getCamt() {
		return camt;
	}

	/**
	 * Sets the CGST Amount as per invoice
	 * 
	 * Field Specification: Decimal(p,2)
	 * 
	 * Sample Data: 1000.00 .
	 *
	 * @param camt
	 *            the new camt
	 */
	public void setCamt(BigDecimal camt) {
		this.camt = camt;
	}

	/**
	 * Gets the SGST Rate as per invoice
	 * 
	 * Field Specification: Decimal(p,2)
	 * 
	 * Sample Data: 10.00 .
	 *
	 * @return the srt
	 */
	public BigDecimal getSrt() {
		return srt;
	}

	/**
	 * Sets the SGST Rate as per invoice
	 * 
	 * Field Specification: Decimal(p,2)
	 * 
	 * Sample Data: 10.00 .
	 *
	 * @param srt
	 *            the new srt
	 */
	public void setSrt(BigDecimal srt) {
		this.srt = srt;
	}

	/**
	 * Gets the SGST Amount as per invoice
	 * 
	 * Field Specification: Decimal(p,2)
	 * 
	 * Sample Data: 1000.00 .
	 *
	 * @return the samt
	 */
	public BigDecimal getSamt() {
		return samt;
	}

	/**
	 * Sets the SGST Amount as per invoice
	 * 
	 * Field Specification: Decimal(p,2)
	 * 
	 * Sample Data: 1000.00 .
	 *
	 * @param samt
	 *            the new samt
	 */
	public void setSamt(BigDecimal samt) {
		this.samt = samt;
	}

	/**
	 * Gets the Cess Rate
	 * 
	 * Field Specification: Decimal(p,2)
	 * 
	 * Sample Data: 10.00 .
	 *
	 * @return the csrt
	 */
	public BigDecimal getCsrt() {
		return csrt;
	}

	/**
	 * Sets the Cess Rate
	 * 
	 * Field Specification: Decimal(p,2)
	 * 
	 * Sample Data: 10.00 .
	 *
	 * @param csrt
	 *            the new csrt
	 */
	public void setCsrt(BigDecimal csrt) {
		this.csrt = csrt;
	}

	/**
	 * Gets the Cess Amount
	 * 
	 * Field Specification: Decimal(p,2)
	 * 
	 * Sample Data: 1000.00 .
	 *
	 * @return the csamt
	 */
	public BigDecimal getCsamt() {
		return csamt;
	}

	/**
	 * Sets the Cess Amount
	 * 
	 * Field Specification: Decimal(p,2)
	 * 
	 * Sample Data: 1000.00 .
	 *
	 * @param csamt
	 *            the new csamt
	 */
	public void setCsamt(BigDecimal csamt) {
		this.csamt = csamt;
	}

	/**
	 * Gets the flag.
	 *
	 * @return the flag
	 */
	public String getFlag() {
		return flag;
	}

	/**
	 * Sets the flag.
	 *
	 * @param flag
	 *            the new flag
	 */
	public void setFlag(String flag) {
		this.flag = flag;
	}

	/**
	 * Gets the pos.
	 *
	 * @return the pos
	 */
	public String getPos() {
		return pos;
	}

	/**
	 * Sets the pos.
	 *
	 * @param pos
	 *            the new pos
	 */
	public void setPos(String pos) {
		this.pos = pos;
	}

	/**
	 * Gets the sply ty.
	 *
	 * @return the sply ty
	 */
	public String getSplyTy() {
		return splyTy;
	}

	/**
	 * Sets the sply ty.
	 *
	 * @param splyTy
	 *            the new sply ty
	 */
	public void setSplyTy(String splyTy) {
		this.splyTy = splyTy;
	}

	/**
	 * Gets the txpd item detail.
	 *
	 * @return the txpd item detail
	 */
	public List<TxpdItemDetail> getTxpdItemDetail() {
		return txpdItemDetail;
	}

	/**
	 * Sets the txpd item detail.
	 *
	 * @param txpdItemDetail
	 *            the new txpd item detail
	 */
	public void setTxpdItemDetail(List<TxpdItemDetail> txpdItemDetail) {
		this.txpdItemDetail = txpdItemDetail;
	}

	public BigDecimal getDiffPercent() {
		return diffPercent;
	}

	public void setDiffPercent(BigDecimal diffPercent) {
		this.diffPercent = diffPercent;
	}

}
