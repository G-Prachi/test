package com.mind.egsp.gstn.dto.gstr;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.all.URLListData;

/**
 * The Class GetFileDetailResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetFileDetailResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The fc. */
	private String fc;

	private String ek;

	/** The url list datas. */
	@JsonProperty("urls")
	List<URLListData> urlListDatas;

	/**
	 * Gets the fc.
	 *
	 * @return the fc
	 */
	public String getFc() {
		return fc;
	}

	/**
	 * Sets the fc.
	 *
	 * @param fc
	 *            the new fc
	 */
	public void setFc(String fc) {
		this.fc = fc;
	}

	/**
	 * Gets the url list datas.
	 *
	 * @return the url list datas
	 */
	public List<URLListData> getUrlListDatas() {
		return urlListDatas;
	}

	/**
	 * Sets the url list datas.
	 *
	 * @param urlListDatas
	 *            the new url list datas
	 */
	public void setUrlListDatas(List<URLListData> urlListDatas) {
		this.urlListDatas = urlListDatas;
	}

	public String getEk() {
		return ek;
	}

	public void setEk(String ek) {
		this.ek = ek;
	}

}
