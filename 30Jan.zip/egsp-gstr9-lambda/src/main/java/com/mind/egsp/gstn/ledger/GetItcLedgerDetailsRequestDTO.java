package com.mind.egsp.gstn.ledger;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

/**
 * The Class GetITCLedgerDetailsRequestDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetItcLedgerDetailsRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The From Date. */
	@JsonProperty("fr_dt")
	private String frDt;

	/** The To Date. */
	@JsonProperty("to_dt")
	private String toDt;

	/**
	 * Instantiates a new gets the cash ledger details request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param gstin
	 *            the gstin
	 * @param retPeriod
	 *            the ret period
	 * @param username
	 *            the username
	 */
	public GetItcLedgerDetailsRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	/**
	 * Gets the From Date.
	 *
	 * @return the From Datet
	 */
	public String getFrDt() {
		return frDt;
	}

	/**
	 * Sets the From Date. Format: string(DD/MM/YYYY)
	 *
	 * @param frDt
	 *            the new From Date
	 */
	public void setFrDt(String frDt) {
		this.frDt = frDt;
	}

	/**
	 * Gets the To Date.
	 *
	 * @return the To Date
	 */
	public String getToDt() {
		return toDt;
	}

	/**
	 * Sets the To Date. Format: string(DD/MM/YYYY)
	 *
	 * @param toDt
	 *            the new To Date
	 */
	public void setToDt(String toDt) {
		this.toDt = toDt;
	}

}
