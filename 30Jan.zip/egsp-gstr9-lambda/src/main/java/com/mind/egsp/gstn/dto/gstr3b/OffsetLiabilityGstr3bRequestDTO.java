package com.mind.egsp.gstn.dto.gstr3b;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseRequestDTO;


/**
 * The Offset Liability GSTR3B Data Request DTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class OffsetLiabilityGstr3bRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	@JsonProperty("data")
	private OffsetLiabilityRequestDTO offsetLiabilityRequestDTO;


	public OffsetLiabilityGstr3bRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username, Long clientId, Long businessTypeId) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username, clientId, businessTypeId);
	}


	public OffsetLiabilityRequestDTO getOffsetLiabilityRequestDTO() {
		return offsetLiabilityRequestDTO;
	}

	public void setOffsetLiabilityRequestDTO(OffsetLiabilityRequestDTO offsetLiabilityRequestDTO) {
		this.offsetLiabilityRequestDTO = offsetLiabilityRequestDTO;
	}

}
