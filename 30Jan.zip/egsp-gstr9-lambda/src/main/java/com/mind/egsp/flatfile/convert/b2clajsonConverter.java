package com.mind.egsp.flatfile.convert;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.amazonaws.services.s3.AmazonS3;
import com.egsp.finalDTOs.B2bInvoiceDetailFlat;
import com.egsp.finalDTOs.B2bInvoiceFlat;
import com.egsp.finalDTOs.B2bInvoiceFlatFinal;
import com.egsp.finalDTOs.B2baInvoiceDetailFlat;
import com.egsp.finalDTOs.B2baInvoiceFlat;
import com.egsp.finalDTOs.B2baInvoiceFlatFinal;
import com.egsp.finalDTOs.B2claInvoiceDetailFlat;
import com.egsp.finalDTOs.B2claInvoiceFlat;
import com.egsp.finalDTOs.B2claInvoiceFlatFinal;
import com.egsp.finalDTOs.SaveGstr1DTOFlat;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mind.egsp.gstn.dto.gstr1.SaveGstr1DTO;
import com.mind.egsp.gstn.dto.gstr1.StateB2ClaInvoice;
import com.mind.egsp.gstn.model.gstr1.B2bInvoice;
import com.mind.egsp.gstn.model.gstr1.B2bInvoiceDetail;
import com.mind.egsp.gstn.model.gstr1.B2bItem;
import com.mind.egsp.gstn.model.gstr1.B2clItem;
import com.mind.egsp.gstn.model.gstr1.B2claInvoice;
import com.mind.egsp.gstn.model.gstr1.B2claInvoiceDetail;
import com.mind.egsp.gstn.model.gstr1.B2claItem;

public class b2clajsonConverter {
		
	static List<B2claInvoiceDetailFlat> flatB2claDetiallist =  new ArrayList<B2claInvoiceDetailFlat>();		
	static List<B2claInvoiceFlat>  flatB2clalist = new ArrayList<B2claInvoiceFlat>();
	static List<B2claInvoiceFlatFinal> b2claInvFlatFinal = new ArrayList<B2claInvoiceFlatFinal>();
	
	public static String b2bJsonConverter(SaveGstr1DTO gstriObj,String bucketName,String filePath,String fileName,AmazonS3 s3, String str2)
	{
		//***************************Declaration for B2cla*************
		try
		{
				List<B2claInvoiceFlat>  flatB2blist = new ArrayList<B2claInvoiceFlat>();				
				//byte[] jsonData1 = Files.readAllBytes(Paths.get("B2b-sample.json"));
				//create ObjectMapper instance
				//ObjectMapper objectMapper = new ObjectMapper();
				SaveGstr1DTOFlat savedtoflat  = new SaveGstr1DTOFlat();
				//SaveGstr1DTO gstriObj = objectMapper.readValue(jsonData1, SaveGstr1DTO.class);
				savedtoflat.setFp(gstriObj.getFp());
				//B2BInvoice================				
				List<StateB2ClaInvoice> list = gstriObj.getStateB2ClaInvoicesList();
				List<B2claInvoiceDetailFlat> flatB2bDetiallist = new ArrayList<B2claInvoiceDetailFlat>();
			
				//System.out.println(list.size() +  "" + list.toString());		
				BigDecimal totaltxval = new BigDecimal(0);
				BigDecimal totaliamt = new BigDecimal(0);;
				BigDecimal totalcamt =new BigDecimal(0);
				BigDecimal totalsamt =new BigDecimal(0);
				BigDecimal totalcsamt = new BigDecimal(0);
				if(list!=null)
				{
				for(StateB2ClaInvoice item : list)
				{
					//flatB2bDetiallist = new ArrayList<B2bInvoiceDetailFlat>();
					B2claInvoiceFlat b2claflat = new B2claInvoiceFlat();
					b2claflat.setCtin(item.getCtin());
					for(B2claInvoiceDetail invDetail : item.getB2claInvoiceDetails()) {
						B2claInvoiceDetailFlat b2claInvoiceDetailFLat = new B2claInvoiceDetailFlat();
						b2claInvoiceDetailFLat.setInum(invDetail.getInum());
						b2claflat.setRchrg(invDetail.getRchrg());
						b2claflat.setInvTyp(invDetail.getInvTyp());
						b2claflat.setVal(invDetail.getVal());
						b2claInvoiceDetailFLat.setIdt(invDetail.getIdt());
						
						for (B2claItem item1 :invDetail.getB2claItems()){
							totaltxval = totaltxval.add(item1.getB2claItemDetail().getTxval());
							totaliamt = totaliamt.add(item1.getB2claItemDetail().getIamt());
							totalcamt = totalcamt.add(item1.getB2claItemDetail().getCamt());
							totalsamt = totalsamt.add(item1.getB2claItemDetail().getSamt());
							totalcsamt = totalcsamt.add(item1.getB2claItemDetail().getCsamt());
						    }
							b2claInvoiceDetailFLat.setTotaltxval(totaltxval);
							b2claInvoiceDetailFLat.setTotaliamt(totaliamt);
							b2claInvoiceDetailFLat.setTotalcamt(totalcamt);
							b2claInvoiceDetailFLat.setTotalcsamt(totalcsamt);
							b2claInvoiceDetailFLat.setTotalsamt(totalsamt);
							flatB2bDetiallist.add(b2claInvoiceDetailFLat);
					}
					b2claflat.setB2claInvoiceDetailFLat(flatB2bDetiallist);
					flatB2blist.add(b2claflat);
				}
//				System.out.println("flatB2blist "+flatB2blist);
					List<B2claInvoiceFlatFinal> b2clafinalList = new ArrayList<B2claInvoiceFlatFinal>();
					for(B2claInvoiceFlat flatList : flatB2clalist)
					{
						for(B2claInvoiceDetailFlat b2claInvoiceFlat : flatList.getB2claInvoiceDetailFLat()) {
							B2claInvoiceFlatFinal b2claInvoiceFlatFinal = new B2claInvoiceFlatFinal();
							b2claInvoiceFlatFinal.setFp(gstriObj.getFp());
							b2claInvoiceFlatFinal.setBusinessType("b2b");
							b2claInvoiceFlatFinal.setCtin(flatList.getCtin());
							//b2bInvoiceFlatFinal.setRchrg(flatList.getRchrg());
							b2claInvoiceFlatFinal.setInvTyp(flatList.getInvTyp());
							b2claInvoiceFlatFinal.setVal(flatList.getVal());
							b2claInvoiceFlatFinal.setInum(b2claInvoiceFlat.getInum());
							b2claInvoiceFlatFinal.setIdt(b2claInvoiceFlat.getIdt());
							b2claInvoiceFlatFinal.setTotalcamt(b2claInvoiceFlat.getTotalcamt());
							b2claInvoiceFlatFinal.setTotalcsamt(b2claInvoiceFlat.getTotalcsamt());
							b2claInvoiceFlatFinal.setTotaliamt(b2claInvoiceFlat.getTotaliamt());
							b2claInvoiceFlatFinal.setTotalsamt(b2claInvoiceFlat.getTotalsamt());
							b2claInvoiceFlatFinal.setTotaltxval(b2claInvoiceFlat.getTotaltxval());
							b2clafinalList.add(b2claInvoiceFlatFinal);
						}
					}
					
				final ByteArrayOutputStream out = new ByteArrayOutputStream();
			    final ObjectMapper mapper = new ObjectMapper();
			    
			    mapper.writeValue(out, b2clafinalList);
		        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		        StringBuilder tempFile = new StringBuilder();
		        Random rnd = new Random();
		        while (tempFile.length() < 18) { // length of the random string.
		            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
		            tempFile.append(SALTCHARS.charAt(index));
		        }
		        String tempFil = tempFile.toString();
		        File tempFileName = new File(tempFil+".json");
		        //return saltStr;
				mapper.writeValue(tempFileName, b2clafinalList);
				InputStream is = new FileInputStream(tempFileName);
				String contents = new BufferedReader(new InputStreamReader(is)).readLine();
				is.close(); 
				
					String str = contents.substring(1, contents.length()-1);
					String str1=str.replaceAll("},", "}\n");
					System.out.println(str1);
					str2= str2.concat(str1);
					return(str2);
					/*PrintWriter pr = new PrintWriter(new BufferedWriter(new FileWriter(new File(fileName), true)));
					pr.write(str1);
					pr.append("\n");
					pr.close();
					s3.putObject(bucketName, filePath+"/"+fileName, str1);
					System.out.println("sucess");*/
			    
			    
				}
		}
				catch(Exception ex)
				{
					
				}
		return (str2);
	}
}