package com.mind.egsp.gstn.dto.gstr8;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.model.gstr8.Gstr8B2bInvoice;
import com.mind.egsp.gstn.model.gstr8.Gstr8B2cInvoiceDetail;
import com.mind.egsp.gstn.model.gstr8.Gstr8B2caInvoiceDetail;
import com.mind.egsp.gstn.model.gstr8.Gstr8CdnrInvoice;
import com.mind.egsp.gstn.model.gstr8.Gstr8CdnraInvoice;
import com.mind.egsp.gstn.model.gstr8.Gstr8CdnurInvoice;
import com.mind.egsp.gstn.model.gstr8.Gstr8CdnuraInvoice;
import com.mind.egsp.gstn.model.gstr8.Gstr8TcsInvoicesDetail;
import com.mind.egsp.gstn.model.gstr8.Gstr8TcsaInvoicesDetail;

// TODO: Auto-generated Javadoc
/**
 * The Gstr8 Save DTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class SaveGstr8DTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The GSTIN of the Tax Payer. */
	private String gstin;

	/** Financial period. */
	private String fp;

	/** B2B Invoices. */
	@JsonProperty("b2b")
	private List<Gstr8B2bInvoice> b2bInvoices;

	/** The b 2 ba invoice. */
	@JsonProperty("b2ba")
	private List<Gstr8B2bInvoice> b2baInvoices;

	/** The B2c invoice. */
	@JsonProperty("b2c")
	private List<Gstr8B2cInvoiceDetail> b2cInvoicesList;

	/** The B2c Ammendments. */
	@JsonProperty("b2ca")
	private List<Gstr8B2caInvoiceDetail> b2caInvoicesList;

	/** The Credit Debit Notes Registered Users invoice. */
	@JsonProperty("cdnr")
	private List<Gstr8CdnrInvoice> cdnrInvoices;

	/** The amended Credit Debit Notes Registered Users invoice. */
	@JsonProperty("cdnra")
	private List<Gstr8CdnraInvoice> cdnraInvoices;

	/** The Credit Debit Notes Un-Registered TaxPayers. */
	@JsonProperty("cdnur")
	private List<Gstr8CdnurInvoice> cdnurInvoiceDetails;

	/** The Credit Debit Notes Amendments Un-Registered TaxPayers. */
	@JsonProperty("cdnura")
	private List<Gstr8CdnuraInvoice> cdnuraInvoiceDetails;

	/** Tax Collected at Source . */
	@JsonProperty("tcs")
	private List<Gstr8TcsInvoicesDetail> tcsInvoicesDetail;

	/** Tax Collected at Source Amendments. */
	@JsonProperty("tcsa")
	private List<Gstr8TcsaInvoicesDetail> tcsaInvoicesDetail;

	/**
	 * Gets the gstin.
	 *
	 * @return the gstin
	 */
	public String getGstin() {
		return gstin;
	}

	/**
	 * Sets the gstin.
	 *
	 * @param gstin
	 *            the new gstin
	 */
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the fp.
	 *
	 * @return the fp
	 */
	public String getFp() {
		return fp;
	}

	/**
	 * Sets the fp.
	 *
	 * @param fp
	 *            the new fp
	 */
	public void setFp(String fp) {
		this.fp = fp;
	}

	/**
	 * Gets the b 2 b invoices.
	 *
	 * @return the b 2 b invoices
	 */
	public List<Gstr8B2bInvoice> getB2bInvoices() {
		return b2bInvoices;
	}

	/**
	 * Sets the b 2 b invoices.
	 *
	 * @param b2bInvoices
	 *            the new b 2 b invoices
	 */
	public void setB2bInvoices(List<Gstr8B2bInvoice> b2bInvoices) {
		this.b2bInvoices = b2bInvoices;
	}

	/**
	 * Gets the b 2 ba invoices.
	 *
	 * @return the b 2 ba invoices
	 */
	public List<Gstr8B2bInvoice> getB2baInvoices() {
		return b2baInvoices;
	}

	/**
	 * Sets the b 2 ba invoices.
	 *
	 * @param b2baInvoices
	 *            the new b 2 ba invoices
	 */
	public void setB2baInvoices(List<Gstr8B2bInvoice> b2baInvoices) {
		this.b2baInvoices = b2baInvoices;
	}

	/**
	 * Gets the b 2 c invoices list.
	 *
	 * @return the b 2 c invoices list
	 */
	public List<Gstr8B2cInvoiceDetail> getB2cInvoicesList() {
		return b2cInvoicesList;
	}

	/**
	 * Sets the b 2 c invoices list.
	 *
	 * @param b2cInvoicesList
	 *            the new b 2 c invoices list
	 */
	public void setB2cInvoicesList(List<Gstr8B2cInvoiceDetail> b2cInvoicesList) {
		this.b2cInvoicesList = b2cInvoicesList;
	}

	/**
	 * Gets the b 2 ca invoices list.
	 *
	 * @return the b 2 ca invoices list
	 */
	public List<Gstr8B2caInvoiceDetail> getB2caInvoicesList() {
		return b2caInvoicesList;
	}

	/**
	 * Sets the b 2 ca invoices list.
	 *
	 * @param b2caInvoicesList
	 *            the new b 2 ca invoices list
	 */
	public void setB2caInvoicesList(List<Gstr8B2caInvoiceDetail> b2caInvoicesList) {
		this.b2caInvoicesList = b2caInvoicesList;
	}

	/**
	 * Gets the cdnr invoices.
	 *
	 * @return the cdnr invoices
	 */
	public List<Gstr8CdnrInvoice> getCdnrInvoices() {
		return cdnrInvoices;
	}

	/**
	 * Sets the cdnr invoices.
	 *
	 * @param cdnrInvoices
	 *            the new cdnr invoices
	 */
	public void setCdnrInvoices(List<Gstr8CdnrInvoice> cdnrInvoices) {
		this.cdnrInvoices = cdnrInvoices;
	}

	/**
	 * Gets the cdnra invoices.
	 *
	 * @return the cdnra invoices
	 */
	public List<Gstr8CdnraInvoice> getCdnraInvoices() {
		return cdnraInvoices;
	}

	/**
	 * Sets the cdnra invoices.
	 *
	 * @param cdnraInvoices
	 *            the new cdnra invoices
	 */
	public void setCdnraInvoices(List<Gstr8CdnraInvoice> cdnraInvoices) {
		this.cdnraInvoices = cdnraInvoices;
	}

	/**
	 * Gets the cdnur invoice details.
	 *
	 * @return the cdnur invoice details
	 */
	public List<Gstr8CdnurInvoice> getCdnurInvoiceDetails() {
		return cdnurInvoiceDetails;
	}

	/**
	 * Sets the cdnur invoice details.
	 *
	 * @param cdnurInvoiceDetails
	 *            the new cdnur invoice details
	 */
	public void setCdnurInvoiceDetails(List<Gstr8CdnurInvoice> cdnurInvoiceDetails) {
		this.cdnurInvoiceDetails = cdnurInvoiceDetails;
	}

	/**
	 * Gets the cdnura invoice details.
	 *
	 * @return the cdnura invoice details
	 */
	public List<Gstr8CdnuraInvoice> getCdnuraInvoiceDetails() {
		return cdnuraInvoiceDetails;
	}

	/**
	 * Sets the cdnura invoice details.
	 *
	 * @param cdnuraInvoiceDetails
	 *            the new cdnura invoice details
	 */
	public void setCdnuraInvoiceDetails(List<Gstr8CdnuraInvoice> cdnuraInvoiceDetails) {
		this.cdnuraInvoiceDetails = cdnuraInvoiceDetails;
	}

	/**
	 * Gets the tcs invoices detail.
	 *
	 * @return the tcs invoices detail
	 */
	public List<Gstr8TcsInvoicesDetail> getTcsInvoicesDetail() {
		return tcsInvoicesDetail;
	}

	/**
	 * Sets the tcs invoices detail.
	 *
	 * @param tcsInvoicesDetail
	 *            the new tcs invoices detail
	 */
	public void setTcsInvoicesDetail(List<Gstr8TcsInvoicesDetail> tcsInvoicesDetail) {
		this.tcsInvoicesDetail = tcsInvoicesDetail;
	}

	/**
	 * Gets the tcsa invoices detail.
	 *
	 * @return the tcsa invoices detail
	 */
	public List<Gstr8TcsaInvoicesDetail> getTcsaInvoicesDetail() {
		return tcsaInvoicesDetail;
	}

	/**
	 * Sets the tcsa invoices detail.
	 *
	 * @param tcsaInvoicesDetail
	 *            the new tcsa invoices detail
	 */
	public void setTcsaInvoicesDetail(List<Gstr8TcsaInvoicesDetail> tcsaInvoicesDetail) {
		this.tcsaInvoicesDetail = tcsaInvoicesDetail;
	}

}