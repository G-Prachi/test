package com.mind.egsp.gstn.model.gstr2a;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

// TODO: Auto-generated Javadoc
/**
 * The Class Gstr2B2BInvoice.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Gstr2AB2bInvoice implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The ctin. */
	private String ctin;

	/** The cfs. */
	private String cfs;

	/** The gstr 2 AB 2 b invoice details. */
	@JsonProperty("inv")
	private List<Gstr2AB2bInvoiceDetail> gstr2AB2bInvoiceDetails;

	/**
	 * Gets the ctin.
	 *
	 * @return the ctin
	 */
	public String getCtin() {
		return ctin;
	}

	/**
	 * Sets the ctin.
	 *
	 * @param ctin
	 *            the new ctin
	 */
	public void setCtin(String ctin) {
		this.ctin = ctin;
	}

	/**
	 * Gets the cfs.
	 *
	 * @return the cfs
	 */
	public String getCfs() {
		return cfs;
	}

	/**
	 * Sets the cfs.
	 *
	 * @param cfs
	 *            the new cfs
	 */
	public void setCfs(String cfs) {
		this.cfs = cfs;
	}

	/**
	 * Gets the gstr 2 AB 2 b invoice details.
	 *
	 * @return the gstr 2 AB 2 b invoice details
	 */
	public List<Gstr2AB2bInvoiceDetail> getGstr2AB2bInvoiceDetails() {
		return gstr2AB2bInvoiceDetails;
	}

	/**
	 * Sets the gstr 2 AB 2 b invoice details.
	 *
	 * @param gstr2ab2bInvoiceDetails
	 *            the new gstr 2 AB 2 b invoice details
	 */
	public void setGstr2AB2bInvoiceDetails(List<Gstr2AB2bInvoiceDetail> gstr2ab2bInvoiceDetails) {
		gstr2AB2bInvoiceDetails = gstr2ab2bInvoiceDetails;
	}

}
