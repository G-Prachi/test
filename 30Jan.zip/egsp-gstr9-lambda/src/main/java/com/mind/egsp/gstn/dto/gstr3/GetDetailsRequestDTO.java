package com.mind.egsp.gstn.dto.gstr3;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

/**
 * The Class GetGSTR3DetailsRequestDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class GetDetailsRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The ret_period URL Parameter. */
	private String finalParam;

	/**
	 * Instantiates a new gets the GSTR 3 details request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param gstin
	 *            the gstin
	 * @param retPeriod
	 *            the ret period
	 * @param username
	 *            the username
	 */
	public GetDetailsRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	/**
	 * Gets the final param.
	 *
	 * @return the final param
	 */
	public String getFinalParam() {
		return finalParam;
	}

	/**
	 * Sets the final param.
	 *
	 * @param finalParam
	 *            the new final param
	 */
	public void setFinalParam(String finalParam) {
		this.finalParam = finalParam;
	}

}
