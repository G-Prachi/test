package com.mind.egsp.gstn.dto.gstr9;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mind.egsp.gstn.dto.BaseRequestDTO;
import com.mind.egsp.gstn.dto.gstr1.SaveGstr1DTO;

/**
 * The Class SaveGstr9RequestDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class SaveGstr9RequestDTO extends BaseRequestDTO implements Serializable {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** HMAC-SHA256 of Base64 data using EK. */
	private String hmac;
	
	/** The save gstr 9 DTO. */
	@JsonProperty("data")
	private SaveGstr9DTO saveGstr9DTO;

	/**
	 * Instantiates a new save gstr 9 request DTO.
	 */
	public SaveGstr9RequestDTO() {
		super();
	}
	
	/**
	 * Instantiates a new save gstr 9 request DTO.
	 *
	 * @param stateCd the state cd
	 * @param ipUsr the ip usr
	 * @param txn the txn
	 * @param gstin the gstin
	 * @param retPeriod the ret period
	 * @param username the username
	 */
	public SaveGstr9RequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	/**
	 * Gets the hmac.
	 *
	 * @return the hmac
	 */
	public String getHmac() {
		return hmac;
	}

	/**
	 * Sets the hmac.
	 *
	 * @param hmac the new hmac
	 */
	public void setHmac(String hmac) {
		this.hmac = hmac;
	}

	/**
	 * Gets the save gstr 9 DTO.
	 *
	 * @return the save gstr 9 DTO
	 */
	public SaveGstr9DTO getSaveGstr9DTO() {
		return saveGstr9DTO;
	}

	/**
	 * Sets the save gstr 9 DTO.
	 *
	 * @param saveGstr9DTO the new save gstr 9 DTO
	 */
	public void setSaveGstr9DTO(SaveGstr9DTO saveGstr9DTO) {
		this.saveGstr9DTO = saveGstr9DTO;
	}
	
	
}
