package com.mind.egsp.gstn.dto.gstr2;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetTcsCreditRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The gstin URL Parameter. */
	private String gstin;

	/** The ret_period URL Parameter. */
	private String retPeriod;

	public GetTcsCreditRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	/**
	 * Gets the gstin.
	 *
	 * @return the gstin
	 */
	@Override
	public String getGstin() {
		return gstin;
	}

	/**
	 * Sets the GSTIN of the taxpayer.
	 * 
	 * Field Specification: Alphanumeric with 15 characters, Mandatory: Y
	 *
	 * @param gstin
	 *            the new gstin
	 */
	@Override
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the ret period.
	 *
	 * @return the ret period
	 */
	@Override
	public String getRetPeriod() {
		return retPeriod;
	}

	/**
	 * Sets the Return Period.
	 * 
	 * Field Specification: MMYYYY, Mandatory: Y
	 *
	 * @param retPeriod
	 *            the new ret period
	 */
	@Override
	public void setRetPeriod(String retPeriod) {
		this.retPeriod = retPeriod;
	}

}
