package com.mind.egsp.gstn.dto.gstr1;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.model.gstr1.AtInvoice;
import com.mind.egsp.gstn.model.gstr1.AtaInvoice;
import com.mind.egsp.gstn.model.gstr1.B2bInvoice;
import com.mind.egsp.gstn.model.gstr1.B2baInvoice;
import com.mind.egsp.gstn.model.gstr1.B2clInvoice;
import com.mind.egsp.gstn.model.gstr1.B2csInvoice;
import com.mind.egsp.gstn.model.gstr1.B2csaInvoice;
import com.mind.egsp.gstn.model.gstr1.CdnrInvoice;
import com.mind.egsp.gstn.model.gstr1.CdnraInvoice;
import com.mind.egsp.gstn.model.gstr1.CdnurInvoiceDetail;
import com.mind.egsp.gstn.model.gstr1.CdnuraInvoiceDetail;
import com.mind.egsp.gstn.model.gstr1.DocIssueInvoice;
import com.mind.egsp.gstn.model.gstr1.ExpInvoice;
import com.mind.egsp.gstn.model.gstr1.ExpaInvoice;
import com.mind.egsp.gstn.model.gstr1.HsnSummary;
import com.mind.egsp.gstn.model.gstr1.NilSupply;
import com.mind.egsp.gstn.model.gstr1.StateB2ClInvoices;
import com.mind.egsp.gstn.model.gstr1.TxpdInvoice;
import com.mind.egsp.gstn.model.gstr1.TxpdaInvoice;

// TODO: Auto-generated Javadoc
/**
 * The Gstr1 Save DTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class SaveGstr1DTO implements Serializable {


	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The GSTIN of the Tax Payer. */
	private String gstin;
	
	@JsonProperty("businessType")
	private String businesstype; 

	/** Financial period. */
	private String fp;

	/** Gross Turn Over. */
	private BigDecimal gt;

	/** Gross Turnover - April to June, 2017 . */
	@JsonProperty("cur_gt")
	private BigDecimal curGt;

	/** B2B Invoices (represents table 5 of GSTR1). */
	@JsonProperty("b2b")
	private List<B2bInvoice> b2bInvoices;

	/** The b 2 ba invoice. */
	@JsonProperty("b2ba")
	private List<B2baInvoice> b2baInvoices;

	/** The B2cl invoice. */
	@JsonProperty("b2cl")
	private List<StateB2ClInvoices> stateB2ClInvoicesList;

	/** The B2cla invoice. */
	@JsonProperty("b2cla")
	private List<StateB2ClaInvoice> stateB2ClaInvoicesList;

	/** The B2cs invoice. */
	@JsonProperty("b2cs")
	private List<B2csInvoice> b2csInvoices;

	/** The b 2 csa invoices. */
	@JsonProperty("b2csa")
	private List<B2csaInvoice> b2csaInvoices;

	/** The Export invoice. */
	@JsonProperty("exp")
	private List<ExpInvoice> expInvoices;

	/** The expa invoices. */
	@JsonProperty("expa")
	private List<ExpaInvoice> expaInvoices;

	/** The Advance Tax invoice. */
	@JsonProperty("at")
	private List<AtInvoice> atInvoices;

	/** The ata invoices. */
	@JsonProperty("ata")
	private List<AtaInvoice> ataInvoices;

	/** Advance Tax paid details. */
	@JsonProperty("txpd")
	private List<TxpdInvoice> txpdInvoices;

	/** The Advance Tax paid details Ammendment. */
	@JsonProperty("txpda")
	private List<TxpdaInvoice> txpdaInvoices;

	/** The Credit Debit Notes Registered Users invoice. */
	@JsonProperty("cdnr")
	private List<CdnrInvoice> cdnrInvoices;

	/** The amended Credit Debit Notes Registered Users invoice. */
	@JsonProperty("cdnra")
	private List<CdnraInvoice> cdnraInvoices;

	/** The Nil Supplies. */
	@JsonProperty("nil")
	private NilSupply nilSupply;

	/** The HSN/SAC summary of outward supplies. */
	@JsonProperty("hsn")
	private HsnSummary hsnSummary;

	/** The Credit Debit Notes Un-Registered TaxPayers. */
	@JsonProperty("cdnur")
	private List<CdnurInvoiceDetail> cdnurInvoiceDetails;

	/** The Credit Debit Notes Amendments Un-Registered TaxPayers. */
	@JsonProperty("cdnura")
	private List<CdnuraInvoiceDetail> cdnuraInvoiceDetails;
	
	private List<B2clInvoice> b2clInvoices;

	@JsonProperty("custom_id")
	private Long customId;
	
	/** The doc issue invoices. */
	@JsonProperty("doc_issue")
	private DocIssueInvoice docIssueInvoice;

	/**
	 * Gets the gstin.
	 *
	 * @return the gstin
	 */
	public String getGstin() {
		return gstin;
	}

	/**
	 * Sets the businesstype.
	 *
	 * @param gstin
	 *            the new businesstype
	 */
	public void setBusinessType(String businesstype) {
		this.businesstype = businesstype;
	}
	
	/**
	 * gets the businesstype.
	 *
	 * @param businesstype
	 *          
	 */
	public String getbusinesstype() {
		return businesstype;
	}

	/**
	 * Sets the gstin.
	 *
	 * @param gstin
	 *            the new gstin
	 */
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the fp.
	 *
	 * @return the fp
	 */
	public String getFp() {
		return fp;
	}

	/**
	 * Sets the fp.
	 *
	 * @param fp
	 *            the new fp
	 */
	public void setFp(String fp) {
		this.fp = fp;
	}

	/**
	 * Gets the gt.
	 *
	 * @return the gt
	 */
	public BigDecimal getGt() {
		return gt;
	}

	/**
	 * Sets the gt.
	 *
	 * @param gt
	 *            the new gt
	 */
	public void setGt(BigDecimal gt) {
		this.gt = gt;
	}

	/**
	 * Gets the cur gt.
	 *
	 * @return the cur gt
	 */
	public BigDecimal getCurGt() {
		return curGt;
	}

	/**
	 * Sets the cur gt.
	 *
	 * @param curGt
	 *            the new cur gt
	 */
	public void setCurGt(BigDecimal curGt) {
		this.curGt = curGt;
	}

	/**
	 * Gets the b 2 b invoices.
	 *
	 * @return the b 2 b invoices
	 */

	public List<B2bInvoice> getB2bInvoices() {
		return b2bInvoices;
	}

	/**
	 * Sets the b 2 b invoices.
	 *
	 * @param b2bInvoices
	 *            the new b 2 b invoices
	 */
	public void setB2bInvoices(List<B2bInvoice> b2bInvoices) {
		this.b2bInvoices = b2bInvoices;
	}

	/**
	 * Gets the save B 2 cl invoice.
	 *
	 * @return the save B 2 cl invoice
	 */
	public List<StateB2ClInvoices> getStateB2ClInvoicesList() {
		return stateB2ClInvoicesList;
	}

	/**
	 * Sets the save B 2 cl invoice.
	 *
	 * @param stateB2ClInvoicesList
	 *            the new state B 2 cl invoices list
	 */
	public void setStateB2ClInvoicesList(List<StateB2ClInvoices> stateB2ClInvoicesList) {
		this.stateB2ClInvoicesList = stateB2ClInvoicesList;
	}

	/**
	 * Gets the B2CS invoices.
	 *
	 * @return the B2CS invoices
	 */
	public List<B2csInvoice> getB2csInvoices() {
		return b2csInvoices;
	}

	/**
	 * Sets the B2CS invoices.
	 *
	 * @param b2csInvoices
	 *            the new B2CS invoices
	 */
	public void setB2csInvoices(List<B2csInvoice> b2csInvoices) {
		this.b2csInvoices = b2csInvoices;
	}

	/**
	 * Gets the Export invoices.
	 *
	 * @return the Export invoices
	 */
	public List<ExpInvoice> getExpInvoices() {
		return expInvoices;
	}

	/**
	 * Sets the Export invoices.
	 *
	 * @param expInvoices
	 *            the new exp invoices
	 */
	public void setExpInvoices(List<ExpInvoice> expInvoices) {
		this.expInvoices = expInvoices;
	}

	/**
	 * Gets the Advance Tax.
	 *
	 * @return the Advance Tax invoices
	 */
	public List<AtInvoice> getAtInvoices() {
		return atInvoices;
	}

	/**
	 * Sets the Advance Tax invoices.
	 *
	 * @param atInvoices
	 *            the new Advance Tax invoices
	 */
	public void setAtInvoices(List<AtInvoice> atInvoices) {
		this.atInvoices = atInvoices;
	}
	
	/**
	 * Gets the B2ba invoice.
	 *
	 * @return the B2ba invoice
	 */
	public List<B2clInvoice> getB2clInvoices() {
		return b2clInvoices;
	}

	/**
	 * Gets the B2ba invoice.
	 *
	 * @return the B2ba invoice
	 */
	public List<B2baInvoice> getB2baInvoices() {
		return b2baInvoices;
	}

	/**
	 * Sets the B2ba invoice.
	 *
	 * @param b2baInvoices
	 *            the new b 2 ba invoices
	 */
	public void setB2baInvoices(List<B2baInvoice> b2baInvoices) {
		this.b2baInvoices = b2baInvoices;
	}

	/**
	 * Gets the state B2Cla invoices list.
	 *
	 * @return the state B2Cla invoices list
	 */
	public List<StateB2ClaInvoice> getStateB2ClaInvoicesList() {
		return stateB2ClaInvoicesList;
	}

	/**
	 * Sets the state B2Cla invoices list.
	 *
	 * @param stateB2ClaInvoicesList
	 *            the new state B2Cla invoices list
	 */
	public void setStateB2ClaInvoicesList(List<StateB2ClaInvoice> stateB2ClaInvoicesList) {
		this.stateB2ClaInvoicesList = stateB2ClaInvoicesList;
	}

	/**
	 * Gets the B2csa invoices.
	 *
	 * @return the B2csa invoices
	 */
	public List<B2csaInvoice> getB2csaInvoices() {
		return b2csaInvoices;
	}

	/**
	 * Sets the B2csa invoices.
	 *
	 * @param b2csaInvoices
	 *            the new B2csa invoices
	 */
	public void setB2csaInvoices(List<B2csaInvoice> b2csaInvoices) {
		this.b2csaInvoices = b2csaInvoices;
	}

	/**
	 * Gets the Advance Tax Paid invoices.
	 *
	 * @return the Advance Tax Paid invoices
	 */
	public List<TxpdInvoice> getTxpdInvoices() {
		return txpdInvoices;
	}

	/**
	 * Sets the Advance Tax Paid invoices.
	 *
	 * @param txpdInvoices
	 *            the new Advance Tax Paid invoices
	 */
	public void setTxpdInvoices(List<TxpdInvoice> txpdInvoices) {
		this.txpdInvoices = txpdInvoices;
	}

	/**
	 * Gets the Credit Debit Notes Registered Users invoices.
	 *
	 * @return the Credit Debit Notes Registered Users invoices
	 */
	public List<CdnrInvoice> getCdnrInvoices() {
		return cdnrInvoices;
	}

	/**
	 * Sets the Credit Debit Notes Registered Users invoices.
	 *
	 * @param cdnrInvoices
	 *            the new Credit Debit Notes Registered Users invoices
	 */
	public void setCdnrInvoices(List<CdnrInvoice> cdnrInvoices) {
		this.cdnrInvoices = cdnrInvoices;
	}

	/**
	 * Gets the cdnra invoices.
	 *
	 * @return the cdnra invoices
	 */
	public List<CdnraInvoice> getCdnraInvoices() {
		return cdnraInvoices;
	}

	/**
	 * Sets the cdnra invoices.
	 *
	 * @param cdnraInvoices
	 *            the new cdnra invoices
	 */
	public void setCdnraInvoices(List<CdnraInvoice> cdnraInvoices) {
		this.cdnraInvoices = cdnraInvoices;
	}


	/**
	 * Gets the nil supply.
	 *
	 * @return the nil supply
	 */
	public NilSupply getNilSupply() {
		return nilSupply;
	}

	/**
	 * Sets the nil supply.
	 *
	 * @param nilSupply
	 *            the new nil supply
	 */
	public void setNilSupply(NilSupply nilSupply) {
		this.nilSupply = nilSupply;
	}

	/**
	 * Gets the Exports Amendments invoices.
	 *
	 * @return the Exports Amendments invoices
	 */
	public List<ExpaInvoice> getExpaInvoices() {
		return expaInvoices;
	}

	/**
	 * Sets the Exports Amendments invoices.
	 *
	 * @param expaInvoices
	 *            the new Exports Amendments invoices
	 */
	public void setExpaInvoices(List<ExpaInvoice> expaInvoices) {
		this.expaInvoices = expaInvoices;
	}

	/**
	 * Gets the ata invoices.
	 *
	 * @return the ata invoices
	 */
	public List<AtaInvoice> getAtaInvoices() {
		return ataInvoices;
	}

	/**
	 * Sets the ata invoices.
	 *
	 * @param ataInvoices
	 *            the new ata invoices
	 */
	public void setAtaInvoices(List<AtaInvoice> ataInvoices) {
		this.ataInvoices = ataInvoices;
	}


	/**
	 * Gets the hsn summary.
	 *
	 * @return the hsn summary
	 */
	public HsnSummary getHsnSummary() {
		return hsnSummary;
	}

	/**
	 * Sets the hsn summary.
	 *
	 * @param hsnSummary
	 *            the new hsn summary
	 */
	public void setHsnSummary(HsnSummary hsnSummary) {
		this.hsnSummary = hsnSummary;
	}

	/**
	 * Gets the cdnur invoice details.
	 *
	 * @return the cdnur invoice details
	 */
	public List<CdnurInvoiceDetail> getCdnurInvoiceDetails() {
		return cdnurInvoiceDetails;
	}

	/**
	 * Sets the cdnur invoice details.
	 *
	 * @param cdnurInvoiceDetails
	 *            the new cdnur invoice details
	 */
	public void setCdnurInvoiceDetails(List<CdnurInvoiceDetail> cdnurInvoiceDetails) {
		this.cdnurInvoiceDetails = cdnurInvoiceDetails;
	}

	/**
	 * Gets the cdnura invoice details.
	 *
	 * @return the cdnura invoice details
	 */
	public List<CdnuraInvoiceDetail> getCdnuraInvoiceDetails() {
		return cdnuraInvoiceDetails;
	}

	/**
	 * Sets the cdnura invoice details.
	 *
	 * @param cdnuraInvoiceDetails
	 *            the new cdnura invoice details
	 */
	public void setCdnuraInvoiceDetails(List<CdnuraInvoiceDetail> cdnuraInvoiceDetails) {
		this.cdnuraInvoiceDetails = cdnuraInvoiceDetails;
	}

	/**
	 * Gets the doc issue invoice.
	 *
	 * @return the doc issue invoice
	 */
	public DocIssueInvoice getDocIssueInvoice() {
		return docIssueInvoice;
	}

	/**
	 * Sets the doc issue invoice.
	 *
	 * @param docIssueInvoice
	 *            the new doc issue invoice
	 */
	public void setDocIssueInvoice(DocIssueInvoice docIssueInvoice) {
		this.docIssueInvoice = docIssueInvoice;
	}

	/**
	 * Gets the txpda invoices.
	 *
	 * @return the txpda invoices
	 */
	public List<TxpdaInvoice> getTxpdaInvoices() {
		return txpdaInvoices;
	}

	/**
	 * Sets the txpda invoices.
	 *
	 * @param txpdaInvoices
	 *            the new txpda invoices
	 */
	public void setTxpdaInvoices(List<TxpdaInvoice> txpdaInvoices) {
		this.txpdaInvoices = txpdaInvoices;
	}

	public Long getCustomId() {
		return customId;
	}

	public void setCustomId(Long customId) {
		this.customId = customId;
	}
}
