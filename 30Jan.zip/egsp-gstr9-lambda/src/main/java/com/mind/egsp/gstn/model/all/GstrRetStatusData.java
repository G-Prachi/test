package com.mind.egsp.gstn.model.all;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Class RetStatusData.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GstrRetStatusData implements Serializable {

	private static final long serialVersionUID = 1L;

	/* Status of request( PROCESSED-P/PROCESSED with Error- PE/ERROR-ER ) */
	@JsonProperty("status_cd")
	private String statusCd;

	/* Form Type (R1=GSTR1, R2=GSTR2...) */
	@JsonProperty("form_typ")
	private String formTyp;

	/* The API Action */
	private String action;

	/* List (Error Details)) */
	@JsonProperty("error_report")
	private ErrorReport errorReport;

	public GstrRetStatusData() {
		super();
	}
	public String getStatusCd() {
		return statusCd;
	}

	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

	public String getFormTyp() {
		return formTyp;
	}

	public void setFormTyp(String formTyp) {
		this.formTyp = formTyp;
	}

	public ErrorReport getErrorReport() {
		return errorReport;
	}

	public void setErrorReport(ErrorReport errorReport) {
		this.errorReport = errorReport;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

}
