package com.mind.egsp.gstn.dto.auth;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;

/**
 * The Class RegisterDscResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class RegisterDscResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;


}
