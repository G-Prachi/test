package com.mind.egsp.gstn.dto.gstr8;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr8.Gstr8TaxPaidComponents;

// TODO: Auto-generated Javadoc
/**
 * The Class Gstr8GetTaxPaidResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Gstr8GetTaxPaidResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** Tax Paid Components. */
	private Gstr8TaxPaidComponents txpd;

	/**
	 * Gets the Tax Paid Components
	 *
	 * @return the txpd
	 */
	public Gstr8TaxPaidComponents getTxpd() {
		return txpd;
	}

	/**
	 * Sets the Tax Paid Components
	 *
	 * @param txpd
	 *            the new txpd
	 */
	public void setTxpd(Gstr8TaxPaidComponents txpd) {
		this.txpd = txpd;
	}
}
