package com.mind.egsp.gstn.model.gstr1A;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Class GSTR1ASectionSummary.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GSTR1ASectionSummary implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The Return Section .
	 */
	@JsonProperty("sec_nm")
	private String secNm;

	/**
	 * The Invoice Check sum value .
	 */
	private String chksum;

	/**
	 * The Total record count .
	 */
	@JsonProperty("ttl_rec")
	private BigDecimal ttlRec;

	/**
	 * The Total record value .
	 */
	@JsonProperty("ttl_val")
	private BigDecimal ttlVal;

	/**
	 * The Total Taxable Value .
	 */
	@JsonProperty("ttl_tax")
	private BigDecimal ttlTax;

	/**
	 * The Total IGST .
	 */
	@JsonProperty("ttl_igst")
	private BigDecimal ttlIgst;

	/**
	 * The Total CGST .
	 */
	@JsonProperty("ttl_cgst")
	private BigDecimal ttlCgst;

	/**
	 * The Total SGST .
	 */
	@JsonProperty("ttl_sgst")
	private BigDecimal ttlSgst;

	/**
	 * The Total Cess .
	 */
	@JsonProperty("ttl_cess")
	private BigDecimal ttlCess;

	/** The gstr 1 acounter party summary. */
	@JsonProperty("cpty_sum")
	private List<GSTR1ACounterPartySummary> gstr1acounterPartySummary;

	/**
	 * Gets the Return Section Field Specification: String (Max length:5) Sample
	 * Data: b2b/b2ba/cdn/cdna .
	 *
	 * @return the sec nm
	 */
	public String getSecNm() {
		return secNm;
	}

	/**
	 * Sets the Return Section Field Specification: String (Max length:5) Sample
	 * Data: b2b/b2ba/cdn/cdna .
	 *
	 * @param secNm
	 *            the new sec nm
	 */
	public void setSecNm(String secNm) {
		this.secNm = secNm;
	}

	/**
	 * Gets the Invoice Check sum value Field Specification: string(Max
	 * length:15) Sample Data: AflJufPlFStqKBZ .
	 *
	 * @return the chksum
	 */
	public String getChksum() {
		return chksum;
	}

	/**
	 * Sets the Invoice Check sum value Field Specification: string(Max
	 * length:15) Sample Data: AflJufPlFStqKBZ .
	 *
	 * @param chksum
	 *            the new chksum
	 */
	public void setChksum(String chksum) {
		this.chksum = chksum;
	}

	/**
	 * Gets the Total record count Field Specification: Number Sample Data:
	 * 10.00 .
	 *
	 * @return the ttl rec
	 */


	/**
	 * Sets the Total record count Field Specification: Number Sample Data:
	 * 10.00 .
	 *
	 * @param ttlRec
	 *            the new ttl rec
	 */


	/**
	 * Gets the Total record value Field Specification: Decimal(15, 2) Sample
	 * Data: 1000 .
	 *
	 * @return the ttl val
	 */
	public BigDecimal getTtlVal() {
		return ttlVal;
	}

	public BigDecimal getTtlRec() {
		return ttlRec;
	}

	public void setTtlRec(BigDecimal ttlRec) {
		this.ttlRec = ttlRec;
	}

	/**
	 * Sets the Total record value Field Specification: Decimal(15, 2) Sample
	 * Data: 1000 .
	 *
	 * @param ttlVal
	 *            the new ttl val
	 */
	public void setTtlVal(BigDecimal ttlVal) {
		this.ttlVal = ttlVal;
	}

	/**
	 * Gets the Total Taxable Value Field Specification: Decimal(15, 2) Sample
	 * Data: 500.00 .
	 *
	 * @return the ttl tax
	 */
	public BigDecimal getTtlTax() {
		return ttlTax;
	}

	/**
	 * Sets the Total Taxable Value Field Specification: Decimal(15, 2) Sample
	 * Data: 500.00 .
	 *
	 * @param ttlTax
	 *            the new ttl tax
	 */
	public void setTtlTax(BigDecimal ttlTax) {
		this.ttlTax = ttlTax;
	}

	/**
	 * Gets the Total IGST Field Specification: Decimal(15, 2) Sample Data: 100
	 * .
	 *
	 * @return the ttl igst
	 */
	public BigDecimal getTtlIgst() {
		return ttlIgst;
	}

	/**
	 * Sets the Total IGST Field Specification: Decimal(15, 2) Sample Data: 100
	 * .
	 *
	 * @param ttlIgst
	 *            the new ttl igst
	 */
	public void setTtlIgst(BigDecimal ttlIgst) {
		this.ttlIgst = ttlIgst;
	}

	/**
	 * Gets the Total CGST Field Specification: Decimal(15, 2) Sample Data:
	 * 100.9 .
	 *
	 * @return the ttl cgst
	 */
	public BigDecimal getTtlCgst() {
		return ttlCgst;
	}

	/**
	 * Sets the Total CGST Field Specification: Decimal(15, 2) Sample Data:
	 * 100.9 .
	 *
	 * @param ttlCgst
	 *            the new ttl cgst
	 */
	public void setTtlCgst(BigDecimal ttlCgst) {
		this.ttlCgst = ttlCgst;
	}

	/**
	 * Gets the Total SGST Field Specification: Decimal(15, 2) Sample Data:
	 * 100.67 .
	 *
	 * @return the ttl sgst
	 */
	public BigDecimal getTtlSgst() {
		return ttlSgst;
	}

	/**
	 * Sets the Total SGST Field Specification: Decimal(15, 2) Sample Data:
	 * 100.67 .
	 *
	 * @param ttlSgst
	 *            the new ttl sgst
	 */
	public void setTtlSgst(BigDecimal ttlSgst) {
		this.ttlSgst = ttlSgst;
	}

	/**
	 * Gets the ttl cess.
	 *
	 * @return the ttl cess
	 */
	public BigDecimal getTtlCess() {
		return ttlCess;
	}

	/**
	 * Sets the ttl cess.
	 *
	 * @param ttlCess
	 *            the new ttl cess
	 */
	public void setTtlCess(BigDecimal ttlCess) {
		this.ttlCess = ttlCess;
	}

	/**
	 * Gets the gstr 1 acounter party summary.
	 *
	 * @return the gstr 1 acounter party summary
	 */
	public List<GSTR1ACounterPartySummary> getGstr1acounterPartySummary() {
		return gstr1acounterPartySummary;
	}

	/**
	 * Sets the gstr 1 acounter party summary.
	 *
	 * @param gstr1acounterPartySummary
	 *            the new gstr 1 acounter party summary
	 */
	public void setGstr1acounterPartySummary(List<GSTR1ACounterPartySummary> gstr1acounterPartySummary) {
		this.gstr1acounterPartySummary = gstr1acounterPartySummary;
	}

}
