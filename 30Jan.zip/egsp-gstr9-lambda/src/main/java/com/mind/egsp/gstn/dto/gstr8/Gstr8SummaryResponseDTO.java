package com.mind.egsp.gstn.dto.gstr8;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr8.Gstr8RefundClaim;
import com.mind.egsp.gstn.model.gstr8.Gstr8SectionSummary;
import com.mind.egsp.gstn.model.gstr8.Gstr8TaxPaidComponents;

// TODO: Auto-generated Javadoc
/**
 * The Class Gstr8SummaryResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Gstr8SummaryResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** Invoice Check sum value. */
	private String chksum;

	/** The GSTIN of the Tax Payer. */
	private String gstin;

	/** Return Period. */
	@JsonProperty("ret_period")
	private String retPeriod;

	/** Section Summary. */
	@JsonProperty("sec_sum")
	private List<Gstr8SectionSummary> sectionSummaries;

	/** Total Liability. */
	private Gstr8TaxPaidComponents txpd;

	/** Refundable Amount. */
	@JsonProperty("ref_claim")
	private Gstr8RefundClaim refclaim;

	/**
	 * Gets the checksum.
	 *
	 * @return the chksum
	 */
	public String getChksum() {
		return chksum;
	}

	/**
	 * Sets the checksum.
	 *
	 * @param chksum
	 *            the new checksum
	 */
	public void setChksum(String chksum) {
		this.chksum = chksum;
	}

	/**
	 * Gets the gstin.
	 *
	 * @return the gstin
	 */
	public String getGstin() {
		return gstin;
	}

	/**
	 * Sets the gstin.
	 *
	 * @param gstin
	 *            the new gstin
	 */
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the ret period.
	 *
	 * @return the ret period
	 */
	public String getRetPeriod() {
		return retPeriod;
	}

	/**
	 * Sets the ret period.
	 *
	 * @param retPeriod
	 *            the new ret period
	 */
	public void setRetPeriod(String retPeriod) {
		this.retPeriod = retPeriod;
	}

	/**
	 * Gets the section summaries.
	 *
	 * @return the section summaries
	 */
	public List<Gstr8SectionSummary> getSectionSummaries() {
		return sectionSummaries;
	}

	/**
	 * Sets the section summaries.
	 *
	 * @param sectionSummaries
	 *            the new section summaries
	 */
	public void setSectionSummaries(List<Gstr8SectionSummary> sectionSummaries) {
		this.sectionSummaries = sectionSummaries;
	}

	/**
	 * Gets the Total Liablility.
	 *
	 * @return the txpd
	 */
	public Gstr8TaxPaidComponents getTxpd() {
		return txpd;
	}

	/**
	 * Sets the Total Liablility.
	 *
	 * @param txpd
	 *            the new txpd
	 */
	public void setTxpd(Gstr8TaxPaidComponents txpd) {
		this.txpd = txpd;
	}

	/**
	 * Gets the Refundable Amount.
	 *
	 * @return the refclaim
	 */
	public Gstr8RefundClaim getRefclaim() {
		return refclaim;
	}

	/**
	 * Sets the Refunadable Amountr.
	 *
	 * @param refclaim
	 *            the new refclaim
	 */
	public void setRefclaim(Gstr8RefundClaim refclaim) {
		this.refclaim = refclaim;
	}

}
