package com.mind.egsp.gstn.dto.all;

import java.io.Serializable;

import com.mind.egsp.gstn.dto.BaseRequestDTO;

/**
 * The Class TrackARNStatusRequestDTO.
 */
public class TrackARNStatusRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The GSTIN of the taxpayer .
	 */
	private String gstinl;

	/**
	 * The Aknowledgement number .
	 */
	private String ackno;

	public TrackARNStatusRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	/**
	 * Gets the Field Specification: Alphanumeric with 15 characters Mandatory:
	 * Y Sample Data: 29HJKPS9689A8Z4 .
	 *
	 * @return the gstinl
	 */
	public String getGstinl() {
		return gstinl;
	}

	/**
	 * Sets the Field Specification: Alphanumeric with 15 characters Mandatory:
	 * Y Sample Data: 29HJKPS9689A8Z4 .
	 *
	 * @param gstinl
	 *            the new gstinl
	 */
	public void setGstinl(String gstinl) {
		this.gstinl = gstinl;
	}

	/**
	 * Gets the Aknowledgement number Field Specification: String with 15 chars
	 * Mandatory: Y Sample Data: ABTN05169886340
	 * 
	 * .
	 *
	 * @return the ackno
	 */
	public String getAckno() {
		return ackno;
	}

	/**
	 * Sets the Aknowledgement number Field Specification: String with 15 chars
	 * Mandatory: Y Sample Data: ABTN05169886340 .
	 *
	 * @param ackno
	 *            the new ackno
	 */
	public void setAckno(String ackno) {
		this.ackno = ackno;
	}

}
