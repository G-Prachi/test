package com.mind.egsp.gstn.dto.gstr1;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr1.GetEcomInvoice;

/**
 * The Class GetEcomResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetEcomDetailsResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The get ecom invoices. */
	// TODO: Check for correct property name from api documentation
	@JsonProperty("iraecom")
	private List<GetEcomInvoice> getEcomInvoices;

	/**
	 * Gets the gets the ecom invoices.
	 *
	 * @return the gets the ecom invoices
	 */
	public List<GetEcomInvoice> getGetEcomInvoices() {
		return getEcomInvoices;
	}

	/**
	 * Sets the gets the ecom invoices.
	 *
	 * @param getEcomInvoices
	 *            the new gets the ecom invoices
	 */
	public void setGetEcomInvoices(List<GetEcomInvoice> getEcomInvoices) {
		this.getEcomInvoices = getEcomInvoices;
	}

}
