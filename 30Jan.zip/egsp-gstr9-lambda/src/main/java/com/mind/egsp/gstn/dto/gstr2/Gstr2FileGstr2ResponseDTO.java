package com.mind.egsp.gstn.dto.gstr2;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseResponseDTO;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Gstr2FileGstr2ResponseDTO extends BaseResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Acknowledgement no. */
	@JsonProperty("ack_num")
	private String ackNum;

	/**
	 * Gets the Acknowledgement no
	 * 
	 * Field Specification: Alphanumeric 15 characters
	 * 
	 * Sample Data: AK12415125235 .
	 *
	 * @return the ack num
	 */
	public String getAckNum() {
		return ackNum;
	}

	/**
	 * Sets the Acknowledgement no
	 * 
	 * Field Specification: Alphanumeric 15 characters
	 * 
	 * Sample Data: AK12415125235 .
	 *
	 * @param ackNum
	 *            the new ack num
	 */
	public void setAckNum(String ackNum) {
		this.ackNum = ackNum;
	}

}
