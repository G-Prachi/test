package com.mind.egsp.gstn.model.gstr2;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Class Gstr2B2BInvoice.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class Gstr2B2bInvoice implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** GSTIN/UID of the Receiver taxpayer/UN, Govt Bodies. */
	private String ctin;

	/** counter party Filing Status. */
	private String cfs;

	/** Invoice Details. */
	@JsonProperty("inv")
	private List<Gstr2B2bInvoiceDetail> b2bInvoiceDetails;

	/**
	 * Gets the ctin.
	 *
	 * @return the ctin
	 */
	public String getCtin() {
		return ctin;
	}

	/**
	 * Sets the ctin.
	 *
	 * @param ctin
	 *            the new ctin
	 */
	public void setCtin(String ctin) {
		this.ctin = ctin;
	}

	/**
	 * Gets the b 2 b invoice details.
	 *
	 * @return the b 2 b invoice details
	 */
	public List<Gstr2B2bInvoiceDetail> getB2bInvoiceDetails() {
		return b2bInvoiceDetails;
	}

	/**
	 * Sets the b 2 b invoice details.
	 *
	 * @param b2bInvoiceDetails
	 *            the new b 2 b invoice details
	 */
	public void setB2bInvoiceDetails(List<Gstr2B2bInvoiceDetail> b2bInvoiceDetails) {
		this.b2bInvoiceDetails = b2bInvoiceDetails;
	}

	/**
	 * Gets the counter party Filing Status.
	 *
	 * @return the counter party Filing Status
	 */
	public String getCfs() {
		return cfs;
	}

	/**
	 * Sets the counter party Filing Status.
	 *
	 * @param cfs
	 *            the new counter party Filing Status
	 */
	public void setCfs(String cfs) {
		this.cfs = cfs;
	}

}
