package com.mind.egsp.gstn.dto.gstr1;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr1.Gstr1SummaryData;

/**
 * The Gstr1 Summary Response DTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Gstr1SummaryResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** Invoice Check sum value. */
	private Gstr1SummaryData gstr1SummaryData;

	/**
	 * Gets the gstr 1 summary data.
	 *
	 * @return the gstr 1 summary data
	 */
	public Gstr1SummaryData getGstr1SummaryData() {
		return gstr1SummaryData;
	}

	/**
	 * Sets the gstr 1 summary data.
	 *
	 * @param gstr1SummaryData
	 *            the new gstr 1 summary data
	 */
	public void setGstr1SummaryData(Gstr1SummaryData gstr1SummaryData) {
		this.gstr1SummaryData = gstr1SummaryData;
	}

}
