package com.mind.egsp.gstn.dto.gstr2;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseResponseDTO;
import com.mind.egsp.gstn.model.gstr2.TcsDataList;

/**
 * The Class GetTcsCreditResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetTcsCreditResponseDTO extends BaseResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The tcs data list. */
	@JsonProperty("tcs_data}")
	private List<TcsDataList> tcsDataList;

	/**
	 * Gets the tcs data list.
	 *
	 * @return the tcs data list
	 */
	public List<TcsDataList> getTcsDataList() {
		return tcsDataList;
	}

	/**
	 * Sets the tcs data list.
	 *
	 * @param tcsDataList
	 *            the new tcs data list
	 */
	public void setTcsDataList(List<TcsDataList> tcsDataList) {
		this.tcsDataList = tcsDataList;
	}

}
