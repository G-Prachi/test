package com.mind.egsp.gstn.model.gstr2;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Class Gstr2B2baInvoice.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Gstr2B2baInvoice implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** GSTIN/UID of the Receiver taxpayer/UN, Govt Bodies. */
	private String ctin;

	/** counter party Filing Status. */
	private String cfs;

	/** Invoice Details. */
	@JsonProperty("inv")
	private List<Gstr2B2baInvoiceDetail> b2baInvoiceDetails;

	/**
	 * Gets the ctin.
	 *
	 * @return the ctin
	 */
	public String getCtin() {
		return ctin;
	}

	/**
	 * Sets the ctin.
	 *
	 * @param ctin
	 *            the new ctin
	 */
	public void setCtin(String ctin) {
		this.ctin = ctin;
	}

	/**
	 * Gets the b 2 ba invoice details.
	 *
	 * @return the b 2 ba invoice details
	 */
	public List<Gstr2B2baInvoiceDetail> getB2baInvoiceDetails() {
		return b2baInvoiceDetails;
	}

	/**
	 * Sets the b 2 ba invoice details.
	 *
	 * @param b2baInvoiceDetails
	 *            the new b 2 ba invoice details
	 */
	public void setB2baInvoiceDetails(List<Gstr2B2baInvoiceDetail> b2baInvoiceDetails) {
		this.b2baInvoiceDetails = b2baInvoiceDetails;
	}

	/**
	 * Gets the counter party Filing Status.
	 *
	 * @return the counter party Filing Status
	 */
	public String getCfs() {
		return cfs;
	}

	/**
	 * Sets the counter party Filing Status.
	 *
	 * @param cfs
	 *            the new counter party Filing Status
	 */
	public void setCfs(String cfs) {
		this.cfs = cfs;
	}

}
