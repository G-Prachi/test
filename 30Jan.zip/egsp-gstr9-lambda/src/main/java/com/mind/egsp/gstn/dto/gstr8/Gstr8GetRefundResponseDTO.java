package com.mind.egsp.gstn.dto.gstr8;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr8.Gstr8RefundClaim;

// TODO: Auto-generated Javadoc
/**
 * The Class Gstr8GetRefundResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Gstr8GetRefundResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** Act Type. */
	@JsonProperty("ref_claim")
	private Gstr8RefundClaim refclaim;

	/**
	 * Gets the Act Type.
	 *
	 * @return the refclaim
	 */
	public Gstr8RefundClaim getRefclaim() {
		return refclaim;
	}

	/**
	 * Sets the Act Type.
	 *
	 * @param refclaim
	 *            the new refclaim
	 */
	public void setRefclaim(Gstr8RefundClaim refclaim) {
		this.refclaim = refclaim;
	}

}
