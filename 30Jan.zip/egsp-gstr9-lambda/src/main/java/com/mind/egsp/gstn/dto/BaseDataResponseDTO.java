package com.mind.egsp.gstn.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BaseDataResponseDTO extends BaseResponseDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String data;

	private String rek;

	private String hmac;

	private String txn;

	@JsonIgnore
	private DataStatusDTO dataStatusDTO;

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getRek() {
		return rek;
	}

	public void setRek(String rek) {
		this.rek = rek;
	}

	public String getHmac() {
		return hmac;
	}

	public void setHmac(String hmac) {
		this.hmac = hmac;
	}

	public String getTxn() {
		return txn;
	}

	public void setTxn(String txn) {
		this.txn = txn;
	}

	public DataStatusDTO getDataStatusDTO() {
		return dataStatusDTO;
	}

	public void setDataStatusDTO(DataStatusDTO dataStatusDTO) {
		this.dataStatusDTO = dataStatusDTO;
	}

}
