package com.mind.egsp.gstn.dto.gstr2;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mind.egsp.gstn.dto.BaseResponseDTO;
import com.mind.egsp.gstn.model.gstr2.SectionSummary;

/**
 * The Class GetGSTR2SummaryResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetGSTR2SummaryResponseDTO extends BaseResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The gstin URL Parameter. */
	private String gstin;

	/** The ret_period URL Parameter. */
	private String retPeriod;

	/**
	 * The Invoice Check sum value .
	 */
	private String chksum;

	/** The section summary. */
	private List<SectionSummary> sectionSummary;

	/**
	 * Gets the gstin.
	 *
	 * @return the gstin
	 */
	public String getGstin() {
		return gstin;
	}

	/**
	 * Sets the GSTIN of the taxpayer.
	 * 
	 * Field Specification: Alphanumeric with 15 characters, Mandatory: Y
	 *
	 * @param gstin
	 *            the new gstin
	 */
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the ret period.
	 *
	 * @return the ret period
	 */
	public String getRetPeriod() {
		return retPeriod;
	}

	/**
	 * Sets the Return Period.
	 * 
	 * Field Specification: MMYYYY, Mandatory: Y
	 *
	 * @param retPeriod
	 *            the new ret period
	 */
	public void setRetPeriod(String retPeriod) {
		this.retPeriod = retPeriod;
	}

	/**
	 * Gets the Invoice Check sum value Field Specification: string(Max
	 * length:15) Sample Data: AflJufPlFStqKBZ .
	 *
	 * @return the chksum
	 */
	public String getChksum() {
		return chksum;
	}

	/**
	 * Sets the Invoice Check sum value Field Specification: string(Max
	 * length:15) Sample Data: AflJufPlFStqKBZ .
	 *
	 * @param chksum
	 *            the new chksum
	 */
	public void setChksum(String chksum) {
		this.chksum = chksum;
	}

	/**
	 * Gets the section summary.
	 *
	 * @return the section summary
	 */
	public List<SectionSummary> getSectionSummary() {
		return sectionSummary;
	}

	/**
	 * Sets the section summary.
	 *
	 * @param sectionSummary
	 *            the new section summary
	 */
	public void setSectionSummary(List<SectionSummary> sectionSummary) {
		this.sectionSummary = sectionSummary;
	}

}
