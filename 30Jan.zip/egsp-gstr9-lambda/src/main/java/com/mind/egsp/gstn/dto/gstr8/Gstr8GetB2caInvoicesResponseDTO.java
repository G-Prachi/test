package com.mind.egsp.gstn.dto.gstr8;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr8.Gstr8B2caInvoiceDetail;

/**
 * The Class GetB2clInvoicesResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Gstr8GetB2caInvoicesResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The b2c invoices. */
	@JsonProperty("b2ca")
	private List<Gstr8B2caInvoiceDetail> b2caInvoices;

	/**
	 * Gets the b2c invoices.
	 *
	 * @return the b2c invoices
	 */
	public List<Gstr8B2caInvoiceDetail> getB2caInvoices() {
		return b2caInvoices;
	}

	/**
	 * Sets the b2c invoices.
	 *
	 * @param b2cInvoices
	 *            the new b2c invoices
	 */
	public void setB2caInvoices(List<Gstr8B2caInvoiceDetail> b2caInvoices) {
		this.b2caInvoices = b2caInvoices;
	}

}
