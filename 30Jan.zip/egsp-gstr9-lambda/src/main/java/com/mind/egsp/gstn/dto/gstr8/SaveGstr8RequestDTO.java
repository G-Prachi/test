package com.mind.egsp.gstn.dto.gstr8;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

/**
 * The Gstr8 Save Data Request DTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class SaveGstr8RequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** HMAC-SHA256 of Base64 data using EK. */
	private String hmac;

	/** Data for invoices of all business types. */
	@JsonProperty("data")
	private SaveGstr8DTO saveGstr8DTO;

	/**
	 * Instantiates a new save gstr 8 request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param gstin
	 *            the gstin
	 * @param retPeriod
	 *            the ret period
	 * @param username
	 *            the username
	 */
	public SaveGstr8RequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	/**
	 * Gets the hmac.
	 *
	 * @return the hmac
	 */
	public String getHmac() {
		return hmac;
	}

	/**
	 * Sets the hmac.
	 *
	 * @param hmac
	 *            the new hmac
	 */
	public void setHmac(String hmac) {
		this.hmac = hmac;
	}

	/**
	 * Gets the save gstr 8 DTO.
	 *
	 * @return the save gstr 8 DTO
	 */
	public SaveGstr8DTO getSaveGstr8DTO() {
		return saveGstr8DTO;
	}

	/**
	 * Sets the save gstr 8 DTO.
	 *
	 * @param saveGstr1DTO
	 *            the new save gstr 8 DTO
	 */
	public void setSaveGstr1DTO(SaveGstr8DTO saveGstr1DTO) {
		this.saveGstr8DTO = saveGstr1DTO;
	}

}
