package com.mind.egsp.flatfile.convert;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mind.egsp.gstn.dto.gstr1.SaveGstr1DTO;
import com.mind.egsp.gstn.model.gstr1.AtInvoice;
import com.mind.egsp.gstn.model.gstr1.AtItemDetail;
import com.amazonaws.services.s3.AmazonS3;
import com.egsp.finalDTOs.*;

public class atjsonConverter {
	
	public static String atJsonConverter(SaveGstr1DTO gstriObj,String bucketName,String filePath,String fileName,AmazonS3 s3, String str2)
	{
		try
		{			
				//byte[] jsonData1 = Files.readAllBytes(Paths.get("B2b-sample.json"));
				//ObjectMapper objectMapper = new ObjectMapper();
				SaveGstr1DTOFlat savedtoflat  = new SaveGstr1DTOFlat();
				//SaveGstr1DTO gstriObj = objectMapper.readValue(jsonData1, SaveGstr1DTO.class);
				savedtoflat.setFp(gstriObj.getFp());
				List<AtInvoice> list = gstriObj.getAtInvoices();
				List<AtInvoiceDetailFlat>flatatDetaillist = new ArrayList<AtInvoiceDetailFlat>();
				
				BigDecimal totaladAmt = new BigDecimal(0);	
				//BigDecimal totaltxval = new BigDecimal(0);
				BigDecimal totaliamt = new BigDecimal(0);;
				BigDecimal totalcamt =new BigDecimal(0);
				BigDecimal totalsamt =new BigDecimal(0);
				BigDecimal totalcsamt = new BigDecimal(0);
				if(list!=null)
				{
				for(AtInvoice item : list)
				{
					AtInvoiceDetailFlat atInvoiceDetailFLat = new AtInvoiceDetailFlat();
					for(AtItemDetail invDetail : item.getAtItemDetails()) {
				
						
							//totaltxval = totaltxval.add(invDetail.getTxval());
							totalcamt = totalcamt.add(invDetail.getCamt());
							totalcsamt = totalcsamt.add(invDetail.getCsamt());
							totalsamt = totalsamt.add(invDetail.getSamt());
							totaliamt = totaliamt.add(invDetail.getIamt());
						    }
				
							//atInvoiceDetailFLat.setTotaltxval(totaltxval);
							atInvoiceDetailFLat.setTotaliamt(totaliamt);
							atInvoiceDetailFLat.setTotalcamt(totalcamt);
							atInvoiceDetailFLat.setTotalcsamt(totalcsamt);
							atInvoiceDetailFLat.setTotalsamt(totalsamt);
							atInvoiceDetailFLat.setTotalsamt(totaladAmt);
							atInvoiceDetailFLat.setFp(gstriObj.getFp());
							atInvoiceDetailFLat.setBusinessType("at");
							flatatDetaillist.add(atInvoiceDetailFLat);
					}
				}
				final ByteArrayOutputStream out = new ByteArrayOutputStream();
			    final ObjectMapper mapper = new ObjectMapper();
			    
			    mapper.writeValue(out, flatatDetaillist);
		        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		        StringBuilder tempFile = new StringBuilder();
		        Random rnd = new Random();
		        while (tempFile.length() < 18) { // length of the random string.
		            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
		            tempFile.append(SALTCHARS.charAt(index));
		        }
		        String tempFil = tempFile.toString();
		        File tempFileName = new File(tempFil+".json");
		        //return saltStr;
				mapper.writeValue(tempFileName, flatatDetaillist);
				InputStream is = new FileInputStream(tempFileName);
				String contents = new BufferedReader(new InputStreamReader(is)).readLine();
				is.close(); 
				
					String str = contents.substring(1, contents.length()-1);
					String str1=str.replaceAll("},", "}\n");
					System.out.println(str1);
					str2= str2.concat(str1);
					return(str2);
					/*PrintWriter pr = new PrintWriter(new BufferedWriter(new FileWriter(new File(fileName), true)));
					pr.write(str1);
					pr.append("\n");
					pr.close();
					s3.putObject(bucketName, filePath+"/"+fileName, str1);
					System.out.println("sucess");*/
			    
			    
		}
				catch(Exception ex)
				{
					
				}
		return (str2);
	}
}
		
	





