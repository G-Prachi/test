package com.mind.egsp.gstn.dto.publicapi;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseResponseDTO;
/**
 * The Class AuthGetCommonTokenResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class GetPublicCommonAuthTokenResponseDTO extends BaseResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The auth token. */
	@JsonProperty("auth_token")
	private String authToken;

	/** The sek. */
	private String sek;

	/**
	 * Gets the auth token.
	 *
	 * @return the auth token
	 */
	public String getAuthToken() {
		return authToken;
	}

	/**
	 * Sets the auth token.
	 *
	 * @param authToken
	 *            the new auth token
	 */
	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}

	/**
	 * Gets the sek.
	 *
	 * @return the sek
	 */
	public String getSek() {
		return sek;
	}

	/**
	 * Sets the sek.
	 *
	 * @param sek
	 *            the new sek
	 */
	public void setSek(String sek) {
		this.sek = sek;
	}



}
