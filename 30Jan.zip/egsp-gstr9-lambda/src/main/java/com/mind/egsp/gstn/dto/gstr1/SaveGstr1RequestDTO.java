package com.mind.egsp.gstn.dto.gstr1;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

/**
 * The Gstr1 Save Data Request DTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class SaveGstr1RequestDTO extends BaseRequestDTO implements Serializable {




	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** HMAC-SHA256 of Base64 data using EK. */
	private String hmac;

	/** Data for invoices of all business types. */
	@JsonProperty("data")
	private SaveGstr1DTO saveGstr1DTO;

	public SaveGstr1RequestDTO() {
		super();
	}
	/**
	 * Instantiates a new save gstr 1 request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param gstin
	 *            the gstin
	 * @param retPeriod
	 *            the ret period
	 * @param username
	 *            the username
	 */
	public SaveGstr1RequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username, Long clientId, Long businessTypeId) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username, clientId, businessTypeId);
	}



	/**
	 * Gets the hmac.
	 *
	 * @return the hmac
	 */
	public String getHmac() {
		return hmac;
	}

	/**
	 * Sets the hmac.
	 *
	 * @param hmac
	 *            the new hmac
	 */
	public void setHmac(String hmac) {
		this.hmac = hmac;
	}

	/**
	 * Gets the save gstr 1 DTO.
	 *
	 * @return the save gstr 1 DTO
	 */
	public SaveGstr1DTO getSaveGstr1DTO() {
		return saveGstr1DTO;
	}

	/**
	 * Sets the save gstr 1 DTO.
	 *
	 * @param saveGstr1DTO
	 *            the new save gstr 1 DTO
	 */
	public void setSaveGstr1DTO(SaveGstr1DTO saveGstr1DTO) {
		this.saveGstr1DTO = saveGstr1DTO;
	}

}
