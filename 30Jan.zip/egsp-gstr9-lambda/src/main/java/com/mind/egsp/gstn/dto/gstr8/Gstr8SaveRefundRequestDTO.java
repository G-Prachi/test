package com.mind.egsp.gstn.dto.gstr8;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseRequestDTO;
import com.mind.egsp.gstn.model.gstr8.Gstr8SaveRefund;

// TODO: Auto-generated Javadoc
/**
 * The Class Gstr8SaveRefundRequestDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Gstr8SaveRefundRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** Refund Claim. */
	@JsonProperty("ref_claim")
	private Gstr8SaveRefund refclaim;

	/**
	 * Instantiates a new gstr 8 get tax paid request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param gstin
	 *            the gstin
	 * @param retPeriod
	 *            the ret period
	 * @param username
	 *            the username
	 */
	public Gstr8SaveRefundRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	/**
	 * Gets the Refund Claim.
	 *
	 * @return the refclaim
	 */
	public Gstr8SaveRefund getRefclaim() {
		return refclaim;
	}

	/**
	 * Sets the Refund Claim.
	 *
	 * @param refclaim
	 *            the new refclaim
	 */
	public void setRefclaim(Gstr8SaveRefund refclaim) {
		this.refclaim = refclaim;
	}

}
