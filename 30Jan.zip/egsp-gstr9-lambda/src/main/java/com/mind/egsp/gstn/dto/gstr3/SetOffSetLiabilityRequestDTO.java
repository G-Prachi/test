package com.mind.egsp.gstn.dto.gstr3;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

/**
 * The Class SetOffsetLiabilityGSTR3RequestDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)

public class SetOffSetLiabilityRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The set offset liability DTO. */
	@JsonProperty("data")
	private SetOffsetLiabilityDTO setOffsetLiabilityDTO;

	/**
	 * Instantiates a new sets the offset liability GSTR 3 request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param gstin
	 *            the gstin
	 * @param retPeriod
	 *            the ret period
	 * @param username
	 *            the username
	 */
	public SetOffSetLiabilityRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	/**
	 * Gets the sets the offset liability DTO.
	 *
	 * @return the sets the offset liability DTO
	 */
	public SetOffsetLiabilityDTO getSetOffsetLiabilityDTO() {
		return setOffsetLiabilityDTO;
	}

	/**
	 * Sets the sets the offset liability DTO.
	 *
	 * @param setOffsetLiabilityDTO
	 *            the new sets the offset liability DTO
	 */
	public void setSetOffsetLiabilityDTO(SetOffsetLiabilityDTO setOffsetLiabilityDTO) {
		this.setOffsetLiabilityDTO = setOffsetLiabilityDTO;
	}

}
