package com.mind.egsp.gstn.dto.gstr1A;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr1A.Gstr1ACdnInvoice;
import com.mind.egsp.gstn.model.gstr2.Gstr2CdnInvoice;

/**
 * The Class GetCdnInvoicesResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Gstr1AGetCdnInvoicesResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The cdn data list. */
	@JsonProperty("cdn")
	List<Gstr1ACdnInvoice> cdnInvoices;

	/**
	 * Gets the cdn invoices.
	 *
	 * @return the cdn invoices
	 */
	public List<Gstr1ACdnInvoice> getCdnInvoices() {
		return cdnInvoices;
	}

	/**
	 * Sets the cdn invoices.
	 *
	 * @param cdnInvoices
	 *            the new cdn invoices
	 */
	public void setCdnInvoices(List<Gstr1ACdnInvoice> cdnInvoices) {
		this.cdnInvoices = cdnInvoices;
	}

}
