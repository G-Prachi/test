package com.mind.egsp.gstn.dto.gstr1;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;

/**
 * The Gstr1 Submit Response DTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubmitGstr2ResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The Reference Id .
	 */
	@JsonProperty("ref_id")
	private String referenceId;

	/**
	 * The Transaction Id .
	 */
	@JsonProperty("trans_id")
	private String transId;

	/**
	 * Gets the Reference Id Field Specification: Alphanumeric 15 characters
	 * Sample Data: LAPN24235325555 .
	 *
	 * @return the referenceId
	 */
	public String getReferenceId() {
		return referenceId;
	}

	/**
	 * Sets the Reference Id Field Specification: Alphanumeric 15 characters
	 * Sample Data: LAPN24235325555 .
	 *
	 * @param refId
	 *            the new referenceId
	 */
	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	/**
	 * Gets the Reference Id Field Specification: Alphanumeric 15 characters
	 * Sample Data: LAPN24235325555 .
	 *
	 * @return the txn id
	 */
	public String getTransId() {
		return transId;
	}

	/**
	 * Sets the Reference Id Field Specification: Alphanumeric 15 characters
	 * Sample Data: LAPN24235325555 .
	 *
	 * @param transId
	 *            the new transId
	 */
	public void setTransId(String transId) {
		this.transId = transId;
	}

}
