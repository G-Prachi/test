package com.mind.egsp.gstn.ledger;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;

/**
 * The Class GetCashLedgerDetailsResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetCashLedgerDetailsResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The cash ledger details data. */
	private CashLedgerDetailsData cashLedgerDetailsData;

	/**
	 * Gets the cash ledger details data.
	 *
	 * @return the cash ledger details data
	 */
	public CashLedgerDetailsData getCashLedgerDetailsData() {
		return cashLedgerDetailsData;
	}

	/**
	 * Sets the cash ledger details data.
	 *
	 * @param cashLedgerDetailsData
	 *            the new cash ledger details data
	 */
	public void setCashLedgerDetailsData(CashLedgerDetailsData cashLedgerDetailsData) {
		this.cashLedgerDetailsData = cashLedgerDetailsData;
	}

}
