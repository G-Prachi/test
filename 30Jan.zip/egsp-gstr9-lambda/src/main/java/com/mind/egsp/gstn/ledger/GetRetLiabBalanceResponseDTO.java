package com.mind.egsp.gstn.ledger;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.ledger.OpenLiability;

// TODO: Auto-generated Javadoc
/**
 * The Class GetRetLiabBalanceResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetRetLiabBalanceResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The GSTIN of the Taxpayer. */
	private String gstin;

	/** The Tax Period. */
	@JsonProperty("tax_prd")
	private String taxPrd;

	/** The GSTR Type. */
	@JsonProperty("ret_type")
	private String retType;

	/** The Open Liabilities details. */
	@JsonProperty("op_liab")
	private List<OpenLiability> openLiabilities;

	/**
	 * Gets the GSTIN of the Tax Payer.
	 *
	 * @return the GSTIN of the Tax Payer
	 */
	public String getGstin() {
		return gstin;
	}

	/**
	 * Sets the GSTIN of the Tax Payer.
	 *
	 * @param gstin
	 *            the new GSTIN of the Tax Payer
	 */
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the Tax Period. Format: YYYYMM
	 *
	 * @return the Tax Period
	 */
	public String getTaxPrd() {
		return taxPrd;
	}

	/**
	 * Sets the Tax Period.
	 *
	 * @param taxPrd
	 *            the new Tax Period
	 */
	public void setTaxPrd(String taxPrd) {
		this.taxPrd = taxPrd;
	}

	/**
	 * Gets the GSTR Type.
	 *
	 * @return the GSTR Type
	 */
	public String getRetType() {
		return retType;
	}

	/**
	 * Sets the GSTR Type.
	 *
	 * @param retType
	 *            the new GSTR Type
	 */
	public void setRetType(String retType) {
		this.retType = retType;
	}

	/**
	 * Gets the open liabilities.
	 *
	 * @return the open liabilities
	 */
	public List<OpenLiability> getOpenLiabilities() {
		return openLiabilities;
	}

	/**
	 * Sets the open liabilities.
	 *
	 * @param openLiabilities
	 *            the new open liabilities
	 */
	public void setOpenLiabilities(List<OpenLiability> openLiabilities) {
		this.openLiabilities = openLiabilities;
	}

}
