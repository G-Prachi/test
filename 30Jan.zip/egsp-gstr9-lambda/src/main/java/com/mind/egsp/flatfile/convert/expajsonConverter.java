package com.mind.egsp.flatfile.convert;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mind.egsp.gstn.dto.gstr1.SaveGstr1DTO;
import com.mind.egsp.gstn.model.gstr1.ExpInvoice;
import com.mind.egsp.gstn.model.gstr1.ExpInvoiceDetail;
import com.mind.egsp.gstn.model.gstr1.ExpaInvoice;
import com.mind.egsp.gstn.model.gstr1.*;
import com.amazonaws.services.s3.AmazonS3;
import com.egsp.finalDTOs.*;

public class expajsonConverter {

//	static List<ExpInvoiceDetailFlat> flatExpDetiallist =  new ArrayList<ExpInvoiceDetailFlat>();		
//	static List<ExpInvoiceFlat>  flatExplist = new ArrayList<ExpInvoiceFlat>();
//	static List<ExpInvoiceFlatFinal> expInvFlatFinal = new ArrayList<ExpInvoiceFlatFinal>();
	
	public static String expaJsonConverter(SaveGstr1DTO gstriObj,String bucketName,String filePath,String fileName,AmazonS3 s3, String str2)
	{
		//***************************Declaration for Exp*************
		try
		{
				List<ExpaInvoiceFlat>  flatExpalist = new ArrayList<ExpaInvoiceFlat>();				
				//byte[] jsonData1 = Files.readAllBytes(Paths.get("B2b-sample.json"));
				//create ObjectMapper instance
				//ObjectMapper objectMapper = new ObjectMapper();
				SaveGstr1DTOFlat savedtoflat  = new SaveGstr1DTOFlat();
				//SaveGstr1DTO gstriObj = objectMapper.readValue(jsonData1, SaveGstr1DTO.class);
				savedtoflat.setFp(gstriObj.getFp());
				//B2BInvoice================
				List<ExpaInvoice> list = gstriObj.getExpaInvoices();
				List<ExpaInvoiceDetailFlat> flatExpDetiallist = new ArrayList<ExpaInvoiceDetailFlat>();
			
				//System.out.println(list.size() +  "" + list.toString());		
				BigDecimal totaltxval = new BigDecimal(0);
				BigDecimal totaliamt = new BigDecimal(0);;
				BigDecimal totalcamt =new BigDecimal(0);
				BigDecimal totalsamt =new BigDecimal(0);
				BigDecimal totalcsamt = new BigDecimal(0);
				if(list!=null)
				{
				for(ExpaInvoice item : list)
				{
					//flatExpDetiallist = new ArrayList<ExpInvoiceDetailFlat>();
					ExpaInvoiceFlat expflat = new ExpaInvoiceFlat();
					expflat.setExTp(item.getExTyp());
					for(ExpaInvoiceDetail invDetail : item.getExpaInvoiceDetail()) {
						ExpaInvoiceDetailFlat expInvoiceDetailFLat = new ExpaInvoiceDetailFlat();
						expInvoiceDetailFLat.setInum(invDetail.getInum());
						expflat.setVal(invDetail.getVal());
						expInvoiceDetailFLat.setIdt(invDetail.getIdt());
						expInvoiceDetailFLat.setOinum(invDetail.getOinum());
						expInvoiceDetailFLat.setOidt(invDetail.getOidt());
						
						for (ExpItemDetail item1 :invDetail.getExpItemDetails()){
							totaltxval = totaltxval.add(item1.getTxval());
							totaliamt = totaliamt.add(item1.getIamt());
							totalcamt = totalcamt.add(item1.getCsamt());
							totalsamt = totalsamt.add(item1.getIamt());
							totalcsamt = totalcsamt.add(item1.getCsamt());
						    }
							expInvoiceDetailFLat.setTotaltxval(totaltxval);
							expInvoiceDetailFLat.setTotaliamt(totaliamt);
							expInvoiceDetailFLat.setTotalcamt(totalcamt);
							expInvoiceDetailFLat.setTotalcsamt(totalcsamt);
							expInvoiceDetailFLat.setTotalsamt(totalsamt);
							flatExpDetiallist.add(expInvoiceDetailFLat);
					}
					expflat.setExpaInvoiceDetailFLat(flatExpDetiallist);
					flatExpalist.add(expflat);
				}
//				System.out.println("flatExplist "+flatExplist);
					List<ExpaInvoiceFlatFinal> expfinalList = new ArrayList<ExpaInvoiceFlatFinal>();
					for(ExpaInvoiceFlat flatList : flatExpalist)
					{
						for(ExpaInvoiceDetailFlat expInvoiceFlat : flatList.getExpaInvoiceDetailFLat()) {
							ExpaInvoiceFlatFinal expInvoiceFlatFinal = new ExpaInvoiceFlatFinal();
							expInvoiceFlatFinal.setFp(gstriObj.getFp());
							expInvoiceFlatFinal.setBusinessType("expa");
							expInvoiceFlatFinal.setExTp(flatList.getExTp());
							//expInvoiceFlatFinal.setRchrg(flatList.getRchrg());
							//expInvoiceFlatFinal.setInvTyp(flatList.getInvTyp());
							//------------------***--------------------------
							expInvoiceFlatFinal.setVal(flatList.getVal());
							expInvoiceFlatFinal.setInum(expInvoiceFlat.getInum());
							expInvoiceFlatFinal.setIdt(expInvoiceFlat.getIdt());
							expInvoiceFlatFinal.setOinum(expInvoiceFlat.getOinum());
							expInvoiceFlatFinal.setOidt(expInvoiceFlat.getOidt());
							expInvoiceFlatFinal.setTotalcamt(expInvoiceFlat.getTotalcamt());
							expInvoiceFlatFinal.setTotalcsamt(expInvoiceFlat.getTotalcsamt());
							expInvoiceFlatFinal.setTotaliamt(expInvoiceFlat.getTotaliamt());
							expInvoiceFlatFinal.setTotalsamt(expInvoiceFlat.getTotalsamt());
							expInvoiceFlatFinal.setTotaltxval(expInvoiceFlat.getTotaltxval());
							expfinalList.add(expInvoiceFlatFinal);
						}
					}
					
				final ByteArrayOutputStream out = new ByteArrayOutputStream();
			    final ObjectMapper mapper = new ObjectMapper();
			    

				mapper.writeValue(out, expfinalList);
		        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		        StringBuilder tempFile = new StringBuilder();
		        Random rnd = new Random();
		        while (tempFile.length() < 18) { // length of the random string.
		            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
		            tempFile.append(SALTCHARS.charAt(index));
		        }
		        String tempFil = tempFile.toString();
		        File tempFileName = new File(tempFil+".json");
		        //return saltStr;
				mapper.writeValue(tempFileName, expfinalList);
				InputStream is = new FileInputStream(tempFileName);
				String contents = new BufferedReader(new InputStreamReader(is)).readLine();
				is.close(); 
				
					String str = contents.substring(1, contents.length()-1);
					String str1=str.replaceAll("},", "}\n");
					System.out.println(str1);
					str2= str2.concat(str1);
					return(str2);
					/*PrintWriter pr = new PrintWriter(new BufferedWriter(new FileWriter(new File(fileName), true)));
					pr.write(str1);
					pr.append("\n");
					pr.close();
					s3.putObject(bucketName, filePath+"/"+fileName, str1);
					System.out.println("sucess");*/
			    
			   
				}
		}
				catch(Exception ex)
				{
					
				}
		return (str2);
	}
}
		
	











