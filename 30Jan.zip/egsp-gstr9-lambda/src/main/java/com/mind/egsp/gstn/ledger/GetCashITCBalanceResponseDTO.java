package com.mind.egsp.gstn.ledger;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.ledger.CashBalanceDetail;
import com.mind.egsp.gstn.model.ledger.ItcBalanceDetail;


/**
 * The Class GetCashITCBalanceResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetCashITCBalanceResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The GSTIN of the Taxpayer. */
	private String gstin;

	/** The Tax Period. */
	@JsonProperty("dt")
	private String dt;

	/** The Details of Cash balance. */
	@JsonProperty("cash_bal")
	private CashBalanceDetail cashBalanceDetail;

	/** The Details of ITC Balance. */
	@JsonProperty("itc_bal")
	private ItcBalanceDetail itcBalanceDetail;

	/**
	 * Gets the gstin.
	 *
	 * @return the gstin
	 */
	public String getGstin() {
		return gstin;
	}

	/**
	 * Sets the gstin.
	 *
	 * @param gstin
	 *            the new gstin
	 */
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the Current Date.
	 * 
	 * Format: string(dd-MM-yyyy)
	 *
	 * @return the Current Date
	 */
	public String getDt() {
		return dt;
	}

	/**
	 * Sets the Current Date.
	 *
	 * @param dt
	 *            the new Current Date
	 */
	public void setDt(String dt) {
		this.dt = dt;
	}

	/**
	 * Gets the cash balance detail.
	 *
	 * @return the cash balance detail
	 */
	public CashBalanceDetail getCashBalanceDetail() {
		return cashBalanceDetail;
	}

	/**
	 * Sets the cash balance detail.
	 *
	 * @param cashBalanceDetail
	 *            the new cash balance detail
	 */
	public void setCashBalanceDetail(CashBalanceDetail cashBalanceDetail) {
		this.cashBalanceDetail = cashBalanceDetail;
	}

	/**
	 * Gets the itc balance detail.
	 *
	 * @return the itc balance detail
	 */
	public ItcBalanceDetail getItcBalanceDetail() {
		return itcBalanceDetail;
	}

	/**
	 * Sets the itc balance detail.
	 *
	 * @param itcBalanceDetail
	 *            the new itc balance detail
	 */
	public void setItcBalanceDetail(ItcBalanceDetail itcBalanceDetail) {
		this.itcBalanceDetail = itcBalanceDetail;
	}

}
