package com.mind.egsp.gstn.model.gstr1;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Class for Nil Supplies.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class NilSupply implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Invoice Check sum value. */
	private String chksum;

	/** Identifier if Goods or Services. */
	@JsonIgnore
	private String ty;

	/** The tax payer action. */

	private Character flag;

	/** The Goods nill data. */
	@JsonProperty("inv")
	private List<NilSupplyData> nilSupplyDatas;

	/** The Service nill data. */
	// @JsonProperty("s")
	@JsonIgnore
	private List<NilSupplyData> serviceNilSupplyDatas;

	/**
	 * Gets the chksum.
	 *
	 * @return the chksum
	 */
	public String getChksum() {
		return chksum;
	}

	/**
	 * Sets the chksum.
	 *
	 * @param chksum
	 *            the new chksum
	 */
	public void setChksum(String chksum) {
		this.chksum = chksum;
	}

	/**
	 * Gets the service nil supply data.
	 *
	 * @return the service nil supply data
	 */
	public List<NilSupplyData> getServiceNilSupplyDatas() {
		return serviceNilSupplyDatas;
	}

	/**
	 * Sets the service nil supply data.
	 *
	 * @param serviceNilSupplyDatas
	 *            the new service nil supply data
	 */

	public void setServiceNilSupplyDatas(List<NilSupplyData> serviceNilSupplyDatas) {
		this.serviceNilSupplyDatas = serviceNilSupplyDatas;
	}

	/**
	 * Gets the ty.
	 *
	 * @return the ty
	 */
	public String getTy() {
		return ty;
	}

	/**
	 * Sets the ty.
	 *
	 * @param ty
	 *            the new ty
	 */
	public void setTy(String ty) {
		this.ty = ty;
	}

	/**
	 * Gets the flag.
	 *
	 * @return the flag
	 */
	public Character getFlag() {
		return flag;
	}

	/**
	 * Sets the flag.
	 *
	 * @param flag
	 *            the new flag
	 */
	public void setFlag(Character flag) {
		this.flag = flag;
	}

	/**
	 * Gets the nil supply datas.
	 *
	 * @return the nil supply datas
	 */
	public List<NilSupplyData> getNilSupplyDatas() {
		return nilSupplyDatas;
	}

	/**
	 * Sets the nil supply datas.
	 *
	 * @param nilSupplyDatas
	 *            the new nil supply datas
	 */
	public void setNilSupplyDatas(List<NilSupplyData> nilSupplyDatas) {
		this.nilSupplyDatas = nilSupplyDatas;
	}

}
