package com.mind.egsp.gstn.dto.gstr1A;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;

/**
 * The Gstr1 Summary Response DTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Gstr1ASummaryResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** Invoice Check sum value. */
	private Gstr1ASummaryData gstr1ASummaryData;

	/**
	 * Gets the gstr 1 A summary data.
	 *
	 * @return the gstr 1A summary data
	 */
	public Gstr1ASummaryData getGstr1ASummaryData() {
		return gstr1ASummaryData;
	}

	/**
	 * Sets the gstr 1A summary data.
	 *
	 * @param gstr1ASummaryData
	 *            the new gstr 1A summary data
	 */
	public void setGstr1ASummaryData(Gstr1ASummaryData gstr1aSummaryData) {
		gstr1ASummaryData = gstr1aSummaryData;
	}
}
