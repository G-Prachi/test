package com.mind.egsp.gstn.dto.auth;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseResponseDTO;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AuthGetTokenResponseDTO extends BaseResponseDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("auth_token")
	private String authToken;

	private String expiry;

	private String sek;

	public String getAuthToken() {
		return authToken;
	}

	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}

	public String getExpiry() {
		return expiry;
	}

	public void setExpiry(String expiry) {
		this.expiry = expiry;
	}

	public String getSek() {
		return sek;
	}

	public void setSek(String sek) {
		this.sek = sek;
	}

}
