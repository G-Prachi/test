package com.mind.egsp.gstn.dto.gstr1;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr1.B2claInvoice;

/**
 * The Class GetB2claInvoicesResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetB2claInvoicesResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The b2cl invoices. */
	@JsonProperty("b2cla")
	private List<B2claInvoice> b2claInvoices;

	/** The Token. */
	private String token;

	/** The Estimated Time in minutes. */
	private String est;

	/**
	 * Gets the gets the B2CLA invoices.
	 *
	 * @return the gets the B2CLA invoices
	 */
	public List<B2claInvoice> getB2claInvoices() {
		return b2claInvoices;
	}

	/**
	 * Sets the gets the B2CLA invoices.
	 *
	 * @param getB2clInvoices
	 *            the new gets the B2CLA invoices
	 */
	public void setB2claInvoices(List<B2claInvoice> b2claInvoices) {
		this.b2claInvoices = b2claInvoices;
	}

	/**
	 * Gets the token.
	 *
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * Sets the token.
	 *
	 * @param token
	 *            the new token
	 */
	public void setToken(String token) {
		this.token = token;
	}

	/**
	 * Gets the est.
	 *
	 * @return the est
	 */
	public String getEst() {
		return est;
	}

	/**
	 * Sets the est.
	 *
	 * @param est
	 *            the new est
	 */
	public void setEst(String est) {
		this.est = est;
	}

}
