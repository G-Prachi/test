package com.mind.egsp.gstn.dto.gstr2;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseResponseDTO;
import com.mind.egsp.gstn.model.gstr2.GSTR2ErrorDetails;

/**
 * The Class GetGSTR2ReturnStatusResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetGSTR2ReturnStatusResponseDTO extends BaseResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The Status_code .
	 */
	private String status_cd;

	/**
	 * The Acknowledgement No .
	 */
	@JsonProperty("arn_no")
	private String arnNo;

	/** The error details. */
	// TODO: Check for correct property name from api documentation
	@JsonProperty("Error Report")
	private List<GSTR2ErrorDetails> errorDetails;

	/**
	 * Gets the status_cd Status_code Field Specification: One character(0 or 1)
	 * Sample Data: 0-Failure, 1=Success .
	 *
	 * @return the status cd
	 */
	public String getStatus_cd() {
		return status_cd;
	}

	/**
	 * Sets the status_cd Status_code Field Specification: One character(0 or 1)
	 * Sample Data: 0-Failure, 1=Success .
	 *
	 * @param status_cd
	 *            the new status cd
	 */
	public void setStatus_cd(String status_cd) {
		this.status_cd = status_cd;
	}

	/**
	 * Gets the arn_no Acknowledgement No Field Specification: Alphanumeric (Max
	 * length:50) Sample Data: DEABCSR6898M5Z4 .
	 *
	 * @return the arn no
	 */
	public String getArnNo() {
		return arnNo;
	}

	/**
	 * Sets the arn_no Acknowledgement No Field Specification: Alphanumeric (Max
	 * length:50) Sample Data: DEABCSR6898M5Z4 .
	 *
	 * @param arnNo
	 *            the new arn no
	 */
	public void setArnNo(String arnNo) {
		this.arnNo = arnNo;
	}

	/**
	 * Gets the error details.
	 *
	 * @return the error details
	 */
	public List<GSTR2ErrorDetails> getErrorDetails() {
		return errorDetails;
	}

	/**
	 * Sets the error details.
	 *
	 * @param errorDetails
	 *            the new error details
	 */
	public void setErrorDetails(List<GSTR2ErrorDetails> errorDetails) {
		this.errorDetails = errorDetails;
	}

}
