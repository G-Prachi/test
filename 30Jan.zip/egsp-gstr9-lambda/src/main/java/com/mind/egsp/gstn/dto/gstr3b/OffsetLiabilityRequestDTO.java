package com.mind.egsp.gstn.dto.gstr3b;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.model.gstr3b.Gstr3bTaxPaidByCash;
import com.mind.egsp.gstn.model.gstr3b.Gstr3bTaxPaidByCredit;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class OffsetLiabilityRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;	

	/** The List of Paid Through Cash. */
	@JsonProperty("pdcash")
	private List<Gstr3bTaxPaidByCash> paidByCashs;

	/** Paid Through Credit. */
	@JsonProperty("pditc")
	private Gstr3bTaxPaidByCredit paidByCredit;

	
	public List<Gstr3bTaxPaidByCash> getPaidByCashs() {
		return paidByCashs;
	}

	public void setPaidByCashs(List<Gstr3bTaxPaidByCash> paidByCashs) {
		this.paidByCashs = paidByCashs;
	}

	public Gstr3bTaxPaidByCredit getPaidByCredit() {
		return paidByCredit;
	}

	public void setPaidByCredit(Gstr3bTaxPaidByCredit paidByCredit) {
		this.paidByCredit = paidByCredit;
	}

}
