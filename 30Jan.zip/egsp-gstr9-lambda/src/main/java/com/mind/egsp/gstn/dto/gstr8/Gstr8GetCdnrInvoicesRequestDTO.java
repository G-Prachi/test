package com.mind.egsp.gstn.dto.gstr8;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

// TODO: Auto-generated Javadoc
/**
 * Get Gstr8 Cdnr Invoices Request DTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Gstr8GetCdnrInvoicesRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Counter party GSTIN. */
	private String ctin;

	/** from which time taxpayer want Invoices. */
	private String fromTime;

	/**
	 * Instantiates a new gstr 8 get cdnr invoices request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param gstin
	 *            the gstin
	 * @param retPeriod
	 *            the ret period
	 * @param username
	 *            the username
	 */
	public Gstr8GetCdnrInvoicesRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	/**
	 * Gets the ctin.
	 *
	 * @return the ctin
	 */
	public String getCtin() {
		return ctin;
	}

	/**
	 * Sets the Counter party GSTIN.
	 * 
	 * Field Specification: Alphanumeric with 15 characters, Mandatory: N
	 *
	 * @param ctin
	 *            the new ctin
	 */
	public void setCtin(String ctin) {
		this.ctin = ctin;
	}

	/**
	 * Gets the from time.
	 *
	 * @return the from time
	 */
	public String getFromTime() {
		return fromTime;
	}

	/**
	 * Sets the from time which taxpayer want Invoices.
	 * 
	 * Field Specification: String (dd-mm-yyyy:hh) 13 Characters, Mandatory: N
	 *
	 * @param fromTime
	 *            the new from time
	 */
	public void setFromTime(String fromTime) {
		this.fromTime = fromTime;
	}
}
