package com.mind.egsp.gstn.dto.gstr1;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr1.ExpInvoice;

// TODO: Auto-generated Javadoc
/**
 * The Class GetExpResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetExpInvoicesResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The exp invoice. */
	@JsonProperty("exp")
	private List<ExpInvoice> expInvoices;

	/**
	 * Gets the exp invoices.
	 *
	 * @return the exp invoices
	 */
	public List<ExpInvoice> getExpInvoices() {
		return expInvoices;
	}

	/**
	 * Sets the exp invoices.
	 *
	 * @param expInvoices
	 *            the new exp invoices
	 */
	public void setExpInvoices(List<ExpInvoice> expInvoices) {
		this.expInvoices = expInvoices;
	}

}
