package com.mind.egsp.gstn.dto.gstr3;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr3.DebitEntriesLedger;
import com.mind.egsp.gstn.model.gstr3.Gstr3InwardSupplies;
import com.mind.egsp.gstn.model.gstr3.Gstr3OutwardSupplies;
import com.mind.egsp.gstn.model.gstr3.Gstr3TurnOverDetails;
import com.mind.egsp.gstn.model.gstr3.ITCCredit;
import com.mind.egsp.gstn.model.gstr3.InterestLiability;
import com.mind.egsp.gstn.model.gstr3.LateFeeDetails;
import com.mind.egsp.gstn.model.gstr3.MismatchAmount;
import com.mind.egsp.gstn.model.gstr3.OtherTaxPaid;
import com.mind.egsp.gstn.model.gstr3.RefundClaimForSaveGstr3;
import com.mind.egsp.gstn.model.gstr3.TCSCredit;
import com.mind.egsp.gstn.model.gstr3.TDSCredit;
import com.mind.egsp.gstn.model.gstr3.TaxPayableAndPaid;
import com.mind.egsp.gstn.model.gstr3.TotalTaxLiability;

/**
 * The Class GetGSTR3DetailsResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class GetDetailsResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The gstin. */
	private String gstin;

	/** The ret pd. */

	@JsonProperty("ret_period")
	private String retPd;

	/** The turn over details. */
	@JsonProperty("tod")
	private Gstr3TurnOverDetails turnOverDetails;

	/** The outward supplies. */
	@JsonProperty("osup")
	private Gstr3OutwardSupplies outwardSupplies;

	/** The in supplies. */
	@JsonProperty("i_sup")
	private Gstr3InwardSupplies inSupplies;

	/** The i TC credit. */
	@JsonProperty("itc_cr")
	private ITCCredit iTCCredit;

	/** The total tax liability. */
	@JsonProperty("ttxl")
	private TotalTaxLiability totalTaxLiability;

	/** The mismatch amount. */
	@JsonProperty("mis")
	private MismatchAmount mismatchAmount;

	/** The tcs credit. */
	@JsonProperty("tcs_cr")
	private TCSCredit tcsCredit;

	/** The t DS credit. */
	@JsonProperty("tds_cr")
	private TDSCredit tDSCredit;

	/** The interest liability. */
	@JsonProperty("intr_liab")
	private InterestLiability interestLiability;

	/** The late fee details. */
	@JsonProperty("lt_fee")
	private LateFeeDetails lateFeeDetails;

	/** The tax payable and paid. */
	@JsonProperty("tpm")
	private TaxPayableAndPaid taxPayableAndPaid;

	/** The other tax paid. */
	@JsonProperty("intr")
	private OtherTaxPaid otherTaxPaid;

	/** The refund claim. */
	@JsonProperty("rf_clm")
	private RefundClaimForSaveGstr3 refundClaim;

	/** The debit entries ledger. */
	@JsonProperty("ldg_debit_entries")
	private DebitEntriesLedger debitEntriesLedger;

	/** The error message. */
	private String errorMessage;

	/**
	 * Gets the gstin.
	 *
	 * @return the gstin
	 */
	public String getGstin() {
		return gstin;
	}

	/**
	 * Sets the gstin.
	 *
	 * @param gstin
	 *            the new gstin
	 */
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the ret pd.
	 *
	 * @return the ret pd
	 */
	public String getRetPd() {
		return retPd;
	}

	/**
	 * Sets the ret pd.
	 *
	 * @param retPd
	 *            the new ret pd
	 */
	public void setRetPd(String retPd) {
		this.retPd = retPd;
	}

	/**
	 * Gets the turn over details.
	 *
	 * @return the turn over details
	 */
	public Gstr3TurnOverDetails getTurnOverDetails() {
		return turnOverDetails;
	}

	/**
	 * Gets the outward supplies.
	 *
	 * @return the outward supplies
	 */
	public Gstr3OutwardSupplies getOutwardSupplies() {
		return outwardSupplies;
	}

	/**
	 * Sets the outward supplies.
	 *
	 * @param outwardSupplies
	 *            the new outward supplies
	 */
	public void setOutwardSupplies(Gstr3OutwardSupplies outwardSupplies) {
		this.outwardSupplies = outwardSupplies;
	}

	/**
	 * Sets the turn over details.
	 *
	 * @param turnOverDetails
	 *            the new turn over details
	 */
	public void setTurnOverDetails(Gstr3TurnOverDetails turnOverDetails) {
		this.turnOverDetails = turnOverDetails;
	}

	/**
	 * Gets the in supplies.
	 *
	 * @return the in supplies
	 */
	public Gstr3InwardSupplies getInSupplies() {
		return inSupplies;
	}

	/**
	 * Sets the in supplies.
	 *
	 * @param inSupplies
	 *            the new in supplies
	 */
	public void setInSupplies(Gstr3InwardSupplies inSupplies) {
		this.inSupplies = inSupplies;
	}

	/**
	 * Gets the total tax liability.
	 *
	 * @return the total tax liability
	 */
	public TotalTaxLiability getTotalTaxLiability() {
		return totalTaxLiability;
	}

	/**
	 * Sets the total tax liability.
	 *
	 * @param totalTaxLiability
	 *            the new total tax liability
	 */
	public void setTotalTaxLiability(TotalTaxLiability totalTaxLiability) {
		this.totalTaxLiability = totalTaxLiability;
	}

	/**
	 * Gets the i TC credit.
	 *
	 * @return the i TC credit
	 */
	public ITCCredit getiTCCredit() {
		return iTCCredit;
	}

	/**
	 * Sets the i TC credit.
	 *
	 * @param iTCCredit
	 *            the new i TC credit
	 */
	public void setiTCCredit(ITCCredit iTCCredit) {
		this.iTCCredit = iTCCredit;
	}

	/**
	 * Gets the mismatch amount.
	 *
	 * @return the mismatch amount
	 */
	public MismatchAmount getMismatchAmount() {
		return mismatchAmount;
	}

	/**
	 * Sets the mismatch amount.
	 *
	 * @param mismatchAmount
	 *            the new mismatch amount
	 */
	public void setMismatchAmount(MismatchAmount mismatchAmount) {
		this.mismatchAmount = mismatchAmount;
	}

	/**
	 * Gets the tcs credit.
	 *
	 * @return the tcs credit
	 */
	public TCSCredit getTcsCredit() {
		return tcsCredit;
	}

	/**
	 * Sets the tcs credit.
	 *
	 * @param tcsCredit
	 *            the new tcs credit
	 */
	public void setTcsCredit(TCSCredit tcsCredit) {
		this.tcsCredit = tcsCredit;
	}

	/**
	 * Gets the t DS credit.
	 *
	 * @return the t DS credit
	 */
	public TDSCredit gettDSCredit() {
		return tDSCredit;
	}

	/**
	 * Sets the t DS credit.
	 *
	 * @param tDSCredit
	 *            the new t DS credit
	 */
	public void settDSCredit(TDSCredit tDSCredit) {
		this.tDSCredit = tDSCredit;
	}

	/**
	 * Gets the interest liability.
	 *
	 * @return the interest liability
	 */
	public InterestLiability getInterestLiability() {
		return interestLiability;
	}

	/**
	 * Sets the interest liability.
	 *
	 * @param interestLiability
	 *            the new interest liability
	 */
	public void setInterestLiability(InterestLiability interestLiability) {
		this.interestLiability = interestLiability;
	}

	/**
	 * Gets the tax payable and paid.
	 *
	 * @return the tax payable and paid
	 */
	public TaxPayableAndPaid getTaxPayableAndPaid() {
		return taxPayableAndPaid;
	}

	/**
	 * Sets the tax payable and paid.
	 *
	 * @param taxPayableAndPaid
	 *            the new tax payable and paid
	 */
	public void setTaxPayableAndPaid(TaxPayableAndPaid taxPayableAndPaid) {
		this.taxPayableAndPaid = taxPayableAndPaid;
	}

	/**
	 * Gets the other tax paid.
	 *
	 * @return the other tax paid
	 */
	public OtherTaxPaid getOtherTaxPaid() {
		return otherTaxPaid;
	}

	/**
	 * Sets the other tax paid.
	 *
	 * @param otherTaxPaid
	 *            the new other tax paid
	 */
	public void setOtherTaxPaid(OtherTaxPaid otherTaxPaid) {
		this.otherTaxPaid = otherTaxPaid;
	}

	public RefundClaimForSaveGstr3 getRefundClaim() {
		return refundClaim;
	}

	public void setRefundClaim(RefundClaimForSaveGstr3 refundClaim) {
		this.refundClaim = refundClaim;
	}

	/**
	 * Gets the debit entries ledger.
	 *
	 * @return the debit entries ledger
	 */
	public DebitEntriesLedger getDebitEntriesLedger() {
		return debitEntriesLedger;
	}

	/**
	 * Sets the debit entries ledger.
	 *
	 * @param debitEntriesLedger
	 *            the new debit entries ledger
	 */
	public void setDebitEntriesLedger(DebitEntriesLedger debitEntriesLedger) {
		this.debitEntriesLedger = debitEntriesLedger;
	}

	/**
	 * Gets the error message.
	 *
	 * @return the error message
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * Sets the error message.
	 *
	 * @param errorMessage
	 *            the new error message
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * Gets the late fee details.
	 *
	 * @return the late fee details
	 */
	public LateFeeDetails getLateFeeDetails() {
		return lateFeeDetails;
	}

	/**
	 * Sets the late fee details.
	 *
	 * @param lateFeeDetails
	 *            the new late fee details
	 */
	public void setLateFeeDetails(LateFeeDetails lateFeeDetails) {
		this.lateFeeDetails = lateFeeDetails;
	}

}
