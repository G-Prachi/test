package com.mind.egsp.gstn.ledger;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.ledger.AmtOverdueTaxLedger;
import com.mind.egsp.gstn.model.ledger.LiabilityTransactionTaxLedger;

/**
 * The Class GetCashLedgerDetailsResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetLiabilityLedgerDetailsResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The GSTIN of the Taxpayer. */
	private String gstin;

	/** The Tax Period. */
	@JsonProperty("tax_prd")
	private String taxPrd;

	/** The Transactions. */
	@JsonProperty("tr")
	private LiabilityTransactionTaxLedger transactionTaxLedger;

	/** The Amount Overdue. */
	@JsonProperty("amt_overdue")
	private AmtOverdueTaxLedger amtOverdueTaxLedger;

	/**
	 * Gets the GSTIN of the Tax Payer.
	 *
	 * @return the GSTIN of the Tax Payer
	 */
	public String getGstin() {
		return gstin;
	}

	/**
	 * Sets the GSTIN of the Tax Payer.
	 *
	 * @param gstin
	 *            the new GSTIN of the Tax Payer
	 */
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the Tax Period. Format: YYYYMM
	 *
	 * @return the Tax Period
	 */
	public String getTaxPrd() {
		return taxPrd;
	}

	/**
	 * Sets the Tax Period.
	 *
	 * @param taxPrd
	 *            the new Tax Period
	 */
	public void setTaxPrd(String taxPrd) {
		this.taxPrd = taxPrd;
	}

	/**
	 * Gets the transaction tax ledgers.
	 *
	 * @return the transaction tax ledgers
	 */
	public LiabilityTransactionTaxLedger getTransactionTaxLedger() {
		return transactionTaxLedger;
	}

	/**
	 * Sets the transaction tax ledgers.
	 *
	 * @param transactionTaxLedgers
	 *            the new transaction tax ledgers
	 */
	public void setTransactionTaxLedger(LiabilityTransactionTaxLedger transactionTaxLedger) {
		this.transactionTaxLedger = transactionTaxLedger;
	}

	/**
	 * Gets the Amount Overdue.
	 *
	 * @return the Amount Overdue
	 */
	public AmtOverdueTaxLedger getAmtOverdue() {
		return amtOverdueTaxLedger;
	}

	/**
	 * Sets the Amount Overdue.
	 *
	 * @param amtOverdue
	 *            the new Amount Overdue
	 */
	public void setAmtOverdue(AmtOverdueTaxLedger amtOverdueTaxLedger) {
		this.amtOverdueTaxLedger = amtOverdueTaxLedger;
	}

}
