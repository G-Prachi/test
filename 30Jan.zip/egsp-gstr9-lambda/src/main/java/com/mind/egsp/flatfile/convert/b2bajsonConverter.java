package com.mind.egsp.flatfile.convert;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mind.egsp.gstn.dto.gstr1.SaveGstr1DTO;
import com.mind.egsp.gstn.model.gstr1.*;
import com.amazonaws.services.s3.AmazonS3;
import com.egsp.finalDTOs.*;

public class b2bajsonConverter {

	static List<B2baInvoiceDetailFlat> flatB2baDetiallist =  new ArrayList<B2baInvoiceDetailFlat>();		
	static List<B2baInvoiceFlat>  flatB2balist = new ArrayList<B2baInvoiceFlat>();
	static List<B2baInvoiceFlatFinal> b2baInvFlatFinal = new ArrayList<B2baInvoiceFlatFinal>();
	
	public static String b2bJsonConverter(SaveGstr1DTO gstriObj,String bucketName,String filePath,String fileName,AmazonS3 s3, String str2)
	{
		//***************************Declaration for B2ba*************
		try
		{
				//List<B2bInvoiceFlat>  flatB2blist = new ArrayList<B2bInvoiceFlat>();				
				//byte[] jsonData1 = Files.readAllBytes(Paths.get("B2b-sample.json"));
				//create ObjectMapper instance
				//ObjectMapper objectMapper = new ObjectMapper();
				SaveGstr1DTOFlat savedtoflat  = new SaveGstr1DTOFlat();
				//SaveGstr1DTO gstriObj = objectMapper.readValue(jsonData1, SaveGstr1DTO.class);
				savedtoflat.setFp(gstriObj.getFp());
				//B2BInvoice================
				List<B2baInvoice> listb2ba=gstriObj.getB2baInvoices();
				List<B2baInvoiceDetailFlat> flatB2baDetiallist = new ArrayList<B2baInvoiceDetailFlat>();
				BigDecimal totaltxval = new BigDecimal(0);
				BigDecimal totaliamt = new BigDecimal(0);;
				BigDecimal totalcamt =new BigDecimal(0);
				BigDecimal totalsamt =new BigDecimal(0);
				BigDecimal totalcsamt = new BigDecimal(0);
				if(listb2ba!=null)
				{
					for(B2baInvoice item : listb2ba)
					{
						//flatB2baDetiallist = new ArrayList<B2baInvoiceDetailFlat>();
						B2baInvoiceFlat b2baflat = new B2baInvoiceFlat();
						b2baflat.setCtin(item.getCtin());
						for(B2baInvoiceDetail invDetail : item.getB2baInvoiceDetails()) {
							B2baInvoiceDetailFlat b2baInvoiceDetailFLat = new B2baInvoiceDetailFlat();
							b2baInvoiceDetailFLat.setInum(invDetail.getInum());
							b2baflat.setRchrg(invDetail.getRchrg());
							b2baflat.setInvTyp(invDetail.getInvTyp());
							b2baflat.setVal(invDetail.getVal());
							
							b2baInvoiceDetailFLat.setIdt(invDetail.getIdt());
							b2baInvoiceDetailFLat.setOinum(invDetail.getOinum());
							b2baInvoiceDetailFLat.setOidt(invDetail.getOidt());
							
							for (B2bItem item1 :invDetail.getB2bItems()) {
								totaltxval = totaltxval.add(item1.getB2bItemDetail().getTxval());
								totaliamt = totaliamt.add(item1.getB2bItemDetail().getIamt());
								totalcamt = totalcamt.add(item1.getB2bItemDetail().getCamt());
								totalsamt = totalsamt.add(item1.getB2bItemDetail().getSamt());
								totalcsamt = totalcsamt.add(item1.getB2bItemDetail().getCsamt());
								
							}
								b2baInvoiceDetailFLat.setTotaltxval(totaltxval);
								b2baInvoiceDetailFLat.setTotaliamt(totaliamt);
								b2baInvoiceDetailFLat.setTotalcamt(totalcamt);
								b2baInvoiceDetailFLat.setTotalcsamt(totalcsamt);
								b2baInvoiceDetailFLat.setTotalsamt(totalsamt);
								flatB2baDetiallist.add(b2baInvoiceDetailFLat);
							
						}
						b2baflat.setB2baInvoiceDetailFLat(flatB2baDetiallist);
						flatB2balist.add(b2baflat);
					}
				//	System.out.println("flatB2blist "+flatB2blist);
					List<B2baInvoiceFlatFinal> b2bafinalList = new ArrayList<B2baInvoiceFlatFinal>();
					
					for(B2baInvoiceFlat flatList : flatB2balist)
					{
						for(B2baInvoiceDetailFlat b2baInvoiceFlat : flatList.getB2baInvoiceDetailFLat()) {
							B2baInvoiceFlatFinal b2baInvoiceFlatFinal = new B2baInvoiceFlatFinal();
							b2baInvoiceFlatFinal.setFp(gstriObj.getFp());
							b2baInvoiceFlatFinal.setBusinessType("b2ba");
							b2baInvoiceFlatFinal.setCtin(flatList.getCtin());
							//b2baInvoiceFlatFinal.setRchrg(flatList.getRchrg());
							b2baInvoiceFlatFinal.setInvTyp(flatList.getInvTyp());
							b2baInvoiceFlatFinal.setVal(flatList.getVal());
							b2baInvoiceFlatFinal.setInum(b2baInvoiceFlat.getInum());
							b2baInvoiceFlatFinal.setIdt(b2baInvoiceFlat.getIdt());
							b2baInvoiceFlatFinal.setTotalcamt(b2baInvoiceFlat.getTotalcamt());
							b2baInvoiceFlatFinal.setTotalcsamt(b2baInvoiceFlat.getTotalcsamt());
							b2baInvoiceFlatFinal.setTotalsamt(b2baInvoiceFlat.getTotalsamt());
							b2baInvoiceFlatFinal.setTotaltxval(b2baInvoiceFlat.getTotaltxval());
							b2baInvoiceFlatFinal.setTotaliamt(b2baInvoiceFlat.getTotaliamt());
							b2baInvoiceFlatFinal.setOinum(flatList.getOinum());
							b2baInvoiceFlatFinal.setOidt(flatList.getOidt());
							b2bafinalList.add(b2baInvoiceFlatFinal);
						}
					}
					
					final ByteArrayOutputStream out = new ByteArrayOutputStream();
				    final ObjectMapper mapper = new ObjectMapper();
				    
				    mapper.writeValue(out, b2bafinalList);
			        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
			        StringBuilder tempFile = new StringBuilder();
			        Random rnd = new Random();
			        while (tempFile.length() < 18) { // length of the random string.
			            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
			            tempFile.append(SALTCHARS.charAt(index));
			        }
			        String tempFil = tempFile.toString();
			        File tempFileName = new File(tempFil+".json");
			        //return saltStr;
					mapper.writeValue(tempFileName, b2bafinalList);
					InputStream is = new FileInputStream(tempFileName);
					String contents = new BufferedReader(new InputStreamReader(is)).readLine();
					is.close(); 
					
						String str = contents.substring(1, contents.length()-1);
						String str1=str.replaceAll("},", "}\n");
						System.out.println(str1);
						str2= str2.concat(str1);
						return(str2);
						/*PrintWriter pr = new PrintWriter(new BufferedWriter(new FileWriter(new File(fileName), true)));
						pr.write(str1);
						pr.append("\n");
						pr.close();
						s3.putObject(bucketName, filePath+"/"+fileName, str1);*/
						//System.out.println("sucess");
			
				}						
		}
				catch(Exception ex)
				{
					
				}
			    return (str2);
	}
}
		
	





