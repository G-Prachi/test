package com.mind.egsp.gstn.dto.gstr1;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr1.B2clInvoice;

/**
 * The Class GetB2clInvoicesResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetB2clInvoicesResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The b2cl invoices. */
	@JsonProperty("b2cl")
	private List<B2clInvoice> b2clInvoices;

	/**
	 * Gets the b2cl invoices.
	 *
	 * @return the b2cl invoices
	 */
	public List<B2clInvoice> getB2clInvoices() {
		return b2clInvoices;
	}

	/**
	 * Sets the b2cl invoices.
	 *
	 * @param b2clInvoices
	 *            the new b2cl invoices
	 */
	public void setB2clInvoices(List<B2clInvoice> b2clInvoices) {
		this.b2clInvoices = b2clInvoices;
	}

}
