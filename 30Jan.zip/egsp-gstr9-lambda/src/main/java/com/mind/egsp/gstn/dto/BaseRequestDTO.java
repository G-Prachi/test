package com.mind.egsp.gstn.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

// TODO: Auto-generated Javadoc
/**
 * The Class BaseRequestDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public abstract class BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The session key for encryption and decryption. */
	@JsonIgnore
	private byte[] sk;

	/** The username. */
	@JsonIgnore
	private String username;

	/** The password. */
	@JsonIgnore
	private String password;

	/** The auth token. */
	@JsonIgnore
	private String authToken;

	/** The GSTIN of the Tax Payer. */
	@JsonIgnore
	private String gstin;

	/** The client id. */
	@JsonIgnore
	private Long clientId;

	/** The business type id. */
	@JsonIgnore
	private Long businessTypeId;

	/** The state cd. */
	@JsonIgnore
	private String stateCd;

	/** The ip usr. */
	@JsonIgnore
	private String ipUsr;

	/** The txn. */
	@JsonIgnore
	private String txn;

	/** Financial period. */
	@JsonIgnore
	private String retPeriod;

	/** The action. */
	private String action;

	/** The api action. */
	@JsonIgnore
	private String apiAction;

	/**
	 * Instantiates a new base request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param gstin
	 *            the gstin
	 * @param retPeriod
	 *            the ret period
	 * @param username
	 *            the username
	 */
	public BaseRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod, String username) {
		this.stateCd = stateCd;
		this.ipUsr = ipUsr;
		this.txn = txn;
		this.gstin = gstin;
		this.retPeriod = retPeriod;
		this.username = username;
	}

	/**
	 * Instantiates a new base request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param gstin
	 *            the gstin
	 * @param retPeriod
	 *            the ret period
	 * @param username
	 *            the username
	 * @param clientId
	 *            the client id
	 * @param businessTypeId
	 *            the business type id
	 */
	public BaseRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod, String username, Long clientId, Long businessTypeId) {
		this.stateCd = stateCd;
		this.ipUsr = ipUsr;
		this.txn = txn;
		this.gstin = gstin;
		this.retPeriod = retPeriod;
		this.username = username;
		this.clientId = clientId;
		this.businessTypeId = businessTypeId;
	}

	/**
	 * Instantiates a new base request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param gstin
	 *            the gstin
	 * @param retPeriod
	 *            the ret period
	 * @param username
	 *            the username
	 * @param clientId
	 *            the client id
	 */
	public BaseRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod, String username,
			Long clientId) {
		this.stateCd = stateCd;
		this.ipUsr = ipUsr;
		this.txn = txn;
		this.gstin = gstin;
		this.retPeriod = retPeriod;
		this.username = username;
		this.clientId = clientId;
	}

	/**
	 * Instantiates a new base request DTO.
	 *
	 * @param username
	 *            the username
	 * @param password
	 *            the password
	 * @param gstin
	 *            the gstin
	 */
	public BaseRequestDTO(String username, String password, String gstin) {
		super();
		this.username = username;
		this.password = password;
		this.gstin = gstin;
	}

	/**
	 * Instantiates a new base request DTO.
	 */
	public BaseRequestDTO() {
		super();
	}
	/**
	 * Gets the sk.
	 *
	 * @return the sk
	 */
	public byte[] getSk() {
		return sk;
	}

	/**
	 * Sets the sk.
	 *
	 * @param sk
	 *            the new sk
	 */
	public void setSk(byte[] sk) {
		this.sk = sk;
	}

	/**
	 * Gets the username.
	 *
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * Sets the username.
	 *
	 * @param username
	 *            the new username
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * Gets the auth token.
	 *
	 * @return the auth token
	 */
	public String getAuthToken() {
		return authToken;
	}

	/**
	 * Sets the auth token.
	 *
	 * @param authToken
	 *            the new auth token
	 */
	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}

	/**
	 * Gets the action.
	 *
	 * @return the action
	 */
	public String getAction() {
		return action;
	}

	/**
	 * Sets the action.
	 *
	 * @param action
	 *            the new action
	 */
	public void setAction(String action) {
		this.action = action;
	}

	/**
	 * Gets the ip usr.
	 *
	 * @return the ip usr
	 */
	public String getIpUsr() {
		return ipUsr;
	}

	/**
	 * Sets the ip usr.
	 *
	 * @param ipUsr
	 *            the new ip usr
	 */
	public void setIpUsr(String ipUsr) {
		this.ipUsr = ipUsr;
	}

	/**
	 * Gets the txn.
	 *
	 * @return the txn
	 */
	public String getTxn() {
		return txn;
	}

	/**
	 * Sets the txn.
	 *
	 * @param txn
	 *            the new txn
	 */
	public void setTxn(String txn) {
		this.txn = txn;
	}

	/**
	 * Gets the GSTIN of the taxpayer
	 * 
	 * Field Specification: Alphanumeric with 15 characters
	 * 
	 * Mandatory: Y
	 * 
	 * Sample Data: 29HJKPS9689A8Z4
	 * 
	 * Return.
	 *
	 * @return the gstin
	 */
	public String getGstin() {
		return gstin;
	}

	/**
	 * Sets the GSTIN of the taxpayer
	 * 
	 * Field Specification: Alphanumeric with 15 characters
	 * 
	 * Mandatory: Y
	 * 
	 * Sample Data: 29HJKPS9689A8Z4 Return.
	 *
	 * @param gstin
	 *            the new gstin
	 */
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the Return Period
	 * 
	 * Field Specification: MMYYYY
	 * 
	 * Mandatory: Y
	 * 
	 * Sample Data: 072016 .
	 *
	 * @return the ret period
	 */
	public String getRetPeriod() {
		return retPeriod;
	}

	/**
	 * Sets the Return Period
	 * 
	 * Field Specification: MMYYYY
	 * 
	 * Mandatory: Y
	 * 
	 * Sample Data: 072016 .
	 *
	 * @param retPeriod
	 *            the new ret period
	 */
	public void setRetPeriod(String retPeriod) {
		this.retPeriod = retPeriod;
	}

	/**
	 * Gets the Recipient state code
	 * 
	 * Field Specification: String(Max length:2)
	 * 
	 * Mandatory: N
	 * 
	 * Sample Data: 04 .
	 *
	 * @return the state cd
	 */
	public String getStateCd() {
		return stateCd;
	}

	/**
	 * Sets theRecipient state code
	 * 
	 * Field Specification: String(Max length:2)
	 * 
	 * Mandatory: N
	 * 
	 * Sample Data: 04.
	 *
	 * @param stateCd
	 *            the new state cd
	 */
	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}

	/**
	 * Gets the client id.
	 *
	 * @return the client id
	 */
	public Long getClientId() {
		return clientId;
	}

	/**
	 * Sets the client id.
	 *
	 * @param clientId
	 *            the new client id
	 */
	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}

	/**
	 * Gets the business type id.
	 *
	 * @return the business type id
	 */
	public Long getBusinessTypeId() {
		return businessTypeId;
	}

	/**
	 * Sets the business type id.
	 *
	 * @param businessTypeId
	 *            the new business type id
	 */
	public void setBusinessTypeId(Long businessTypeId) {
		this.businessTypeId = businessTypeId;
	}

	/**
	 * Gets the password.
	 *
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Sets the password.
	 *
	 * @param password
	 *            the new password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * Gets the api action.
	 *
	 * @return the api action
	 */
	public String getApiAction() {
		return apiAction;
	}

	/**
	 * Sets the api action.
	 *
	 * @param apiAction
	 *            the new api action
	 */
	public void setApiAction(String apiAction) {
		this.apiAction = apiAction;
	}


}
