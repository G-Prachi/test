package com.mind.egsp.gstn.dto.all;

import java.io.Serializable;
import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseResponseDTO;

/**
 * The Class GetPartiaITCDetailsResponseDTO.
 */
public class GetPartiaITCDetailsResponseDTO extends BaseResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The Invoice Number .
	 */
	@JsonProperty("inv_num")
	private String invNum;

	/**
	 * The Invoice Date .
	 */
	@JsonProperty("inv_dt")
	private String invDt;

	/**
	 * The Receiver GSTIN .
	 */
	private String rgstin;

	/**
	 * The IGST -Availed Amount .
	 */
	private BigDecimal igav;

	/**
	 * The IGST - Balance Available .
	 */
	private BigDecimal igbl;

	/**
	 * The CGST - Availed Amount .
	 */
	private BigDecimal cgav;

	/**
	 * The CGST - Balance Available .
	 */
	private BigDecimal cgbl;

	/**
	 * The SGST - Availed Amount .
	 */
	private BigDecimal sgav;

	/**
	 * The SGST - Balance Available .
	 */
	private BigDecimal sgbl;

	/**
	 * Gets the Invoice Number Field Specification: Alphanumeric (Max length:50
	 * Sample Data: 1234567 .
	 *
	 * @return the inv num
	 */
	public String getInvNum() {
		return invNum;
	}

	/**
	 * Sets the Invoice Number Field Specification: Alphanumeric (Max length:50
	 * Sample Data: 1234567 .
	 *
	 * @param invNum
	 *            the new inv num
	 */
	public void setInvNum(String invNum) {
		this.invNum = invNum;
	}

	/**
	 * Gets the Invoice Date Field Specification: Date [DD-MM-YYYY] Sample Data:
	 * 15-06-2016 .
	 *
	 * @return the inv dt
	 */
	public String getInvDt() {
		return invDt;
	}

	/**
	 * Sets the Invoice Date Field Specification: Date [DD-MM-YYYY] Sample Data:
	 * 15-06-2016 .
	 *
	 * @param invDt
	 *            the new inv dt
	 */
	public void setInvDt(String invDt) {
		this.invDt = invDt;
	}

	/**
	 * Gets the Receiver GSTIN Field Specification: String (15 characters)
	 * Sample Data: 29HJKPS9689A8Z5 .
	 *
	 * @return the rgstin
	 */
	public String getRgstin() {
		return rgstin;
	}

	/**
	 * Sets the Receiver GSTIN Field Specification: String (15 characters)
	 * Sample Data: 29HJKPS9689A8Z5 .
	 *
	 * @param rgstin
	 *            the new rgstin
	 */
	public void setRgstin(String rgstin) {
		this.rgstin = rgstin;
	}

	/**
	 * Gets the IGST -Availed Amount Field Specification: Decimal(p,2) Sample
	 * Data: 3456 .
	 *
	 * @return the igav
	 */
	public BigDecimal getIgav() {
		return igav;
	}

	/**
	 * Sets the IGST -Availed Amount Field Specification: Decimal(p,2) Sample
	 * Data: 3456 .
	 *
	 * @param igav
	 *            the new igav
	 */
	public void setIgav(BigDecimal igav) {
		this.igav = igav;
	}

	/**
	 * Gets the IGST - Balance Available Field Specification: Decimal(p,2)
	 * Sample Data: 1200 .
	 *
	 * @return the igbl
	 */
	public BigDecimal getIgbl() {
		return igbl;
	}

	/**
	 * Sets the IGST - Balance Available Field Specification: Decimal(p,2)
	 * Sample Data: 1200 .
	 *
	 * @param igbl
	 *            the new igbl
	 */
	public void setIgbl(BigDecimal igbl) {
		this.igbl = igbl;
	}

	/**
	 * Gets the CGST - Availed Amount Field Specification: Decimal(p,2) Sample
	 * Data: 8000 .
	 *
	 * @return the cgav
	 */
	public BigDecimal getCgav() {
		return cgav;
	}

	/**
	 * Sets the CGST - Availed Amount Field Specification: Decimal(p,2) Sample
	 * Data: 8000 .
	 *
	 * @param cgav
	 *            the new cgav
	 */
	public void setCgav(BigDecimal cgav) {
		this.cgav = cgav;
	}

	/**
	 * Gets the CGST - Balance Available Field Specification: Decimal(p,2)
	 * Sample Data: 4000 .
	 *
	 * @return the cgbl
	 */
	public BigDecimal getCgbl() {
		return cgbl;
	}

	/**
	 * Sets the CGST - Balance Available Field Specification: Decimal(p,2)
	 * Sample Data: 4000 .
	 *
	 * @param cgbl
	 *            the new cgbl
	 */
	public void setCgbl(BigDecimal cgbl) {
		this.cgbl = cgbl;
	}

	/**
	 * Gets the SGST - Availed Amount Field Specification: Decimal(p,2) Sample
	 * Data: 7800 .
	 *
	 * @return the sgav
	 */
	public BigDecimal getSgav() {
		return sgav;
	}

	/**
	 * Sets the SGST - Availed Amount Field Specification: Decimal(p,2) Sample
	 * Data: 7800 .
	 *
	 * @param sgav
	 *            the new sgav
	 */
	public void setSgav(BigDecimal sgav) {
		this.sgav = sgav;
	}

	/**
	 * Gets the SGST - Balance Available Field Specification: Decimal(p,2)
	 * Sample Data: 5670 .
	 *
	 * @return the sgbl
	 */
	public BigDecimal getSgbl() {
		return sgbl;
	}

	/**
	 * Sets the SGST - Balance Available Field Specification: Decimal(p,2)
	 * Sample Data: 5670 .
	 *
	 * @param sgbl
	 *            the new sgbl
	 */
	public void setSgbl(BigDecimal sgbl) {
		this.sgbl = sgbl;
	}

}
