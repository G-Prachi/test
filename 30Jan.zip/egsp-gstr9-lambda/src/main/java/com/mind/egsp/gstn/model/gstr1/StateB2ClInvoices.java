package com.mind.egsp.gstn.model.gstr1;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * The Class SaveB2ClInvoice.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class StateB2ClInvoices implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Recipient state code. */

	// @JsonProperty("state_cd")
	@JsonIgnore
	private String stateCd;

	/** The Place of Supply . */
	private String pos;

	/** The B2clInvoice Details of . */
	@JsonProperty("inv")
	private List<B2clInvoiceDetail> b2clInvoiceDetails;

	/**
	 * Gets the Recipient state code.
	 * 
	 * Sample Data: 06
	 *
	 * @return the state cd
	 */
	public String getStateCd() {
		return stateCd;
	}

	/**
	 * Sets the Recipient state code.
	 * 
	 * Sample Data: 06
	 *
	 * @param stateCd
	 *            the new state cd
	 */
	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}

	/**
	 * Gets the pos.
	 *
	 * @return the pos
	 */
	public String getPos() {
		return pos;
	}

	/**
	 * Sets the pos.
	 *
	 * @param pos
	 *            the new pos
	 */
	public void setPos(String pos) {
		this.pos = pos;
	}

	/**
	 * Gets the save B2cl invoice detail.
	 *
	 * @return the save B2cl invoice detail
	 */
	public List<B2clInvoiceDetail> getB2clInvoiceDetails() {
		return b2clInvoiceDetails;
	}

	/**
	 * Sets the save B2cl invoice detail.
	 *
	 * @param b2clInvoiceDetails
	 *            the new b 2 cl invoice details
	 */
	public void setB2clInvoiceDetails(List<B2clInvoiceDetail> b2clInvoiceDetails) {
		this.b2clInvoiceDetails = b2clInvoiceDetails;
	}

}
