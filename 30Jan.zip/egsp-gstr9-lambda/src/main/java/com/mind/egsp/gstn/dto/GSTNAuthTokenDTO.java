package com.mind.egsp.gstn.dto;

import java.util.Calendar;

public class GSTNAuthTokenDTO {
	String appKey, authToken, userIp;
	Calendar tokenExpiryTime;
	byte[] sk;
	Calendar sessionExpiryTime;
	
	public GSTNAuthTokenDTO( String appKey){
		super();
		this.appKey = appKey;
	}
	
	public GSTNAuthTokenDTO(String appKey, String authToken, String userIp, Calendar tokenExpiryTime, byte[] sk,
			Calendar sessionExpiryTime) {
		super();
		this.appKey = appKey;
		this.authToken = authToken;
		this.userIp = userIp;
		this.tokenExpiryTime = tokenExpiryTime;
		this.sk = sk;
		this.sessionExpiryTime = sessionExpiryTime;
	}
	
	
	public String getAppKey() {
		return appKey;
	}
	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}
	public String getAuthToken() {
		return authToken;
	}
	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}
	public String getUserIp() {
		return userIp;
	}
	public void setUserIp(String userIp) {
		this.userIp = userIp;
	}
	public Calendar getTokenExpiryTime() {
		return tokenExpiryTime;
	}
	public void setTokenExpiryTime(Calendar tokenExpiryTime) {
		this.tokenExpiryTime = tokenExpiryTime;
	}
	public byte[] getSk() {
		return sk;
	}
	public void setSk(byte[] sk) {
		this.sk = sk;
	}
	public Calendar getSessionExpiryTime() {
		return sessionExpiryTime;
	}
	public void setSessionExpiryTime(Calendar sessionExpiryTime) {
		this.sessionExpiryTime = sessionExpiryTime;
	}

}
