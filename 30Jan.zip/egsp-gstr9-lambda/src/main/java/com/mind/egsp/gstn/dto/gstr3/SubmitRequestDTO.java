package com.mind.egsp.gstn.dto.gstr3;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

/**
 * The Class SubmitGSTR3RequestDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class SubmitRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The submit GSTR 3 DTO. */
	@JsonProperty("data")
	private SubmitDTO submitGSTR3DTO;

	/**
	 * Instantiates a new submit GSTR 3 request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param gstin
	 *            the gstin
	 * @param retPeriod
	 *            the ret period
	 * @param username
	 *            the username
	 */
	public SubmitRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);

	}

}
