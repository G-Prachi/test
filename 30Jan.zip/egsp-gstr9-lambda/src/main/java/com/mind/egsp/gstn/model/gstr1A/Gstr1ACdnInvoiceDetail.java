package com.mind.egsp.gstn.model.gstr1A;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.model.gstr1.CDNRItem;
import com.mind.egsp.gstn.model.gstr1.CdnrInvoiceDetail;

/**
 * The Class Gstr2CdnrInvoiceDetail.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Gstr1ACdnInvoiceDetail extends CdnrInvoiceDetail implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Invoice Status. */
	private Character flag;

	/** The Counter Party Flag. */
	private Character cflag;

	/** The Original Period. */
	private String opd;

	/** The Uploaded By. */
	private Character updby;

	/** The Invoice Check sum value . */
	private String chksum;

	/** The Credit/debit note number. */
	@JsonProperty("nt_num")
	private String ntNum;

	/** The Credit/Debit Note date. */
	@JsonProperty("nt_dt")
	private String ntDt;

	/** The Reason Code for issuing Debit/Credit Note. */
	private String rsn;

	/** The Pre GST Regime Dr./ Cr. Notes. */
	@JsonProperty("p_gst")
	private Character pGst;

	/** The Credit/debit note type. */
	private Character ntty;

	/** The Original invoice number. */
	private String inum;

	/** The Invoice date. */
	private String idt;

	/** The Differential Value for which Dr./ Cr. note is issued. */
	private BigDecimal val;

	/** The cdnr items. */
	@JsonProperty("itms")
	private List<CDNRItem> cdnrItems;

	/**
	 * Gets the Invoice Status.
	 *
	 * @return the flag
	 */
	public Character getFlag() {
		return flag;
	}

	/**
	 * Sets the Invoice Status.
	 *
	 * @param flag
	 *            the new flag
	 */
	public void setFlag(Character flag) {
		this.flag = flag;
	}

	/**
	 * Gets the Uploaded By.
	 *
	 * @return the updby
	 */
	public Character getUpdby() {
		return updby;
	}

	/**
	 * Sets the Uploaded By.
	 *
	 * @param updby
	 *            the new updby
	 */
	public void setUpdby(Character updby) {
		this.updby = updby;
	}

	/**
	 * Gets the Invoice Check sum value .
	 *
	 * @return the chksum
	 */
	public String getChksum() {
		return chksum;
	}

	/**
	 * Sets the Invoice Check sum value .
	 *
	 * @param chksum
	 *            the new chksum
	 */
	public void setChksum(String chksum) {
		this.chksum = chksum;
	}

	/**
	 * Gets the Credit/debit note type.
	 *
	 * @return the ntty
	 */
	public Character getNtty() {
		return ntty;
	}

	/**
	 * Sets the Credit/debit note type.
	 *
	 * @param ntty
	 *            the new ntty
	 */
	public void setNtty(Character ntty) {
		this.ntty = ntty;
	}

	/**
	 * Gets the Credit/debit note number.
	 *
	 * @return the nt num
	 */
	public String getNtNum() {
		return ntNum;
	}

	/**
	 * Sets the Credit/debit note number.
	 *
	 * @param ntNum
	 *            the new nt num
	 */
	public void setNtNum(String ntNum) {
		this.ntNum = ntNum;
	}

	/**
	 * Gets the Reason Code for issuing Debit/Credit Note.
	 *
	 * @return the rsn
	 */
	public String getRsn() {
		return rsn;
	}

	/**
	 * Sets the Reason Code for issuing Debit/Credit Note.
	 *
	 * @param rsn
	 *            the new rsn
	 */
	public void setRsn(String rsn) {
		this.rsn = rsn;
	}

	/**
	 * Gets the Original invoice number.
	 *
	 * @return the inum
	 */
	public String getInum() {
		return inum;
	}

	/**
	 * Sets the Original invoice number.
	 *
	 * @param inum
	 *            the new inum
	 */
	public void setInum(String inum) {
		this.inum = inum;
	}

	/**
	 * Gets the Invoice date.
	 *
	 * @return the idt
	 */
	public String getIdt() {
		return idt;
	}

	/**
	 * Sets the Invoice date.
	 *
	 * @param idt
	 *            the new idt
	 */
	public void setIdt(String idt) {
		this.idt = idt;
	}

	/**
	 * Gets the Differential Value for which Dr./ Cr. note is issued.
	 *
	 * @return the val
	 */
	public BigDecimal getVal() {
		return val;
	}

	/**
	 * Sets the Differential Value for which Dr./ Cr. note is issued.
	 *
	 * @param val
	 *            the new val
	 */
	public void setVal(BigDecimal val) {
		this.val = val;
	}

	/**
	 * Gets the Credit/Debit Note date.
	 *
	 * @return the nt dt
	 */
	public String getNtDt() {
		return ntDt;
	}

	/**
	 * Sets the Credit/Debit Note date.
	 *
	 * @param ntDt
	 *            the new nt dt
	 */
	public void setNtDt(String ntDt) {
		this.ntDt = ntDt;
	}

	/**
	 * Gets the cflag.
	 *
	 * @return the cflag
	 */
	public Character getCflag() {
		return cflag;
	}

	/**
	 * Sets the cflag.
	 *
	 * @param cflag
	 *            the new cflag
	 */
	public void setCflag(Character cflag) {
		this.cflag = cflag;
	}

	/**
	 * Gets the opd.
	 *
	 * @return the opd
	 */
	public String getOpd() {
		return opd;
	}

	/**
	 * Sets the opd.
	 *
	 * @param opd
	 *            the new opd
	 */
	public void setOpd(String opd) {
		this.opd = opd;
	}

	/**
	 * Gets the cdnr items.
	 *
	 * @return the cdnr items
	 */
	public List<CDNRItem> getCdnrItems() {
		return cdnrItems;
	}

	/**
	 * Sets the cdnr items.
	 *
	 * @param cdnrItems
	 *            the new cdnr items
	 */
	public void setCdnrItems(List<CDNRItem> cdnrItems) {
		this.cdnrItems = cdnrItems;
	}

	/**
	 * Gets the p gst.
	 *
	 * @return the p gst
	 */
	public Character getpGst() {
		return pGst;
	}

	/**
	 * Sets the p gst.
	 *
	 * @param pGst
	 *            the new p gst
	 */
	public void setpGst(Character pGst) {
		this.pGst = pGst;
	}

}
