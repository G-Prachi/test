package com.mind.egsp.gstn.model.gstr1;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * The Class TxpdaInvoice.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class TxpdaInvoice extends TxpdInvoice implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Original Month. */
	private String omon;



	/**
	 * Gets the Original Month
	 * 
	 * Field Specification: String(MMYYYY)
	 * 
	 * Sample Data: 032017
	 *
	 * @return the omon
	 */
	public String getOmon() {
		return omon;
	}

	/**
	 * Sets the Original Month
	 * 
	 * Field Specification: String(MMYYYY)
	 * 
	 * Sample Data: 032017
	 *
	 * @param typ
	 *            the new omon
	 */
	public void setOmon(String omon) {
		this.omon = omon;
	}



}
