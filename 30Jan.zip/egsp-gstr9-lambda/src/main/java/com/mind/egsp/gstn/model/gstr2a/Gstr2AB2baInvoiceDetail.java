package com.mind.egsp.gstn.model.gstr2a;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.model.gstr2.Gstr2B2bInvoiceDetail;

// TODO: Auto-generated Javadoc
/**
 * The Class Gstr2B2BInvoice.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Gstr2AB2baInvoiceDetail extends Gstr2B2bInvoiceDetail implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** Original Invoice Number. */
	private String oinum;

	/** Original Invoice Date. */
	private String oidt;

	/** The diff percent. */
	@JsonProperty("diff_percent")
	private String diffPercent;

	/**
	 * Gets the oinum.
	 *
	 * @return the oinum
	 */
	public String getOinum() {
		return oinum;
	}

	/**
	 * Sets the oinum.
	 *
	 * @param oinum
	 *            the new oinum
	 */
	public void setOinum(String oinum) {
		this.oinum = oinum;
	}

	/**
	 * Gets the oidt.
	 *
	 * @return the oidt
	 */
	public String getOidt() {
		return oidt;
	}

	/**
	 * Sets the oidt.
	 *
	 * @param oidt
	 *            the new oidt
	 */
	public void setOidt(String oidt) {
		this.oidt = oidt;
	}

	/**
	 * Gets the diff percent.
	 *
	 * @return the diff percent
	 */
	public String getDiffPercent() {
		return diffPercent;
	}

	/**
	 * Sets the diff percent.
	 *
	 * @param diffPercent
	 *            the new diff percent
	 */
	public void setDiffPercent(String diffPercent) {
		this.diffPercent = diffPercent;
	}

}
