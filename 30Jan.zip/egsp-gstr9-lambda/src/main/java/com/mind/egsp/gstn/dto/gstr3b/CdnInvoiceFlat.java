package com.mind.egsp.gstn.dto.gstr3b;

public class CdnInvoiceFlat {

}
