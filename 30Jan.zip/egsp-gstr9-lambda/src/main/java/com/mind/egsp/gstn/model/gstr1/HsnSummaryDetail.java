package com.mind.egsp.gstn.model.gstr1;

import java.io.Serializable;
import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Class for HSN/SAC summary of outward supplies.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class HsnSummaryDetail implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Invoice Check sum value. */
	@JsonIgnore
	private String chksum;

	/** The Serial Number. */
	private Integer num;

	/** The Identifier if Goods or Services. */
	private String ty;

	/** The Taxable value of Goods or Service as per invoice. */
	private BigDecimal txval;

	/** The HSN or SAC of Goods or Services as per Invoice line items. */
	@JsonProperty("hsn_sc")
	private String hsnSc;

	/** The Description of goods sold. */
	private String desc;

	/** The UQC (Unit of Measure) of goods sold. */
	private String uqc;

	/** The Quantity of goods sold. */
	private BigDecimal qty;

	/** The Nature of Supply . */
	// @JsonProperty("sply_ty")
	@JsonIgnore
	private String splyTy;

	/** The IGST Rate as per invoice. */
	private BigDecimal irt;

	/** The IGST Amount as per invoice. */
	private BigDecimal iamt;

	/** The CGST Rate as per invoice. */
	private BigDecimal crt;

	/** The CGST Amount as per invoice. */
	private BigDecimal camt;

	/** The SGST Rate as per invoice. */
	private BigDecimal srt;

	/** The SGST Amount as per invoice. */
	private BigDecimal samt;

	/** The Cess Rate as per invoice. */
	private BigDecimal csrt;

	/** The Cess Amount as per invoice. */
	private BigDecimal csamt;

	/** The val. */
	private BigDecimal val;

	/**
	 * Gets the Invoice Check sum value.
	 *
	 * @return the Invoice Check sum value
	 */
	public String getChksum() {
		return chksum;
	}

	/**
	 * Sets the Invoice Check sum value.
	 *
	 * @param chksum
	 *            the new Invoice Check sum value
	 */
	public void setChksum(String chksum) {
		this.chksum = chksum;
	}

	/**
	 * Gets the Serial Number
	 * 
	 * Field Specification: Integer
	 * 
	 * Sample Data: 1.00 .
	 *
	 * @return the num
	 */
	public Integer getNum() {
		return num;
	}

	/**
	 * Sets the Serial Number
	 * 
	 * Field Specification: Integer
	 * 
	 * Sample Data: 1.00 .
	 *
	 * @param num
	 *            the new num
	 */
	public void setNum(Integer num) {
		this.num = num;
	}

	/**
	 * Gets the Identifier if Goods or Services
	 * 
	 * Field Specification: One Character (G or S)
	 * 
	 * Sample Data: G- Goods, S- services .
	 *
	 * @return the ty
	 */
	public String getTy() {
		return ty;
	}

	/**
	 * Sets the Identifier if Goods or Services
	 * 
	 * Field Specification: One Character (G or S)
	 * 
	 * Sample Data: G- Goods, S- services .
	 *
	 * @param ty
	 *            the new ty
	 */
	public void setTy(String ty) {
		this.ty = ty;
	}

	/**
	 * Gets the HSN or SAC of Goods or Services as per Invoice line items
	 * 
	 * Field Specification: Alphanumeric (Max length:10)
	 * 
	 * Sample Data: 19059020 .
	 *
	 * @return the hsn sc
	 */
	public String getHsnSc() {
		return hsnSc;
	}

	/**
	 * Sets the HSN or SAC of Goods or Services as per Invoice line items
	 * 
	 * Field Specification: Alphanumeric (Max length:10)
	 * 
	 * Sample Data: 19059020 .
	 *
	 * @param hsnSc
	 *            the new hsn sc
	 */
	public void setHsnSc(String hsnSc) {
		this.hsnSc = hsnSc;
	}

	/**
	 * Gets the Description of goods sold
	 * 
	 * Field Specification: string(Max length:30)
	 * 
	 * Sample Data: Gold .
	 *
	 * @return the desc
	 */
	public String getDesc() {
		return desc;
	}

	/**
	 * Sets the Description of goods sold
	 * 
	 * Field Specification: string(Max length:30)
	 * 
	 * Sample Data: Gold .
	 *
	 * @param desc
	 *            the new desc
	 */
	public void setDesc(String desc) {
		this.desc = desc;
	}

	/**
	 * Gets the UQC (Unit of Measure) of goods sold Field
	 * 
	 * Specification: string(Max length:30)
	 * 
	 * Sample Data: Kg .
	 *
	 * @return the uqc
	 */
	public String getUqc() {
		return uqc;
	}

	/**
	 * Sets the UQC (Unit of Measure) of goods sold
	 * 
	 * Field Specification: string(Max length:30)
	 * 
	 * Sample Data: Kg .
	 *
	 * @param uqc
	 *            the new uqc
	 */
	public void setUqc(String uqc) {
		this.uqc = uqc;
	}

	/**
	 * Gets the Quantity of goods sold
	 * 
	 * Field Specification: Decimal(p,3)
	 * 
	 * Sample Data: 10.000 .
	 *
	 * @return the qty
	 */
	public BigDecimal getQty() {
		return qty;
	}

	/**
	 * Sets the Quantity of goods sold
	 * 
	 * Field Specification: Decimal(p,3)
	 * 
	 * Sample Data: 10.000 .
	 *
	 * @param qty
	 *            the new qty
	 */
	public void setQty(BigDecimal qty) {
		this.qty = qty;
	}

	/**
	 * Gets the Nature of Supply 
	 * 
	 * Field Specification: string (Max length:50)
	 * 
	 * Sample Data: Inter-State B2C .
	 *
	 * @return the sply ty
	 */
	public String getSplyTy() {
		return splyTy;
	}

	/**
	 * Sets the Nature of Supply 
	 * 
	 * 
	 * Field Specification: string (Max length:50)
	 * 
	 * Sample Data: Inter-State B2C .
	 *
	 * @param splyTy
	 *            the new sply ty
	 */
	public void setSplyTy(String splyTy) {
		this.splyTy = splyTy;
	}

	/**
	 * Gets the Taxable value of Goods or Service as per invoice
	 * 
	 * Field Specification: Decimal(15, 2)
	 * 
	 * Sample Data: 10000.00 .
	 *
	 * @return the txval
	 */
	public BigDecimal getTxval() {
		return txval;
	}

	/**
	 * Sets the Taxable value of Goods or Service as per invoice
	 * 
	 * Field Specification: Decimal(15, 2)
	 * 
	 * Sample Data: 10000.00 .
	 *
	 * @param txval
	 *            the new txval
	 */
	public void setTxval(BigDecimal txval) {
		this.txval = txval;
	}

	/**
	 * Gets the IGST Rate as per invoice
	 * 
	 * Field Specification: Decimal(15, 2)
	 * 
	 * Sample Data: 10.00 .
	 *
	 * @return the irt
	 */
	public BigDecimal getIrt() {
		return irt;
	}

	/**
	 * Sets the IGST Rate as per invoice
	 * 
	 * Field Specification: Decimal(15, 2)
	 * 
	 * Sample Data: 10.00 .
	 *
	 * @param irt
	 *            the new irt
	 */
	public void setIrt(BigDecimal irt) {
		this.irt = irt;
	}

	/**
	 * Gets the IGST Amount as per invoice
	 * 
	 * Field Specification: Decimal(15, 2)
	 * 
	 * Sample Data: 1000.00 .
	 *
	 * @return the iamt
	 */
	public BigDecimal getIamt() {
		return iamt;
	}

	/**
	 * Sets the IGST Amount as per invoice
	 * 
	 * Field Specification: Decimal(15, 2)
	 * 
	 * Sample Data: 1000.00 .
	 *
	 * @param iamt
	 *            the new iamt
	 */
	public void setIamt(BigDecimal iamt) {
		this.iamt = iamt;
	}

	/**
	 * Gets the CGST Rate as per invoice
	 * 
	 * Field Specification: Decimal(15, 2)
	 * 
	 * Sample Data: 10.00 .
	 *
	 * @return the crt
	 */
	public BigDecimal getCrt() {
		return crt;
	}

	/**
	 * Sets the CGST Rate as per invoice
	 * 
	 * Field Specification: Decimal(15, 2)
	 * 
	 * Sample Data: 10.00 .
	 *
	 * @param crt
	 *            the new crt
	 */
	public void setCrt(BigDecimal crt) {
		this.crt = crt;
	}

	/**
	 * Gets the CGST Amount as per invoice
	 * 
	 * Field Specification: Decimal(15, 2)
	 * 
	 * Sample Data: 1000.00 .
	 *
	 * @return the camt
	 */
	public BigDecimal getCamt() {
		return camt;
	}

	/**
	 * Sets the CGST Amount as per invoice
	 * 
	 * Field Specification: Decimal(15, 2)
	 * 
	 * Sample Data: 1000.00 .
	 *
	 * @param camt
	 *            the new camt
	 */
	public void setCamt(BigDecimal camt) {
		this.camt = camt;
	}

	/**
	 * Gets the SGST Rate as per invoice
	 * 
	 * Field Specification: Decimal(15, 2)
	 * 
	 * Sample Data: 10.00 .
	 *
	 * @return the srt
	 */
	public BigDecimal getSrt() {
		return srt;
	}

	/**
	 * Sets the SGST Rate as per invoice
	 * 
	 * Field Specification: Decimal(15, 2)
	 * 
	 * Sample Data: 10.00 .
	 *
	 * @param srt
	 *            the new srt
	 */
	public void setSrt(BigDecimal srt) {
		this.srt = srt;
	}

	/**
	 * Gets the SGST Amount as per invoice
	 * 
	 * Field Specification: Decimal(15, 2)
	 * 
	 * Sample Data: 1000.00 .
	 *
	 * @return the samt
	 */
	public BigDecimal getSamt() {
		return samt;
	}

	/**
	 * Sets the SGST Amount as per invoice
	 * 
	 * Field Specification: Decimal(15, 2)
	 * 
	 * Sample Data: 1000.00 .
	 *
	 * @param samt
	 *            the new samt
	 */
	public void setSamt(BigDecimal samt) {
		this.samt = samt;
	}

	/**
	 * Gets the Cess Rate as per invoice
	 * 
	 * Field Specification: Decimal(15, 2)
	 * 
	 * Sample Data: 10.00 .
	 *
	 * @return the csrt
	 */
	public BigDecimal getCsrt() {
		return csrt;
	}

	/**
	 * Sets the Cess Rate as per invoice
	 * 
	 * Field Specification: Decimal(15, 2)
	 * 
	 * Sample Data: 10.00 .
	 *
	 * @param csrt
	 *            the new csrt
	 */
	public void setCsrt(BigDecimal csrt) {
		this.csrt = csrt;
	}

	/**
	 * Gets the Cess Amount as per invoice
	 * 
	 * Field Specification: Decimal(15, 2)
	 * 
	 * Sample Data: 1000.00 .
	 *
	 * @return the csamt
	 */
	public BigDecimal getCsamt() {
		return csamt;
	}

	/**
	 * 
	 * Sets the Cess Amount as per invoice
	 * 
	 * Field Specification: Decimal(15, 2)
	 * 
	 * Sample Data: 1000.00 .
	 *
	 * @param csamt
	 *            the new csamt
	 */
	public void setCsamt(BigDecimal csamt) {
		this.csamt = csamt;
	}

	/**
	 * Gets the val.
	 *
	 * @return the val
	 */
	public BigDecimal getVal() {
		return val;
	}

	/**
	 * Sets the val.
	 *
	 * @param val
	 *            the new val
	 */
	public void setVal(BigDecimal val) {
		this.val = val;
	}
	
	public String toString(){
		StringBuilder builder = new StringBuilder();
		if (camt != null) {
			builder.append("camt=");
			builder.append(camt);	
			builder.append(",");	
		}
		if (crt != null) {
			builder.append("crt=");
			builder.append(crt);	
			builder.append(",");	
		}
		if (csamt != null) {
			builder.append("csamt=");
			builder.append(csamt);	
			builder.append(",");	
		}
		if (csrt != null) {
			builder.append("csrt=");
			builder.append(csrt);	
			builder.append(",");	
		}
		if (desc != null) {
			builder.append("desc=");
			builder.append(desc);	
			builder.append(",");	
		}
		if (hsnSc != null) {
			builder.append("hsn_sc=");
			builder.append(hsnSc);	
			builder.append(",");	
		}
		if (iamt != null) {
			builder.append("iamt=");
			builder.append(iamt);	
			builder.append(",");	
		}
		if (irt != null) {
			builder.append("irt=");
			builder.append(irt);	
			builder.append(",");	
		}
		if (num != null) {
			builder.append("num=");
			builder.append(num);	
			builder.append(",");	
		}
		if (qty != null) {
			builder.append("qty=");
			builder.append(qty);	
			builder.append(",");	
		}
		if (samt != null) {
			builder.append("samt=");
			builder.append(samt);	
			builder.append(",");	
		}
		if (srt != null) {
			builder.append("srt=");
			builder.append(srt);	
			builder.append(",");	
		}
		if (txval != null) {
			builder.append("txval=");
			builder.append(txval);	
			builder.append(",");	
		}
		if (ty != null) {
			builder.append("ty=");
			builder.append(ty);	
			builder.append(",");	
		}
		if (uqc != null) {
			builder.append("uqc=");
			builder.append(uqc);	
			builder.append(",");	
		}
		if (val != null) {
			builder.append("val=");
			builder.append(val);	
			builder.append(",");	
		}
		if(builder.length() > 1) {
			if (builder.charAt(builder.length() - 1) == ',') {
			builder.setLength(builder.length() - 1);
			}
		}
		return builder.toString(); 
		}


}
