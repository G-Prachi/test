package com.mind.egsp.gstn.dto.gstr9;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr9.Gstr9GetDetails;

/**
 * The Class Gstr9GetDetailsResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Gstr9GetDetailsResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	
	/** The get details. */
	@JsonIgnore
	private Gstr9GetDetails getDetails;


	/**
	 * Gets the gets the details.
	 *
	 * @return the gets the details
	 */
	public Gstr9GetDetails getGetDetails() {
		return getDetails;
	}


	/**
	 * Sets the gets the details.
	 *
	 * @param getDetails the new gets the details
	 */
	public void setGetDetails(Gstr9GetDetails getDetails) {
		this.getDetails = getDetails;
	}

	
	
}
