package com.mind.egsp.gstn.dto.gstr8;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr8.Gstr8CdnuraInvoice;

// TODO: Auto-generated Javadoc
/**
 * The Class Gstr8GetCdnuraInvoicesResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Gstr8GetCdnuraInvoicesResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The cdnura invoices. */
	@JsonProperty("cdnur")
	private List<Gstr8CdnuraInvoice> cdnuraInvoices;

	/** The Token. */
	private String token;

	/** The Estimated Time in minutes. */
	private String est;

	/**
	 * Gets the token.
	 *
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * Sets the token.
	 *
	 * @param token
	 *            the new token
	 */
	public void setToken(String token) {
		this.token = token;
	}

	/**
	 * Gets the Estimated Time in minutes.
	 *
	 * @return the est
	 */
	public String getEst() {
		return est;
	}

	/**
	 * Sets the Estimated Time in minutes.
	 *
	 * @param est
	 *            the new est
	 */
	public void setEst(String est) {
		this.est = est;
	}

	/**
	 * Gets the gets the cdnra invoice.
	 *
	 * @return the gets the cdnra invoice
	 */
	public List<Gstr8CdnuraInvoice> getGetCdnuraInvoice() {
		return cdnuraInvoices;
	}

	/**
	 * Sets the gets the cdnra invoice.
	 *
	 * @param cdnurInvoices
	 *            the new gets the cdnura invoice
	 */
	public void setGetCdnurInvoice(List<Gstr8CdnuraInvoice> cdnuraInvoices) {
		this.cdnuraInvoices = cdnuraInvoices;
	}
}
