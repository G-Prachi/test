package com.mind.egsp.gstn.dto;

/**
 * Keeps the Authorization Signature and  date (Amazon expected format).
 */
public class SignatureDTO {
    
    /** The x amz date. */
    private String xAmzDate;
    
    /** The authorization. */
    private String authorization;
    
    /** The api key. */
    private String apiKey;

	/**
	 * Instantiates a new signature DTO.
	 */
	public SignatureDTO(){}

    /**
     * Instantiates a new signature DTO.
     *
     * @param xAmzDate the x amz date
     * @param authorization the authorization
     */
    public SignatureDTO(String xAmzDate, String authorization) {
        this.xAmzDate = xAmzDate;
        this.authorization = authorization;
    }

    /**
     * Gets the x amz date.
     *
     * @return the x amz date
     */
    public String getxAmzDate() {
        return xAmzDate;
    }

    /**
     * Sets the x amz date.
     *
     * @param xAmzDate the new x amz date
     */
    public void setxAmzDate(String xAmzDate) {
        this.xAmzDate = xAmzDate;
    }

    /**
     * Gets the authorization.
     *
     * @return the authorization
     */
    public String getAuthorization() {
        return authorization;
    }

    /**
     * Sets the authorization.
     *
     * @param authorization the new authorization
     */
    public void setAuthorization(String authorization) {
        this.authorization = authorization;
    }
    
    /**
     * Gets the api key.
     *
     * @return the api key
     */
    public String getApiKey() {
		return apiKey;
	}

	/**
	 * Sets the api key.
	 *
	 * @param apiKey the new api key
	 */
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}

}
