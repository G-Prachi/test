package com.mind.egsp.gstn.model.all;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.model.gstr1.B2clInvoiceDetail;

// TODO: Auto-generated Javadoc
/**
 * The Class B2CLErrorReport.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class B2CLErrorReport implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The B2CL Invoice. */
	@JsonProperty("inv")
	private List<B2clInvoiceDetail> b2clInvoiceDetails;

	/**
	 * The Error_cd .
	 */
	@JsonProperty("error_cd")
	private String errorCd;

	/**
	 * The Error Message .
	 */
	private String pos;

	/**
	 * The Error Message .
	 */
	@JsonProperty("error_msg")
	private String errorMsg;

	/**
	 * Gets the Error_cd Field Specification: Alphanumeric (Max length:10) Sample
	 * Data: RET100 .
	 *
	 * @return the error cd
	 */
	public String getErrorCd() {
		return errorCd;
	}

	/**
	 * Sets the Error_cd Field Specification: Alphanumeric (Max length:10) Sample
	 * Data: RET100 .
	 *
	 * @param errorCd
	 *            the new error cd
	 */
	public void setErrorCd(String errorCd) {
		this.errorCd = errorCd;
	}

	/**
	 * Gets the Error Message Field Specification: Alphanumeric (Max length:100)
	 * Sample Data: Duplicate Invoice .
	 *
	 * @return the error msg
	 */
	public String getErrorMsg() {
		return errorMsg;
	}

	/**
	 * Sets the Error Message Field Specification: Alphanumeric (Max length:100)
	 * Sample Data: Duplicate Invoice .
	 *
	 * @param errorMsg
	 *            the new error msg
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	/**
	 * Gets the b 2 cl invoice details.
	 *
	 * @return the b 2 cl invoice details
	 */
	public List<B2clInvoiceDetail> getB2clInvoiceDetails() {
		return b2clInvoiceDetails;
	}

	/**
	 * Sets the b 2 cl invoice details.
	 *
	 * @param b2clInvoiceDetails
	 *            the new b 2 cl invoice details
	 */
	public void setB2clInvoiceDetails(List<B2clInvoiceDetail> b2clInvoiceDetails) {
		this.b2clInvoiceDetails = b2clInvoiceDetails;
	}

	/**
	 * Gets the pos.
	 *
	 * @return the pos
	 */
	public String getPos() {
		return pos;
	}

	/**
	 * Sets the pos.
	 *
	 * @param pos
	 *            the new pos
	 */
	public void setPos(String pos) {
		this.pos = pos;
	}

}
