package com.mind.egsp.gstn.dto.gstr8;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseRequestDTO;
import com.mind.egsp.gstn.model.gstr8.Gstr8SubmitData;

// TODO: Auto-generated Javadoc
/**
 * The Class SubmitGstr8RequestDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class SubmitGstr8RequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The gstr 8 submit data. */
	@JsonProperty("data")
	private Gstr8SubmitData gstr8SubmitData = new Gstr8SubmitData();

	/**
	 * Instantiates a new submit gstr 8 request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param gstin
	 *            the gstin
	 * @param retPeriod
	 *            the ret period
	 * @param username
	 *            the username
	 */
	public SubmitGstr8RequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
		this.gstr8SubmitData.setGstin(gstin);
		this.gstr8SubmitData.setRetPeriod(retPeriod);
	}

	/**
	 * Gets the gstr 8 submit data.
	 *
	 * @return the gstr 8 submit data
	 */
	public Gstr8SubmitData getGstr8SubmitData() {
		return gstr8SubmitData;
	}

	/**
	 * Sets the gstr 8 submit data.
	 *
	 * @param gstr8SubmitData
	 *            the new gstr 8 submit data
	 */
	public void setGstr8SubmitData(Gstr8SubmitData gstr8SubmitData) {
		this.gstr8SubmitData = gstr8SubmitData;
	}
}
