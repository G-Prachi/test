package com.mind.egsp.gstn.dto.gstr1A;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Class GetGSTR1ASectionSummary.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetGSTR1ASectionSummary implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The Return Section .
	 */
	@JsonProperty("section_name")
	private String sectionName;

	/**
	 * The Invoice Check sum value .
	 */
	@JsonProperty("checksum")
	private String checksum;

	/**
	 * The Total invoice value .
	 */
	@JsonProperty("ttl_inv")
	private BigDecimal ttlInv;

	/**
	 * The Total Taxible Value .
	 */
	@JsonProperty("ttl_tax")
	private BigDecimal ttlTax;

	/**
	 * The Total IGST .
	 */
	@JsonProperty("ttl_igst")
	private BigDecimal ttlIgst;

	/**
	 * The Total CGST .
	 */
	@JsonProperty("ttl_cgst")
	private BigDecimal ttlCgst;

	/**
	 * The Total SGST .
	 */
	@JsonProperty("ttl_sgst")
	private BigDecimal ttlSgst;

	/** The GSTR 1 A counter party summary. */
	// TODO: Check for correct property name from api documentation
	@JsonProperty("counter party summary")
	private List<GSTR1ACounterPartySummary> GSTR1ACounterPartySummary;

	/**
	 * Gets the Return Section Field Specification: String (Max length:5) Sample
	 * Data: b2b/b2ba/cdn/cdna/at/ata .
	 *
	 * @return the section name
	 */
	public String getSectionName() {
		return sectionName;
	}

	/**
	 * Sets the Return Section Field Specification: String (Max length:5) Sample
	 * Data: b2b/b2ba/cdn/cdna/at/ata .
	 *
	 * @param sectionName
	 *            the new section name
	 */
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	/**
	 * Gets the Invoice Check sum value Field Specification: string(Max
	 * length:15) Sample Data: AflJufPlFStqKBZ .
	 *
	 * @return the checksum
	 */
	public String getChecksum() {
		return checksum;
	}

	/**
	 * Sets the Invoice Check sum value Field Specification: string(Max
	 * length:15) Sample Data: AflJufPlFStqKBZ .
	 *
	 * @param checksum
	 *            the new checksum
	 */
	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}

	/**
	 * Gets the Total invoice value Field Specification: Decimal(p,2) Sample
	 * Data: 1000 .
	 *
	 * @return the ttl inv
	 */
	public BigDecimal getTtlInv() {
		return ttlInv;
	}

	/**
	 * Sets the Total invoice value Field Specification: Decimal(p,2) Sample
	 * Data: 1000 .
	 *
	 * @param ttlInv
	 *            the new ttl inv
	 */
	public void setTtlInv(BigDecimal ttlInv) {
		this.ttlInv = ttlInv;
	}

	/**
	 * Gets the Total Taxible Value Field Specification: Decimal(p,2) Sample
	 * Data: 500 .
	 *
	 * @return the ttl tax
	 */
	public BigDecimal getTtlTax() {
		return ttlTax;
	}

	/**
	 * Sets the Total Taxible Value Field Specification: Decimal(p,2) Sample
	 * Data: 500 .
	 *
	 * @param ttlTax
	 *            the new ttl tax
	 */
	public void setTtlTax(BigDecimal ttlTax) {
		this.ttlTax = ttlTax;
	}

	/**
	 * Gets the Total IGST Field Specification: Decimal(p,2) Sample Data: 100 .
	 *
	 * @return the ttl igst
	 */
	public BigDecimal getTtlIgst() {
		return ttlIgst;
	}

	/**
	 * Sets the Total IGST Field Specification: Decimal(p,2) Sample Data: 100 .
	 *
	 * @param ttlIgst
	 *            the new ttl igst
	 */
	public void setTtlIgst(BigDecimal ttlIgst) {
		this.ttlIgst = ttlIgst;
	}

	/**
	 * Gets the Total CGST Field Specification: Decimal(p,2) Sample Data: 100.9
	 * .
	 *
	 * @return the ttl cgst
	 */
	public BigDecimal getTtlCgst() {
		return ttlCgst;
	}

	/**
	 * Sets the Total CGST Field Specification: Decimal(p,2) Sample Data: 100.9
	 * .
	 *
	 * @param ttlCgst
	 *            the new ttl cgst
	 */
	public void setTtlCgst(BigDecimal ttlCgst) {
		this.ttlCgst = ttlCgst;
	}

	/**
	 * Gets the Total SGST Field Specification: Decimal(p,2) Sample Data: 100.67
	 * .
	 *
	 * @return the ttl sgst
	 */
	public BigDecimal getTtlSgst() {
		return ttlSgst;
	}

	/**
	 * Sets the Total SGST Field Specification: Decimal(p,2) Sample Data: 100.67
	 * .
	 *
	 * @param ttlSgst
	 *            the new ttl sgst
	 */
	public void setTtlSgst(BigDecimal ttlSgst) {
		this.ttlSgst = ttlSgst;
	}

	/**
	 * Gets the GSTR 1 A counter party summary.
	 *
	 * @return the GSTR 1 A counter party summary
	 */
	public List<GSTR1ACounterPartySummary> getGSTR1ACounterPartySummary() {
		return GSTR1ACounterPartySummary;
	}

	/**
	 * Sets the GSTR 1 A counter party summary.
	 *
	 * @param gSTR1ACounterPartySummary
	 *            the new GSTR 1 A counter party summary
	 */
	public void setGSTR1ACounterPartySummary(List<GSTR1ACounterPartySummary> gSTR1ACounterPartySummary) {
		GSTR1ACounterPartySummary = gSTR1ACounterPartySummary;
	}

}
