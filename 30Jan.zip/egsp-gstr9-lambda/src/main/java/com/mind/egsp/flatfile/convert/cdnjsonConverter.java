package com.mind.egsp.flatfile.convert;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mind.egsp.gstn.dto.gstr1.SaveGstr1DTO;
import com.mind.egsp.gstn.dto.gstr2.SaveGstr2DTO;
import com.mind.egsp.gstn.model.gstr1.CdnrInvoice;
import com.mind.egsp.gstn.model.gstr1.CdnrInvoiceDetail;
import com.mind.egsp.gstn.model.gstr1.CdnraInvoice;
import com.mind.egsp.gstn.model.gstr1.*;
import com.mind.egsp.gstn.model.gstr2.*;
import com.mind.egsp.gstn.model.gstr2.Gstr2CdnInvoiceDetail;
import com.mind.egsp.gstn.model.gstr2.Gstr2CdnInvoice;
import com.amazonaws.services.s3.AmazonS3;
import com.egsp.finalDTOs.*;

public class cdnjsonConverter {

//	static List<CdnrInvoiceDetailFlat> flatCdnrDetiallist =  new ArrayList<CdnrInvoiceDetailFlat>();		
//	static List<CdnrInvoiceFlat>  flatCdnrlist = new ArrayList<CdnrInvoiceFlat>();
//	static List<CdnrInvoiceFlatFinal> cdnrInvFlatFinal = new ArrayList<CdnrInvoiceFlatFinal>();
	
	public static String cdnJsonConverter(SaveGstr2DTO gstriObj2,String bucketName,String filePath,String fileName,AmazonS3 s3, String str2)
	{
		//***************************Declaration for Cdnr*************
		try
		{
				List<CdnInvoiceFlat>  flatCdnrlist = new ArrayList<CdnInvoiceFlat>();				
				//byte[] jsonData1 = Files.readAllBytes(Paths.get("B2b-sample.json"));
				//create ObjectMapper instance
				//ObjectMapper objectMapper = new ObjectMapper();
				SaveGstr1DTOFlat savedtoflat  = new SaveGstr1DTOFlat();
				//SaveGstr1DTO gstriObj = objectMapper.readValue(jsonData1, SaveGstr1DTO.class);
				savedtoflat.setFp(gstriObj2.getFp());
				//B2BInvoice================
				List<Gstr2CdnInvoice> list = gstriObj2.getCdnInvoices();
				List<CdnInvoiceDetailFlat> flatCdnrDetiallist = new ArrayList<CdnInvoiceDetailFlat>();
				//System.out.println(list.size() +  "" + list.toString());		
				BigDecimal totaltxval = new BigDecimal(0);
				BigDecimal totaliamt = new BigDecimal(0);;
				BigDecimal totalcamt =new BigDecimal(0);
				BigDecimal totalsamt =new BigDecimal(0);
				BigDecimal totalcsamt = new BigDecimal(0);
				if(list!=null)
				{
				for(Gstr2CdnInvoice item : list)
				{
					//flatCdnrDetiallist = new ArrayList<CdnrInvoiceDetailFlat>();
					CdnInvoiceFlat cdnrflat = new CdnInvoiceFlat();
					cdnrflat.setCtin(item.getCtin());
					for(Gstr2CdnInvoiceDetail invDetail : item.getCdnInvoiceDetails()) {
						CdnInvoiceDetailFlat cdnrInvoiceDetailFLat = new CdnInvoiceDetailFlat();
						cdnrInvoiceDetailFLat.setInum(invDetail.getInum());
						cdnrflat.setVal(invDetail.getVal());
						cdnrInvoiceDetailFLat.setIdt(invDetail.getIdt());						
						cdnrInvoiceDetailFLat.setNtNum(invDetail.getNtNum());
						cdnrInvoiceDetailFLat.setNtDt(invDetail.getNtDt());
						cdnrInvoiceDetailFLat.setNtty(invDetail.getNtty());					
						
						for (CDNRItem item1 :invDetail.getCdnrItems()){
							if(item1.getCdnrItemDetails().getTxval()!=null)
							totaltxval = totaltxval.add(item1.getCdnrItemDetails().getTxval());
							if(item1.getCdnrItemDetails().getIamt()!=null)
							totaliamt = totaliamt.add(item1.getCdnrItemDetails().getIamt());
							if(item1.getCdnrItemDetails().getCamt()!=null)
							totalcamt = totalcamt.add(item1.getCdnrItemDetails().getCamt());
							if(item1.getCdnrItemDetails().getSamt()!=null)
							totalsamt = totalsamt.add(item1.getCdnrItemDetails().getSamt());
							if(item1.getCdnrItemDetails().getCsamt()!=null)
							totalcsamt = totalcsamt.add(item1.getCdnrItemDetails().getCsamt());							
						    }
							cdnrInvoiceDetailFLat.setTotaltxval(totaltxval);
							cdnrInvoiceDetailFLat.setTotaliamt(totaliamt);
							cdnrInvoiceDetailFLat.setTotalcamt(totalcamt);
							cdnrInvoiceDetailFLat.setTotalcsamt(totalcsamt);
							cdnrInvoiceDetailFLat.setTotalsamt(totalsamt);
							flatCdnrDetiallist.add(cdnrInvoiceDetailFLat);
					}
					cdnrflat.setCdnInvoiceDetailFLat(flatCdnrDetiallist);
					flatCdnrlist.add(cdnrflat);
				}
//				System.out.println("flatCdnrlist "+flatCdnrlist);
					List<CdnInvoiceFlatFinal> cdnrfinalList = new ArrayList<CdnInvoiceFlatFinal>();
					for(CdnInvoiceFlat flatList : flatCdnrlist)
					{
						for(CdnInvoiceDetailFlat cdnrInvoiceFlat : flatList.getCdnInvoiceDetailFLat()) {
							CdnInvoiceFlatFinal cdnrInvoiceFlatFinal = new CdnInvoiceFlatFinal();
							cdnrInvoiceFlatFinal.setFp(gstriObj2.getFp());
							cdnrInvoiceFlatFinal.setBusinessType("cdn");
							cdnrInvoiceFlatFinal.setCtin(flatList.getCtin());
							
							//cdnrInvoiceFlatFinal.setRchrg(flatList.getRchrg());
							//cdnrInvoiceFlatFinal.setInvTyp(flatList.getInvTyp());
							//------------------***--------------------------
							cdnrInvoiceFlatFinal.setVal(flatList.getVal());
							cdnrInvoiceFlatFinal.setInum(cdnrInvoiceFlat.getInum());
							cdnrInvoiceFlatFinal.setIdt(cdnrInvoiceFlat.getIdt());
							cdnrInvoiceFlatFinal.setNtDt(cdnrInvoiceFlat.getNtDt());
							cdnrInvoiceFlatFinal.setNtNum(cdnrInvoiceFlat.getNtNum());
							cdnrInvoiceFlatFinal.setNtty(cdnrInvoiceFlat.getNtty());
							cdnrInvoiceFlatFinal.setTotalcamt(cdnrInvoiceFlat.getTotalcamt());
							cdnrInvoiceFlatFinal.setTotalcsamt(cdnrInvoiceFlat.getTotalcsamt());
							cdnrInvoiceFlatFinal.setTotaliamt(cdnrInvoiceFlat.getTotaliamt());
							cdnrInvoiceFlatFinal.setTotalsamt(cdnrInvoiceFlat.getTotalsamt());
							cdnrInvoiceFlatFinal.setTotaltxval(cdnrInvoiceFlat.getTotaltxval());
							cdnrfinalList.add(cdnrInvoiceFlatFinal);
						}
					}
					
				final ByteArrayOutputStream out = new ByteArrayOutputStream();
			    final ObjectMapper mapper = new ObjectMapper();
			    
			    mapper.writeValue(out, cdnrfinalList);
		        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		        StringBuilder tempFile = new StringBuilder();
		        Random rnd = new Random();
		        while (tempFile.length() < 18) { // length of the random string.
		            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
		            tempFile.append(SALTCHARS.charAt(index));
		        }
		        String tempFil = tempFile.toString();
		        File tempFileName = new File(tempFil+".json");
		        //return saltStr;
				mapper.writeValue(tempFileName, cdnrfinalList);
				InputStream is = new FileInputStream(tempFileName);
				String contents = new BufferedReader(new InputStreamReader(is)).readLine();
				is.close(); 
				
					String str = contents.substring(1, contents.length()-1);
					String str1=str.replaceAll("},", "}\n");
					System.out.println(str1);
					str2= str2.concat(str1);
					return(str2);
					/*PrintWriter pr = new PrintWriter(new BufferedWriter(new FileWriter(new File(fileName), true)));
					pr.write(str1);
					pr.append("\n");
					pr.close();
					s3.putObject(bucketName, filePath+"/"+fileName, str1);
					System.out.println("sucess");*/
			    
			   
				}
		}
				catch(Exception ex)
				{
					
				}
			    return (str2);
	}
}
		
	





