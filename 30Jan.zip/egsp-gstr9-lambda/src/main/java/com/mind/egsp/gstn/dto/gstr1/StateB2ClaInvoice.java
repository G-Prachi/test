package com.mind.egsp.gstn.dto.gstr1;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.model.gstr1.B2claInvoiceDetail;

/**
 * The Class StateB2ClaInvoices.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class StateB2ClaInvoice implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Recipient state code. */
	
	private String ctin;

	private String pos;

	/** The B2clInvoice Details of . */
	@JsonProperty("inv")
	private List<B2claInvoiceDetail> b2claInvoiceDetails;

	/**
	 * Gets the Place of Supply.
	 * 
	 * Sample Data: 04
	 *
	 * @return the pos
	 */
	public String getPos() {
		return pos;
	}
	
	/**
	 * Gets the ctin.
	 *
	 * @return the ctin
	 */
	public String getCtin() {
		return ctin;
	}
	
	/**
	 * Sets the Place of Supply.
	 * 
	 * Sample Data: 04
	 *
	 * @param stateCd
	 *            the pos
	 */
	public void setPos(String pos) {
		this.pos = pos;
	}

	/**
	 * Gets the b 2 cla invoice details.
	 *
	 * @return the b 2 cla invoice details
	 */
	public List<B2claInvoiceDetail> getB2claInvoiceDetails() {
		return b2claInvoiceDetails;
	}

	/**
	 * Sets the b 2 cla invoice details.
	 *
	 * @param b2claInvoiceDetails
	 *            the new b 2 cla invoice details
	 */
	public void setB2claInvoiceDetails(List<B2claInvoiceDetail> b2claInvoiceDetails) {
		this.b2claInvoiceDetails = b2claInvoiceDetails;
	}

}
