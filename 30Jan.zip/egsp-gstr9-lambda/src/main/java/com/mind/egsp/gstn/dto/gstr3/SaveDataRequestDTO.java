package com.mind.egsp.gstn.dto.gstr3;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseRequestDTO;
import com.mind.egsp.gstn.model.gstr3.RefundClaimForSaveGstr3;

/**
 * The Class SaveGSTR3DataRequestDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class SaveDataRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The refund claim for save gstr 3. */
	@JsonProperty("data")
	private RefundClaimForSaveGstr3 refundClaimForSaveGstr3;

	/**
	 * Instantiates a new save GSTR 3 data request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param gstin
	 *            the gstin
	 * @param retPeriod
	 *            the ret period
	 * @param username
	 *            the username
	 */
	public SaveDataRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	/**
	 * Gets the refund claim for save gstr 3.
	 *
	 * @return the refund claim for save gstr 3
	 */
	public RefundClaimForSaveGstr3 getRefundClaimForSaveGstr3() {
		return refundClaimForSaveGstr3;
	}

	/**
	 * Sets the refund claim for save gstr 3.
	 *
	 * @param refundClaimForSaveGstr3
	 *            the new refund claim for save gstr 3
	 */
	public void setRefundClaimForSaveGstr3(RefundClaimForSaveGstr3 refundClaimForSaveGstr3) {
		this.refundClaimForSaveGstr3 = refundClaimForSaveGstr3;
	}

}
