package com.mind.egsp.gstn.dto.publicapi;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mind.egsp.gstn.dto.auth.AuthBaseRequestDTO;

/**
 * The Class AuthGetCommonTokenRequestDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetPublicCommonAuthTokenRequestDTO extends AuthBaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	private String password;

	/**
	 * Instantiates a new auth get common token request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param appKey
	 *            the app key
	 * @param username
	 *            the username
	 * @param password
	 *            the password
	 */

	public GetPublicCommonAuthTokenRequestDTO(String appKey, String username, String password) {
		super(appKey, username);
		this.password = password;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
