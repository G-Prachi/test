package com.mind.egsp.gstn.dto.gstr2;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr2.ItcReceived;

// TODO: Auto-generated Javadoc
/**
 * The Class GetItcReceivedResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetItcReceivedResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The itc received. */
	@JsonProperty("itc_rcd")
	private List<ItcReceived> itcReceiveds;

	/**
	 * Gets the itc receiveds.
	 *
	 * @return the itc receiveds
	 */
	public List<ItcReceived> getItcReceiveds() {
		return itcReceiveds;
	}

	/**
	 * Sets the itc receiveds.
	 *
	 * @param itcReceiveds
	 *            the new itc receiveds
	 */
	public void setItcReceiveds(List<ItcReceived> itcReceiveds) {
		this.itcReceiveds = itcReceiveds;
	}

}
