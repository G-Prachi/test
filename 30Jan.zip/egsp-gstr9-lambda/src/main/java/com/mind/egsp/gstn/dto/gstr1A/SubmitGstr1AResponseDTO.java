package com.mind.egsp.gstn.dto.gstr1A;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SubmitGstr1AResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The Reference Id .
	 */
	@JsonProperty("ref_id")
	private String refId;

	/**
	 * The Transaction Id .
	 */
	@JsonProperty("txn_id")
	private String txnId;

	/**
	 * Gets the Reference Id Field Specification: Alphanumeric 15 characters
	 * Sample Data: LAPN24235325555 .
	 *
	 * @return the ref id
	 */
	public String getRefId() {
		return refId;
	}

	/**
	 * Sets the Reference Id Field Specification: Alphanumeric 15 characters
	 * Sample Data: LAPN24235325555 .
	 *
	 * @param refId
	 *            the new ref id
	 */
	public void setRefId(String refId) {
		this.refId = refId;
	}

	/**
	 * Gets the Reference Id Field Specification: Alphanumeric 15 characters
	 * Sample Data: LAPN24235325555 .
	 *
	 * @return the txn id
	 */
	public String getTxnId() {
		return txnId;
	}

	/**
	 * Sets the Reference Id Field Specification: Alphanumeric 15 characters
	 * Sample Data: LAPN24235325555 .
	 *
	 * @param txnId
	 *            the new txn id
	 */
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

}
