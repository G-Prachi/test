package com.mind.egsp.gstn.dto.auth;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

// TODO: Auto-generated Javadoc
/**
 * The Class EVCGetOTPRequestDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class EVCGetOTPRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The pan. */
	@JsonIgnore
	private String pan;

	/** The from type. */
	@JsonIgnore
	private String fromType;

	/**
	 * Instantiates a new EVC get OTP request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param gstin
	 *            the gstin
	 * @param retPeriod
	 *            the ret period
	 * @param username
	 *            the username
	 */
	public EVCGetOTPRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	/**
	 * Gets the pan.
	 *
	 * @return the pan
	 */
	public String getPan() {
		return pan;
	}

	/**
	 * Sets the pan.
	 *
	 * @param pan
	 *            the new pan
	 */
	public void setPan(String pan) {
		this.pan = pan;
	}

	/**
	 * Gets the from type.
	 *
	 * @return the from type
	 */
	public String getFromType() {
		return fromType;
	}

	/**
	 * Sets the from type.
	 *
	 * @param fromType
	 *            the new from type
	 */
	public void setFromType(String fromType) {
		this.fromType = fromType;
	}


}
