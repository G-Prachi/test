package com.mind.egsp.gstn.dto.publicapi;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;


/**
 * The Class GetCashLedgerDetailsResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class GetPublicSearchTaxpayerDetailsResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The search taxpayer response DTO. */
	@JsonProperty("searchTaxpayer")
	GetPublicSearchTaxpayerResponseDTO searchTaxpayerResponseDTO;

	/**
	 * Gets the search taxpayer response DTO.
	 *
	 * @return the search taxpayer response DTO
	 */
	public GetPublicSearchTaxpayerResponseDTO getSearchTaxpayerResponseDTO() {
		return searchTaxpayerResponseDTO;
	}

	/**
	 * Sets the search taxpayer response DTO.
	 *
	 * @param searchTaxpayerResponseDTO
	 *            the new search taxpayer response DTO
	 */
	public void setSearchTaxpayerResponseDTO(GetPublicSearchTaxpayerResponseDTO searchTaxpayerResponseDTO) {
		this.searchTaxpayerResponseDTO = searchTaxpayerResponseDTO;
	}

}
