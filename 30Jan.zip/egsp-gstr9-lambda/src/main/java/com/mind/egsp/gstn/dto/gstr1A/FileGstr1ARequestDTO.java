package com.mind.egsp.gstn.dto.gstr1A;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

// TODO: Auto-generated Javadoc
/**
 * The Class GSTR1AFileGstr1ARequestDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class FileGstr1ARequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The GSTR Summary .
	 */
	@JsonProperty("data")
	private Gstr1ASummaryData gstr1ASummaryData;

	/**
	 * The PKCS#7 signature of SHA-256 hash of Base64 of Request payload JSON
	 * using private key of Tax Payer (Authorized signatory) .
	 */
	private String sign;

	/**
	 * The Type of signature – DSC or ESIGN .
	 */
	private String st;

	/**
	 * The PAN of authorized representative if st = DSC or AADHAR no. of
	 * authorized representative if st=ESIGN .
	 */
	private String sid;

	/**
	 * Instantiates a new file gstr 1 A request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param gstin
	 *            the gstin
	 * @param retPeriod
	 *            the ret period
	 * @param username
	 *            the username
	 */
	public FileGstr1ARequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	/**
	 * Gets the PKCS#7 signature of SHA-256 hash of Base64 of Request payload
	 * JSON using private key of Tax Payer (Authorized signatory) Field
	 * Specification: Sample Data: .
	 *
	 * @return the sign
	 */
	public String getSign() {
		return sign;
	}

	/**
	 * Sets the PKCS#7 signature of SHA-256 hash of Base64 of Request payload
	 * JSON using private key of Tax Payer (Authorized signatory) Field
	 * Specification: Sample Data: .
	 *
	 * @param sign
	 *            the new sign
	 */
	public void setSign(String sign) {
		this.sign = sign;
	}

	/**
	 * Gets the Type of signature – DSC or ESIGN Field Specification: String
	 * (Maxlength:5) Sample Data: DSC/ESIGN .
	 *
	 * @return the st
	 */
	public String getSt() {
		return st;
	}

	/**
	 * Sets the Type of signature – DSC or ESIGN Field Specification: String
	 * (Maxlength:5) Sample Data: DSC/ESIGN .
	 *
	 * @param st
	 *            the new st
	 */
	public void setSt(String st) {
		this.st = st;
	}

	/**
	 * Gets the PAN of authorized representative if st = DSC or AADHAR no. of
	 * authorized representative if st=ESIGN Field Specification: Alphanumeric
	 * (Max Length:15) Sample Data: .
	 *
	 * @return the sid
	 */
	public String getSid() {
		return sid;
	}

	/**
	 * Sets the PAN of authorized representative if st = DSC or AADHAR no. of
	 * authorized representative if st=ESIGN Field Specification: Alphanumeric
	 * (Max Length:15) Sample Data: .
	 *
	 * @param sid
	 *            the new sid
	 */
	public void setSid(String sid) {
		this.sid = sid;
	}

	/**
	 * Gets the gstr 1 A summary data.
	 *
	 * @return the gstr 1 A summary data
	 */
	public Gstr1ASummaryData getGstr1ASummaryData() {
		return gstr1ASummaryData;
	}

	/**
	 * Sets the gstr 1 A summary data.
	 *
	 * @param gstr1aSummaryData
	 *            the new gstr 1 A summary data
	 */
	public void setGstr1ASummaryData(Gstr1ASummaryData gstr1aSummaryData) {
		gstr1ASummaryData = gstr1aSummaryData;
	}

}
