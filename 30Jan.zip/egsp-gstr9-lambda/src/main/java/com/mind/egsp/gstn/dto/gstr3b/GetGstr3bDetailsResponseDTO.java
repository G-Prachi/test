package com.mind.egsp.gstn.dto.gstr3b;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;

/**
 * * Get GSTR3B Detail Response DTO.
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class GetGstr3bDetailsResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The GSTR3B Detail. */
	@JsonProperty("gstr3b")
	private Gstr3bDetailDTO gstr3bDetailDTO;

	/**
	 * Gets the gstr 3 b detail DTO.
	 *
	 * @return the gstr 3 b detail DTO
	 */
	public Gstr3bDetailDTO getGstr3bDetailDTO() {
		return gstr3bDetailDTO;
	}

	/**
	 * Sets the gstr 3 b detail DTO.
	 *
	 * @param gstr3bDetailDTO
	 *            the new gstr 3 b detail DTO
	 */
	public void setGstr3bDetailDTO(Gstr3bDetailDTO gstr3bDetailDTO) {
		this.gstr3bDetailDTO = gstr3bDetailDTO;
	}

}
