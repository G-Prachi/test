package com.mind.egsp.gstn.dto.all;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseResponseDTO;
import com.mind.egsp.gstn.model.all.InvoiceDetails;

// TODO: Auto-generated Javadoc
/**
 * The Class GetAdvanceTaxPaidDetailsResponseDTO.
 */
public class GetAdvanceTaxPaidDetailsResponseDTO extends BaseResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The GSTIN of the receiver .
	 */
	private String gstin;

	/**
	 * The Document number .
	 */
	@JsonProperty("doc_num")
	private String docNum;

	/** The invoice details. */

	@JsonProperty("inv")
	private List<InvoiceDetails> invoiceDetails;

	/**
	 * Gets the GSTIN of the receiver Field Specification: Alphanumeric with 15
	 * characters Sample Data: 29HJKPS9689A8Z4 .
	 *
	 * @return the gstin
	 */
	public String getGstin() {
		return gstin;
	}

	/**
	 * Sets the GSTIN of the receiver Field Specification: Alphanumeric with 15
	 * characters Sample Data: 29HJKPS9689A8Z4 .
	 *
	 * @param gstin
	 *            the new gstin
	 */
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the Document number Field Specification: Alphanumeric (Max length:50
	 * Sample Data: B024434 .
	 *
	 * @return the doc num
	 */
	public String getDocNum() {
		return docNum;
	}

	/**
	 * Sets the Document number Field Specification: Alphanumeric (Max length:50
	 * Sample Data: B024434 .
	 *
	 * @param docNum
	 *            the new doc num
	 */
	public void setDocNum(String docNum) {
		this.docNum = docNum;
	}

	/**
	 * Gets the invoice details.
	 *
	 * @return the invoice details
	 */
	public List<InvoiceDetails> getInvoiceDetails() {
		return invoiceDetails;
	}

	/**
	 * Sets the invoice details.
	 *
	 * @param invoiceDetails
	 *            the new invoice details
	 */
	public void setInvoiceDetails(List<InvoiceDetails> invoiceDetails) {
		this.invoiceDetails = invoiceDetails;
	}

}
