package com.mind.egsp.gstn.ledger;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.model.all.GstrRetStatusData;
import com.mind.egsp.gstn.model.ledger.ClosingBalTaxLedger;
import com.mind.egsp.gstn.model.ledger.OpeningBalTaxLedger;
import com.mind.egsp.gstn.model.ledger.TransactionTaxLedger;

// TODO: Auto-generated Javadoc
/**
 * The Class CashLedgerDetailsData.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class CashLedgerDetailsData {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The ret status data. */
	@JsonIgnore
	private GstrRetStatusData retStatusData;

	/** The GSTIN of the Taxpayer. */
	private String gstin;

	/** The From Date. */
	@JsonProperty("fr_dt")
	private String frDt;

	/** The To Date. */
	@JsonProperty("to_dt")
	private String toDt;

	/** The Opening Balance. */
	@JsonProperty("op_bal")
	private OpeningBalTaxLedger opBal;

	/** The Transactions. */
	@JsonProperty("tr")
	private List<TransactionTaxLedger> trList;

	/** The Closing Balance. */
	@JsonProperty("cl_bal")
	private ClosingBalTaxLedger clBal;

	private String status;
	/**
	 * Gets the GSTIN of the Tax Payer.
	 *
	 * @return the GSTIN of the Tax Payer
	 */
	public String getGstin() {
		return gstin;
	}

	/**
	 * Sets the GSTIN of the Tax Payer.
	 *
	 * @param gstin
	 *            the new GSTIN of the Tax Payer
	 */
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the From Date.
	 *
	 * @return the From Date
	 */
	public String getFrDt() {
		return frDt;
	}

	/**
	 * Sets the From Date.
	 *
	 * @param frDt
	 *            the new From Date
	 */
	public void setFrDt(String frDt) {
		this.frDt = frDt;
	}

	/**
	 * Gets the To Date.
	 *
	 * @return the To Date
	 */
	public String getToDt() {
		return toDt;
	}

	/**
	 * Sets the To Date.
	 *
	 * @param toDt
	 *            the new To Date
	 */
	public void setToDt(String toDt) {
		this.toDt = toDt;
	}

	/**
	 * Gets the Opening Balance.
	 *
	 * @return the Opening Balance
	 */
	public OpeningBalTaxLedger getOpBal() {
		return opBal;
	}

	/**
	 * Sets the Opening Balance.
	 *
	 * @param opBal
	 *            the new Opening Balance
	 */
	public void setOpBal(OpeningBalTaxLedger opBal) {
		this.opBal = opBal;
	}

	public List<TransactionTaxLedger> getTrList() {
		return trList;
	}

	public void setTrList(List<TransactionTaxLedger> trList) {
		this.trList = trList;
	}

	/**
	 * Gets the Closing Balance.
	 *
	 * @return the Closing Balance
	 */
	public ClosingBalTaxLedger getClBal() {
		return clBal;
	}

	/**
	 * Sets the Closing Balance.
	 *
	 * @param clBal
	 *            the new Closing Balance
	 */
	public void setClBal(ClosingBalTaxLedger clBal) {
		this.clBal = clBal;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
