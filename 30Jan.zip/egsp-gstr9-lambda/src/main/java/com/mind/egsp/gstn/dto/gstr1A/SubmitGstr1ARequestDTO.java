package com.mind.egsp.gstn.dto.gstr1A;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseRequestDTO;
import com.mind.egsp.gstn.model.gstr1.GstrSubmitData;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class SubmitGstr1ARequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The gstr 1 A submit data. */
	@JsonProperty("data")
	private GstrSubmitData gstrSubmitData = new GstrSubmitData();


	public SubmitGstr1ARequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
		this.gstrSubmitData.setGstin(gstin);
		this.gstrSubmitData.setRetPeriod(retPeriod);
	}

	/**
	 * Gets the gstr submit data.
	 *
	 * @return the gstr submit data
	 */
	public GstrSubmitData getGstrSubmitData() {
		return gstrSubmitData;
	}

	/**
	 * Sets the gstr submit data.
	 *
	 * @param gstr1SubmitData
	 *            the new gstr submit data
	 */
	public void setGstrSubmitData(GstrSubmitData gstrSubmitData) {
		this.gstrSubmitData = gstrSubmitData;
	}

}
