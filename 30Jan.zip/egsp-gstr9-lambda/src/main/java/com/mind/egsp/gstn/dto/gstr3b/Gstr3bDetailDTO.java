package com.mind.egsp.gstn.dto.gstr3b;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.model.gstr3b.Gstr3bEligibleItc;
import com.mind.egsp.gstn.model.gstr3b.Gstr3bInOutSupplyDetail;
import com.mind.egsp.gstn.model.gstr3b.Gstr3bInterSupply;
import com.mind.egsp.gstn.model.gstr3b.Gstr3bIntrLateFeePayable;
import com.mind.egsp.gstn.model.gstr3b.Gstr3bInwardSupply;
import com.mind.egsp.gstn.model.gstr3b.Gstr3bTaxPayment;


/**
 * The Class Gstr3bSaveDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class Gstr3bDetailDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** Supplier GSTIN. */
	private String gstin;

	/** Supplier Invoice Date. */
	@JsonProperty("ret_period")
	private String retPeriod;

	/** Details of Outward Supplies and inward supplies liable to reverse charge. */
	@JsonProperty("sup_details")
	private Gstr3bInOutSupplyDetail inOutSupplyDetail;

	/**
	 * Details of inter-State supplies made to unregistered persons, composition
	 * taxable persons and UIN holders.
	 */
	@JsonProperty("inter_sup")
	private Gstr3bInterSupply interSupply;

	/** Eligible ITC. */
	@JsonProperty("itc_elg")
	private Gstr3bEligibleItc eligibleItc;

	/** Values of exempt, nil-rated and non-GST inward supplies. */
	@JsonProperty("inward_sup")
	private Gstr3bInwardSupply gstr3bInwardSupply;

	/** Interest & late fee payable. */
	@JsonProperty("intr_ltfee")
	private Gstr3bIntrLateFeePayable intrLateFeeDetail;

	/** Payment of tax. */
	@JsonProperty("tx_pmt")
	private Gstr3bTaxPayment taxPmt;

	/**
	 * Gets the gstin.
	 *
	 * @return the gstin
	 */
	public String getGstin() {
		return gstin;
	}

	/**
	 * Sets the gstin.
	 *
	 * @param gstin
	 *            the new gstin
	 */
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the ret period.
	 *
	 * @return the ret period
	 */
	public String getRetPeriod() {
		return retPeriod;
	}

	/**
	 * Sets the ret period.
	 *
	 * @param retPeriod
	 *            the new ret period
	 */
	public void setRetPeriod(String retPeriod) {
		this.retPeriod = retPeriod;
	}

	/**
	 * Gets the in out supply detail.
	 *
	 * @return the in out supply detail
	 */
	public Gstr3bInOutSupplyDetail getInOutSupplyDetail() {
		return inOutSupplyDetail;
	}

	/**
	 * Sets the in out supply detail.
	 *
	 * @param inOutSupplyDetail
	 *            the new in out supply detail
	 */
	public void setInOutSupplyDetail(Gstr3bInOutSupplyDetail inOutSupplyDetail) {
		this.inOutSupplyDetail = inOutSupplyDetail;
	}

	/**
	 * Gets the inter supply.
	 *
	 * @return the inter supply
	 */
	public Gstr3bInterSupply getInterSupply() {
		return interSupply;
	}

	/**
	 * Sets the inter supply.
	 *
	 * @param interSupply
	 *            the new inter supply
	 */
	public void setInterSupply(Gstr3bInterSupply interSupply) {
		this.interSupply = interSupply;
	}

	/**
	 * Gets the eligible itc.
	 *
	 * @return the eligible itc
	 */
	public Gstr3bEligibleItc getEligibleItc() {
		return eligibleItc;
	}

	/**
	 * Sets the eligible itc.
	 *
	 * @param eligibleItc
	 *            the new eligible itc
	 */
	public void setEligibleItc(Gstr3bEligibleItc eligibleItc) {
		this.eligibleItc = eligibleItc;
	}

	/**
	 * Gets the gstr 3 b inward supply.
	 *
	 * @return the gstr 3 b inward supply
	 */
	public Gstr3bInwardSupply getGstr3bInwardSupply() {
		return gstr3bInwardSupply;
	}

	/**
	 * Sets the gstr 3 b inward supply.
	 *
	 * @param gstr3bInwardSupply
	 *            the new gstr 3 b inward supply
	 */
	public void setGstr3bInwardSupply(Gstr3bInwardSupply gstr3bInwardSupply) {
		this.gstr3bInwardSupply = gstr3bInwardSupply;
	}

	/**
	 * Gets the intr late fee detail.
	 *
	 * @return the intr late fee detail
	 */
	public Gstr3bIntrLateFeePayable getIntrLateFeeDetail() {
		return intrLateFeeDetail;
	}

	/**
	 * Sets the intr late fee detail.
	 *
	 * @param intrLateFeeDetail
	 *            the new intr late fee detail
	 */
	public void setIntrLateFeeDetail(Gstr3bIntrLateFeePayable intrLateFeeDetail) {
		this.intrLateFeeDetail = intrLateFeeDetail;
	}

	/**
	 * Gets the tax pmt.
	 *
	 * @return the tax pmt
	 */
	public Gstr3bTaxPayment getTaxPmt() {
		return taxPmt;
	}

	/**
	 * Sets the tax pmt.
	 *
	 * @param taxPmt
	 *            the new tax pmt
	 */
	public void setTaxPmt(Gstr3bTaxPayment taxPmt) {
		this.taxPmt = taxPmt;
	}

}
