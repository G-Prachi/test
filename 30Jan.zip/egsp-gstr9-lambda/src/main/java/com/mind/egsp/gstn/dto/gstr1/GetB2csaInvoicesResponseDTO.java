package com.mind.egsp.gstn.dto.gstr1;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr1.B2csaInvoice;

// TODO: Auto-generated Javadoc
/**
 * The Class GetB2csaInvoicesResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetB2csaInvoicesResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The B2CSA invoice detail. */
	@JsonProperty("b2csa")
	private List<B2csaInvoice> b2csaInvoices;

	/**
	 * Gets the B2CSA invoices.
	 *
	 * @return the B2CSA invoices
	 */
	public List<B2csaInvoice> getB2csaInvoices() {
		return b2csaInvoices;
	}

	/**
	 * Sets the B2CSA invoices.
	 *
	 * @param b2csaInvoices
	 *            the new B2CSA invoices
	 */
	public void setB2csaInvoices(List<B2csaInvoice> b2csaInvoices) {
		this.b2csaInvoices = b2csaInvoices;
	}

}
