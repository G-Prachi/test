package com.mind.egsp.gstn.model.gstr1;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * The Class for HSN/SAC summary of outward supplies.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class HsnSummary implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The tax payer action. */
	private Character flag;

	/** Invoice Check sum value. */
	private String chksum;

	/** The HsnSummary Detail. */
	@JsonProperty("data")
	private List<HsnSummaryDetail> hsnSummaryDetails;

	/**
	 * Gets the flag.
	 *
	 * @return the flag
	 */
	public Character getFlag() {
		return flag;
	}

	/**
	 * Sets the flag.
	 *
	 * @param flag
	 *            the new flag
	 */
	public void setFlag(Character flag) {
		this.flag = flag;
	}

	/**
	 * Gets the hsn summary details.
	 *
	 * @return the hsn summary details
	 */
	public List<HsnSummaryDetail> getHsnSummaryDetails() {
		return hsnSummaryDetails;
	}

	/**
	 * Sets the hsn summary details.
	 *
	 * @param hsnSummaryDetails
	 *            the new hsn summary details
	 */
	public void setHsnSummaryDetails(List<HsnSummaryDetail> hsnSummaryDetails) {
		this.hsnSummaryDetails = hsnSummaryDetails;
	}

	/**
	 * Gets the chksum.
	 *
	 * @return the chksum
	 */
	public String getChksum() {
		return chksum;
	}

	/**
	 * Sets the chksum.
	 *
	 * @param chksum
	 *            the new chksum
	 */
	public void setChksum(String chksum) {
		this.chksum = chksum;
	}

}
