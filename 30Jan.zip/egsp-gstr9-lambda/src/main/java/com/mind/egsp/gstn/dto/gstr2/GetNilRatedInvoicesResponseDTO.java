package com.mind.egsp.gstn.dto.gstr2;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr2.Gstr2NilSupply;

// TODO: Auto-generated Javadoc
/**
 * The Class GetNilRatedInvoicesResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetNilRatedInvoicesResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The nil rated data list. */
	@JsonProperty("nil_supplies")
	private List<Gstr2NilSupply> gstr2NilSupplies;

	/**
	 * Gets the gstr 2 nil supplies.
	 *
	 * @return the gstr 2 nil supplies
	 */
	public List<Gstr2NilSupply> getGstr2NilSupplies() {
		return gstr2NilSupplies;
	}

	/**
	 * Sets the gstr 2 nil supplies.
	 *
	 * @param gstr2NilSupplies
	 *            the new gstr 2 nil supplies
	 */
	public void setGstr2NilSupplies(List<Gstr2NilSupply> gstr2NilSupplies) {
		this.gstr2NilSupplies = gstr2NilSupplies;
	}

}
