package com.mind.egsp.gstn.dto.gstr3;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseRequestDTO;
import com.mind.egsp.gstn.model.gstr3.GSTRSummary;

/**
 * The Class FileGSTR3RequestDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class FileRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The GSTR Summary .
	 */
	@JsonProperty("data")
	private GSTRSummary gstrSummary;

	/**
	 * The PKCS#7 signature of SHA-256 hash of Base64 of Request payload JSON
	 * using private key of Tax Payer (Authorized signatory) .
	 */
	private String sign;

	/**
	 * The Type of signature – DSC or ESIGN .
	 */
	private String st;

	/**
	 * The PAN of authorized representative if st = DSC or AADHAR no. of
	 * authorized representative if st=ESIGN .
	 */
	private String sid;

	public FileRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	/**
	 * Gets the GSTR Summary Field Specification: Get GSTR Summary Sample Data:
	 * .
	 *
	 * @return the gstr summary
	 */
	public GSTRSummary getGstrSummary() {
		return gstrSummary;
	}

	/**
	 * Sets the Gets the GSTR Summary Field Specification: Get GSTR Summary
	 * Sample Data: .
	 *
	 * @param gstrSummary
	 *            the new gstr summary
	 */
	public void setGstrSummary(GSTRSummary gstrSummary) {
		this.gstrSummary = gstrSummary;
	}

	/**
	 * Gets the PKCS#7 signature of SHA-256 hash of Base64 of Request payload
	 * JSON using private key of Tax Payer (Authorized signatory) Field
	 * Specification: Sample Data: .
	 *
	 * @return the sign
	 */
	public String getSign() {
		return sign;
	}

	/**
	 * Sets the PKCS#7 signature of SHA-256 hash of Base64 of Request payload
	 * JSON using private key of Tax Payer (Authorized signatory) Field
	 * Specification: Sample Data: .
	 *
	 * @param sign
	 *            the new sign
	 */
	public void setSign(String sign) {
		this.sign = sign;
	}

	/**
	 * Gets the Type of signature – DSC or ESIGN Field Specification: String
	 * (Maxlength:5) Sample Data: DSC/ESIGN .
	 *
	 * @return the st
	 */
	public String getSt() {
		return st;
	}

	/**
	 * Sets the Type of signature – DSC or ESIGN Field Specification: String
	 * (Maxlength:5) Sample Data: DSC/ESIGN .
	 *
	 * @param st
	 *            the new st
	 */
	public void setSt(String st) {
		this.st = st;
	}

	/**
	 * Gets the PAN of authorized representative if st = DSC or AADHAR no. of
	 * authorized representative if st=ESIGN Field Specification: Alphanumeric
	 * (Max Length:15) Sample Data: .
	 *
	 * @return the sid
	 */
	public String getSid() {
		return sid;
	}

	/**
	 * Sets the PAN of authorized representative if st = DSC or AADHAR no. of
	 * authorized representative if st=ESIGN Field Specification: Alphanumeric
	 * (Max Length:15) Sample Data: .
	 *
	 * @param sid
	 *            the new sid
	 */
	public void setSid(String sid) {
		this.sid = sid;
	}

}
