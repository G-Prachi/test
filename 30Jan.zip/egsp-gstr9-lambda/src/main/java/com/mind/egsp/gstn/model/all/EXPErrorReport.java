package com.mind.egsp.gstn.model.all;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.model.gstr1.ExpInvoiceDetail;

/**
 * The Class EXPErrorReport.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class EXPErrorReport implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The CDNR Invoice. */
	@JsonProperty("inv")
	private List<ExpInvoiceDetail> expInvoiceDetails;

	/**
	 * The Error_cd .
	 */
	@JsonProperty("error_cd")
	private String errorCd;

	/**
	 * The Error Message .
	 */
	@JsonProperty("error_msg")
	private String errorMsg;

	/**
	 * The Export Type .
	 */
	@JsonProperty("exp_typ")
	private String expTyp;

	/**
	 * Gets the Error_cd Field Specification: Alphanumeric (Max length:10) Sample
	 * Data: RET100 .
	 *
	 * @return the error cd
	 */
	public String getErrorCd() {
		return errorCd;
	}

	/**
	 * Sets the Error_cd Field Specification: Alphanumeric (Max length:10) Sample
	 * Data: RET100 .
	 *
	 * @param errorCd
	 *            the new error cd
	 */
	public void setErrorCd(String errorCd) {
		this.errorCd = errorCd;
	}

	/**
	 * Gets the Error Message Field Specification: Alphanumeric (Max length:100)
	 * Sample Data: Duplicate Invoice .
	 *
	 * @return the error msg
	 */
	public String getErrorMsg() {
		return errorMsg;
	}

	/**
	 * Sets the Error Message Field Specification: Alphanumeric (Max length:100)
	 * Sample Data: Duplicate Invoice .
	 *
	 * @param errorMsg
	 *            the new error msg
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	/**
	 * Gets the exp invoice details.
	 *
	 * @return the exp invoice details
	 */
	public List<ExpInvoiceDetail> getExpInvoiceDetails() {
		return expInvoiceDetails;
	}

	/**
	 * Sets the exp invoice details.
	 *
	 * @param expInvoiceDetails
	 *            the new exp invoice details
	 */
	public void setExpInvoiceDetails(List<ExpInvoiceDetail> expInvoiceDetails) {
		this.expInvoiceDetails = expInvoiceDetails;
	}

	/**
	 * Gets the exp typ.
	 *
	 * @return the exp typ
	 */
	public String getExpTyp() {
		return expTyp;
	}

	/**
	 * Sets the exp typ.
	 *
	 * @param expTyp
	 *            the new exp typ
	 */
	public void setExpTyp(String expTyp) {
		this.expTyp = expTyp;
	}
}
