package com.mind.egsp.gstn.dto.gstr9;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mind.egsp.gstn.model.gstr9.Table10AggregateSummary;
import com.mind.egsp.gstn.model.gstr9.Table14AggregateSummary;
import com.mind.egsp.gstn.model.gstr9.Table15AggregateSummary;
import com.mind.egsp.gstn.model.gstr9.Table16AggregateSummary;
import com.mind.egsp.gstn.model.gstr9.Table17AggregateSummary;
import com.mind.egsp.gstn.model.gstr9.Table18AggregateSummary;
import com.mind.egsp.gstn.model.gstr9.Table4AggregateSummary;
import com.mind.egsp.gstn.model.gstr9.Table5AggregateSummary;
import com.mind.egsp.gstn.model.gstr9.Table6AggregateSummary;
import com.mind.egsp.gstn.model.gstr9.Table7AggregateSummary;
import com.mind.egsp.gstn.model.gstr9.Table8AggregateSummary;
import com.mind.egsp.gstn.model.gstr9.Table9AggregateSummary;

/**
 * The Class SaveGstr9DTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class SaveGstr9DTO   implements Serializable {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The GSTIN of the Tax Payer. */
	private String gstin;

	/** Financial period. */
	private String fp;
	
	/** The table 4. */
	private Table4AggregateSummary table4;
	
	/** The table 5. */
	private Table5AggregateSummary table5;
	
	/** The table 6. */
	private Table6AggregateSummary table6;
	
	/** The table 7. */
	private Table7AggregateSummary table7;

	/** The table 8. */
	private Table8AggregateSummary table8;
	
	/** The table 9. */
	private Table9AggregateSummary table9;
	
	/** The table 10. */
	private Table10AggregateSummary table10;

	/** The table 14. */
	private Table14AggregateSummary table14;
	
	/** The table 15. */
	private Table15AggregateSummary table15;
	
	/** The table 16. */
	private Table16AggregateSummary table16;
	
	/** The table 17. */
	private Table17AggregateSummary table17;
	
	/** The table 18. */
	private Table18AggregateSummary table18;

	/**
	 * Gets the gstin.
	 *
	 * @return the gstin
	 */
	public String getGstin() {
		return gstin;
	}

	/**
	 * Sets the gstin.
	 *
	 * @param gstin the new gstin
	 */
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the fp.
	 *
	 * @return the fp
	 */
	public String getFp() {
		return fp;
	}

	/**
	 * Sets the fp.
	 *
	 * @param fp the new fp
	 */
	public void setFp(String fp) {
		this.fp = fp;
	}

	/**
	 * Gets the table 4.
	 *
	 * @return the table 4
	 */
	public Table4AggregateSummary getTable4() {
		return table4;
	}

	/**
	 * Sets the table 4.
	 *
	 * @param table4 the new table 4
	 */
	public void setTable4(Table4AggregateSummary table4) {
		this.table4 = table4;
	}

	/**
	 * Gets the table 5.
	 *
	 * @return the table 5
	 */
	public Table5AggregateSummary getTable5() {
		return table5;
	}

	/**
	 * Sets the table 5.
	 *
	 * @param table5 the new table 5
	 */
	public void setTable5(Table5AggregateSummary table5) {
		this.table5 = table5;
	}

	/**
	 * Gets the table 6.
	 *
	 * @return the table 6
	 */
	public Table6AggregateSummary getTable6() {
		return table6;
	}

	/**
	 * Sets the table 6.
	 *
	 * @param table6 the new table 6
	 */
	public void setTable6(Table6AggregateSummary table6) {
		this.table6 = table6;
	}

	/**
	 * Gets the table 7.
	 *
	 * @return the table 7
	 */
	public Table7AggregateSummary getTable7() {
		return table7;
	}

	/**
	 * Sets the table 7.
	 *
	 * @param table7 the new table 7
	 */
	public void setTable7(Table7AggregateSummary table7) {
		this.table7 = table7;
	}

	/**
	 * Gets the table 8.
	 *
	 * @return the table 8
	 */
	public Table8AggregateSummary getTable8() {
		return table8;
	}

	/**
	 * Sets the table 8.
	 *
	 * @param table8 the new table 8
	 */
	public void setTable8(Table8AggregateSummary table8) {
		this.table8 = table8;
	}

	/**
	 * Gets the table 9.
	 *
	 * @return the table 9
	 */
	public Table9AggregateSummary getTable9() {
		return table9;
	}

	/**
	 * Sets the table 9.
	 *
	 * @param table9 the new table 9
	 */
	public void setTable9(Table9AggregateSummary table9) {
		this.table9 = table9;
	}

	/**
	 * Gets the table 10.
	 *
	 * @return the table 10
	 */
	public Table10AggregateSummary getTable10() {
		return table10;
	}

	/**
	 * Sets the table 10.
	 *
	 * @param table10 the new table 10
	 */
	public void setTable10(Table10AggregateSummary table10) {
		this.table10 = table10;
	}

	/**
	 * Gets the table 14.
	 *
	 * @return the table 14
	 */
	public Table14AggregateSummary getTable14() {
		return table14;
	}

	/**
	 * Sets the table 14.
	 *
	 * @param table14 the new table 14
	 */
	public void setTable14(Table14AggregateSummary table14) {
		this.table14 = table14;
	}

	/**
	 * Gets the table 15.
	 *
	 * @return the table 15
	 */
	public Table15AggregateSummary getTable15() {
		return table15;
	}

	/**
	 * Sets the table 15.
	 *
	 * @param table15 the new table 15
	 */
	public void setTable15(Table15AggregateSummary table15) {
		this.table15 = table15;
	}

	/**
	 * Gets the table 16.
	 *
	 * @return the table 16
	 */
	public Table16AggregateSummary getTable16() {
		return table16;
	}

	/**
	 * Sets the table 16.
	 *
	 * @param table16 the new table 16
	 */
	public void setTable16(Table16AggregateSummary table16) {
		this.table16 = table16;
	}

	/**
	 * Gets the table 17.
	 *
	 * @return the table 17
	 */
	public Table17AggregateSummary getTable17() {
		return table17;
	}

	/**
	 * Sets the table 17.
	 *
	 * @param table17 the new table 17
	 */
	public void setTable17(Table17AggregateSummary table17) {
		this.table17 = table17;
	}

	/**
	 * Gets the table 18.
	 *
	 * @return the table 18
	 */
	public Table18AggregateSummary getTable18() {
		return table18;
	}

	/**
	 * Sets the table 18.
	 *
	 * @param table18 the new table 18
	 */
	public void setTable18(Table18AggregateSummary table18) {
		this.table18 = table18;
	}
	
	
}
