package com.mind.egsp.gstn.dto.gstr1;

import java.io.Serializable;
import java.util.Arrays;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

/**
 * The Gstr1 Summary Request DTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Gstr2SummaryRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	public Gstr2SummaryRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	@Override
	public String toString() {
		return "Gstr1SummaryRequestDTO [getSk()=" + Arrays.toString(getSk()) + ", getUsername()=" + getUsername()
				+ ", getAuthToken()=" + getAuthToken() + ", getAction()=" + getAction() + ", getIpUsr()=" + getIpUsr()
				+ ", getTxn()=" + getTxn() + ", getGstin()=" + getGstin() + ", getRetPeriod()=" + getRetPeriod()
				+ ", getStateCd()=" + getStateCd() + ", getClientId()=" + getClientId() + ", getBusinessTypeId()="
				+ getBusinessTypeId() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

}
