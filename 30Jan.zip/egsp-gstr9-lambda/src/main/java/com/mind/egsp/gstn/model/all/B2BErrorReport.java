package com.mind.egsp.gstn.model.all;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.model.gstr1.B2bInvoiceDetail;

/**
 * The Class B2BErrorReport.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class B2BErrorReport implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The B2B Invoice. */
	@JsonProperty("inv")
	private List<B2bInvoiceDetail> b2bInvoiceDetails;

	/**
	 * The Supplier TIN .
	 */
	private String ctin;

	/**
	 * The Error_cd .
	 */
	@JsonProperty("error_cd")
	private String errorCd;

	/**
	 * The Error Message .
	 */
	@JsonProperty("error_msg")
	private String errorMsg;

	/**
	 * Gets the Supplier TIN Field Specification: Alphanumeric with 15 char
	 * Sample Data: 20GRRHF2562D3A3 .
	 *
	 * @return the ctin
	 */
	public String getCtin() {
		return ctin;
	}

	/**
	 * Sets the Supplier TIN Field Specification: Alphanumeric with 15 char
	 * Sample Data: 20GRRHF2562D3A3 .
	 *
	 * @param ctin
	 *            the new ctin
	 */
	public void setCtin(String ctin) {
		this.ctin = ctin;
	}

	/**
	 * Gets the Error_cd Field Specification: Alphanumeric (Max length:10)
	 * Sample Data: RET100 .
	 *
	 * @return the error cd
	 */
	public String getErrorCd() {
		return errorCd;
	}

	/**
	 * Sets the Error_cd Field Specification: Alphanumeric (Max length:10)
	 * Sample Data: RET100 .
	 *
	 * @param errorCd
	 *            the new error cd
	 */
	public void setErrorCd(String errorCd) {
		this.errorCd = errorCd;
	}

	/**
	 * Gets the Error Message Field Specification: Alphanumeric (Max length:100)
	 * Sample Data: Duplicate Invoice .
	 *
	 * @return the error msg
	 */
	public String getErrorMsg() {
		return errorMsg;
	}

	/**
	 * Sets the Error Message Field Specification: Alphanumeric (Max length:100)
	 * Sample Data: Duplicate Invoice .
	 *
	 * @param errorMsg
	 *            the new error msg
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	/**
	 * Gets the b 2 b invoice details.
	 *
	 * @return the b 2 b invoice details
	 */
	public List<B2bInvoiceDetail> getB2bInvoiceDetails() {
		return b2bInvoiceDetails;
	}

	/**
	 * Sets the b 2 b invoice details.
	 *
	 * @param b2bInvoiceDetails
	 *            the new b 2 b invoice details
	 */
	public void setB2bInvoiceDetails(List<B2bInvoiceDetail> b2bInvoiceDetails) {
		this.b2bInvoiceDetails = b2bInvoiceDetails;
	}

}
