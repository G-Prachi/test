package com.mind.egsp.gstn.dto.gstr8;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr8.Gstr8CdnurInvoice;

// TODO: Auto-generated Javadoc
/**
 * The Class Gstr8GetCdnurInvoicesResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Gstr8GetCdnurInvoicesResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The cdnur invoices. */
	@JsonProperty("cdnur")
	private List<Gstr8CdnurInvoice> cdnurInvoices;

	/** The Token. */
	private String token;

	/** The Estimated Time in minutes. */
	private String est;

	/**
	 * Gets the token.
	 *
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * Sets the token.
	 *
	 * @param token
	 *            the new token
	 */
	public void setToken(String token) {
		this.token = token;
	}

	/**
	 * Gets the Estimated Time in minutes.
	 *
	 * @return the est
	 */
	public String getEst() {
		return est;
	}

	/**
	 * Sets the Estimated Time in minutes.
	 *
	 * @param est
	 *            the new est
	 */
	public void setEst(String est) {
		this.est = est;
	}

	/**
	 * Gets the gets the cdnr invoice.
	 *
	 * @return the gets the cdnr invoice
	 */
	public List<Gstr8CdnurInvoice> getGetCdnurInvoice() {
		return cdnurInvoices;
	}

	/**
	 * Sets the gets the cdnr invoice.
	 *
	 * @param cdnurInvoices
	 *            the new gets the cdnur invoice
	 */
	public void setGetCdnurInvoice(List<Gstr8CdnurInvoice> cdnurInvoices) {
		this.cdnurInvoices = cdnurInvoices;
	}
}
