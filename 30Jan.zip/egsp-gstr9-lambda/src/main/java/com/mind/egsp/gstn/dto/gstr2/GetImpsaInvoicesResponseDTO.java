package com.mind.egsp.gstn.dto.gstr2;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr2.ImpsaInvoiceDetail;

/**
 * The Class GetAmmendedImpOfServicesBillsResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetImpsaInvoicesResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Impsa invoice detail. */
	@JsonProperty("imp_sa")
	private List<ImpsaInvoiceDetail> impsaInvoiceDetails;

	/**
	 * Gets the impsa invoice details.
	 *
	 * @return the impsa invoice details
	 */
	public List<ImpsaInvoiceDetail> getImpsaInvoiceDetails() {
		return impsaInvoiceDetails;
	}

	/**
	 * Sets the impsa invoice details.
	 *
	 * @param impsaInvoiceDetails
	 *            the new impsa invoice details
	 */
	public void setImpsaInvoiceDetails(List<ImpsaInvoiceDetail> impsaInvoiceDetails) {
		this.impsaInvoiceDetails = impsaInvoiceDetails;
	}

}
