package com.mind.egsp.gstn.dto.gstr3;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

/**
 * The Class GetGSTR3ReturnStatusRequestDTO.
 */
public class GetReturnStatusRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The GSTIN of the Tax Payer. */
	private String gstin;

	/** The Return Period. */
	private String ret_pd;

	/** The Transaction ID. */
	@JsonProperty("trans_id")
	private String transId;

	public GetReturnStatusRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	/**
	 * Gets the GSTIN of the taxpayer Field Specification: Alphanumeric with 15
	 * characters Mandatory: Y Sample Data: 29HJKPS9689A8Z4 .
	 *
	 * @return the gstin
	 */
	@Override
	public String getGstin() {
		return gstin;
	}

	/**
	 * Sets the GSTIN of the taxpayer Field Specification: Alphanumeric with 15
	 * characters Mandatory: Y Sample Data: 29HJKPS9689A8Z4 .
	 *
	 * @param gstin
	 *            the new gstin
	 */
	@Override
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the Return Period Field Specification: MMYYYY Mandatory: Y Sample
	 * Data: 072016 .
	 *
	 * @return the ret pd
	 */
	public String getRet_pd() {
		return ret_pd;
	}

	/**
	 * Sets the Return Period Field Specification: MMYYYY Mandatory: Y Sample
	 * Data: 072016 .
	 *
	 * @param ret_pd
	 *            the new ret pd
	 */
	public void setRet_pd(String ret_pd) {
		this.ret_pd = ret_pd;
	}

	/**
	 * Gets the Transaction ID Field Specification: Alphanumeric with 15
	 * characters Mandatory: Y Sample Data: AD2235345345123 .
	 *
	 * @return the trans id
	 */
	public String getTransId() {
		return transId;
	}

	/**
	 * Sets the Transaction ID Field Specification: Alphanumeric with 15
	 * characters Mandatory: Y Sample Data: AD2235345345123 .
	 *
	 * @param transId
	 *            the new trans id
	 */
	public void setTransId(String transId) {
		this.transId = transId;
	}

}
