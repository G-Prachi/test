package com.mind.egsp.gstn.ledger;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;

/**
 * The Class GetCashLedgerDetailsResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class GetItcLedgerDetailsResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	@JsonProperty("itc")
	private GetItcLedgerResponseDTO getItcLedgerResponseDTO;

	public GetItcLedgerResponseDTO getGetItcLedgerResponseDTO() {
		return getItcLedgerResponseDTO;
	}

	/**
	 * Sets the gets the itc ledger response DTO.
	 *
	 * @param getItcLedgerResponseDTO
	 *            the new gets the itc ledger response DTO
	 */
	public void setGetItcLedgerResponseDTO(GetItcLedgerResponseDTO getItcLedgerResponseDTO) {
		this.getItcLedgerResponseDTO = getItcLedgerResponseDTO;
	}

}
