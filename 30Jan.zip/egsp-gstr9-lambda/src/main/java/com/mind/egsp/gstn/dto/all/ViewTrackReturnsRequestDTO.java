package com.mind.egsp.gstn.dto.all;

import java.io.Serializable;

import com.mind.egsp.gstn.dto.BaseRequestDTO;

/**
 * The Class ViewTrackReturnsRequestDTO.
 */
public class ViewTrackReturnsRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The Return Type.
	 */
	private String type;



	public ViewTrackReturnsRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	/**
	 * Gets the Return Type Field Specification: String Mandatory: N Sample Data:
	 * R1.
	 *
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * Sets the Return Type Field Specification: String Mandatory: N Sample Data:
	 * R1.
	 *
	 * @param type
	 *            the new type
	 */
	public void setType(String type) {
		this.type = type;
	}

}
