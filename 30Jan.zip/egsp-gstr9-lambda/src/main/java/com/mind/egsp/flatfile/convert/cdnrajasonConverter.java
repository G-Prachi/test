package com.mind.egsp.flatfile.convert;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
//import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mind.egsp.gstn.dto.gstr1.SaveGstr1DTO;
import com.mind.egsp.gstn.model.gstr1.CdnraInvoice;
import com.mind.egsp.gstn.model.gstr1.CdnraInvoiceDetail;
import com.mind.egsp.gstn.model.gstr1.*;
import com.amazonaws.services.s3.AmazonS3;
import com.egsp.finalDTOs.*;

public class cdnrajasonConverter {

//	static List<CdnrInvoiceDetailFlat> flatCdnrDetiallist =  new ArrayList<CdnrInvoiceDetailFlat>();		
//	static List<CdnrInvoiceFlat>  flatCdnrlist = new ArrayList<CdnrInvoiceFlat>();
//	static List<CdnrInvoiceFlatFinal> cdnrInvFlatFinal = new ArrayList<CdnrInvoiceFlatFinal>();
	
	public static String cdnraJasonConverter(SaveGstr1DTO gstriObj,String bucketName,String filePath,String fileName,AmazonS3 s3, String str2)
	{
		//***************************Declaration for Cdnr*************
		try
		{
				List<CdnraInvoiceFlat>  flatCdnralist = new ArrayList<CdnraInvoiceFlat>();				
				//byte[] jsonData1 = Files.readAllBytes(Paths.get("B2b-sample.json"));
				//create ObjectMapper instance
				//ObjectMapper objectMapper = new ObjectMapper();
				SaveGstr1DTOFlat savedtoflat  = new SaveGstr1DTOFlat();
				//SaveGstr1DTO gstriObj = objectMapper.readValue(jsonData1, SaveGstr1DTO.class);
				savedtoflat.setFp(gstriObj.getFp());
				//B2BInvoice================
				List<CdnraInvoice> list = gstriObj.getCdnraInvoices();
				List<CdnraInvoiceDetailFlat> flatCdnraDetiallist = new ArrayList<CdnraInvoiceDetailFlat>();
				//System.out.println(list.size() +  "" + list.toString());		
				BigDecimal totaltxval = new BigDecimal(0);
				BigDecimal totaliamt = new BigDecimal(0);;
				BigDecimal totalcamt =new BigDecimal(0);
				BigDecimal totalsamt =new BigDecimal(0);
				BigDecimal totalcsamt = new BigDecimal(0);
				if(list!=null)
				{
				for(CdnraInvoice item : list)
				{
					//flatCdnrDetiallist = new ArrayList<CdnrInvoiceDetailFlat>();
					
					System.out.print(item.toString());
					CdnraInvoiceFlat cdnraflat = new CdnraInvoiceFlat();
					//cdnraflat.setCtin(item.getCtin());
					for(CdnraInvoiceDetail invDetail : item.getCdnraInvoiceDetails()) {
						CdnraInvoiceDetailFlat cdnraInvoiceDetailFLatlist = new CdnraInvoiceDetailFlat();
						cdnraInvoiceDetailFLatlist.setInum(invDetail.getInum());
						cdnraflat.setVal(invDetail.getVal());
						cdnraInvoiceDetailFLatlist.setIdt(invDetail.getIdt());						
						cdnraInvoiceDetailFLatlist.setNtNum(invDetail.getNtNum());
						cdnraInvoiceDetailFLatlist.setNtDt(invDetail.getNtDt());
						cdnraInvoiceDetailFLatlist.setNtty(invDetail.getNtty());	
						cdnraInvoiceDetailFLatlist.setOntNum(invDetail.getOntNum());
						cdnraInvoiceDetailFLatlist.setOntDt(invDetail.getOntDt());
						
						for (CDNRItem item1 :invDetail.getCdnrItems()){
							totaltxval = totaltxval.add(item1.getCdnrItemDetails().getTxval());
							totaliamt = totaliamt.add(item1.getCdnrItemDetails().getIamt());
							totalcamt = totalcamt.add(item1.getCdnrItemDetails().getCamt());
							totalsamt = totalsamt.add(item1.getCdnrItemDetails().getSamt());
							totalcsamt = totalcsamt.add(item1.getCdnrItemDetails().getCsamt());							
						    }
							cdnraInvoiceDetailFLatlist.setTotaltxval(totaltxval);
							cdnraInvoiceDetailFLatlist.setTotaliamt(totaliamt);
							cdnraInvoiceDetailFLatlist.setTotalcamt(totalcamt);
							cdnraInvoiceDetailFLatlist.setTotalcsamt(totalcsamt);
							cdnraInvoiceDetailFLatlist.setTotalsamt(totalsamt);
							flatCdnraDetiallist.add(cdnraInvoiceDetailFLatlist);
					}
					cdnraflat.setCdnraInvoiceDetailFLat(flatCdnraDetiallist);
					flatCdnralist.add(cdnraflat);
				}
//				System.out.println("flatCdnrlist "+flatCdnrlist);
					List<CdnraInvoiceFlatFinal> cdnrafinalList = new ArrayList<CdnraInvoiceFlatFinal>();
					for(CdnraInvoiceFlat flatList : flatCdnralist)
					{
						for(CdnraInvoiceDetailFlat cdnraInvoiceFlat : flatList.getCdnraInvoiceDetailFLat()) {
							CdnraInvoiceFlatFinal cdnraInvoiceFlatFinal = new CdnraInvoiceFlatFinal();
							cdnraInvoiceFlatFinal.setFp(gstriObj.getFp());
							cdnraInvoiceFlatFinal.setBusinessType("cdnra");
							cdnraInvoiceFlatFinal.setCtin(flatList.getCtin());
							
							//cdnrInvoiceFlatFinal.setRchrg(flatList.getRchrg());
							//cdnrInvoiceFlatFinal.setInvTyp(flatList.getInvTyp());
							//------------------***--------------------------
							cdnraInvoiceFlatFinal.setVal(flatList.getVal());
							cdnraInvoiceFlatFinal.setInum(cdnraInvoiceFlat.getInum());
							cdnraInvoiceFlatFinal.setIdt(cdnraInvoiceFlat.getIdt());
							cdnraInvoiceFlatFinal.setNtDt(cdnraInvoiceFlat.getNtDt());
							cdnraInvoiceFlatFinal.setNtNum(cdnraInvoiceFlat.getNtNum());
							cdnraInvoiceFlatFinal.setNtty(cdnraInvoiceFlat.getNtty());
							cdnraInvoiceFlatFinal.setOntNum(cdnraInvoiceFlat.getOntNum());
							cdnraInvoiceFlatFinal.setOntDt(cdnraInvoiceFlat.getOntDt());
							cdnraInvoiceFlatFinal.setTotalcamt(cdnraInvoiceFlat.getTotalcamt());
							cdnraInvoiceFlatFinal.setTotalcsamt(cdnraInvoiceFlat.getTotalcsamt());
							cdnraInvoiceFlatFinal.setTotaliamt(cdnraInvoiceFlat.getTotaliamt());
							cdnraInvoiceFlatFinal.setTotalsamt(cdnraInvoiceFlat.getTotalsamt());
							cdnraInvoiceFlatFinal.setTotaltxval(cdnraInvoiceFlat.getTotaltxval());
							cdnrafinalList.add(cdnraInvoiceFlatFinal);
						}
					}
					
				final ByteArrayOutputStream out = new ByteArrayOutputStream();
			    final ObjectMapper mapper = new ObjectMapper();
			    
			    mapper.writeValue(out, cdnrafinalList);
		        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		        StringBuilder tempFile = new StringBuilder();
		        Random rnd = new Random();
		        while (tempFile.length() < 18) { // length of the random string.
		            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
		            tempFile.append(SALTCHARS.charAt(index));
		        }
		        String tempFil = tempFile.toString();
		        File tempFileName = new File(tempFil+".json");
		        //return saltStr;
				mapper.writeValue(tempFileName, cdnrafinalList);
				InputStream is = new FileInputStream(tempFileName);
				String contents = new BufferedReader(new InputStreamReader(is)).readLine();
				is.close(); 
				
					String str = contents.substring(1, contents.length()-1);
					String str1=str.replaceAll("},", "}\n");
					System.out.println(str1);
					str2= str2.concat(str1);
					return(str2);
					/*PrintWriter pr = new PrintWriter(new BufferedWriter(new FileWriter(new File(fileName), true)));
					pr.write(str1);
					pr.append("\n");
					pr.close();
					s3.putObject(bucketName, filePath+"/"+fileName, str1);
					System.out.println("sucess");*/
			    
			  
				}
		}
				catch(Exception ex)
				{
					 System.out.println(ex.toString());
				}
		return (str2);
	}
}
		
	





