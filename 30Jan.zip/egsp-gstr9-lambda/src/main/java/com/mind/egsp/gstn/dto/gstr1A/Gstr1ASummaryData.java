package com.mind.egsp.gstn.dto.gstr1A;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr1A.GSTR1ASectionSummary;

// TODO: Auto-generated Javadoc
/**
 * The Class GetGSTR1ASummaryResponseDTO.
 */
public class Gstr1ASummaryData extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The GSTIN of the taxpayer .
	 */
	private String gstin;

	/**
	 * The Return Period .
	 */
	@JsonProperty("ret_period")
	private String retPeriod;

	/**
	 * The Invoice Check sum value .
	 */
	private String chksum;

	/**
	 * Short / long Summary .
	 */
	@JsonProperty("summ_typ")
	private String summTyp;

	/** The gstr 1 a section summary. */
	@JsonProperty("sec_sum")
	private List<GSTR1ASectionSummary> gstr1aSectionSummary;

	/**
	 * Gets the GSTIN of the taxpayer Field Specification: Alphanumeric with 15
	 * characters Sample Data: 29HJKPS9689A8Z4 .
	 *
	 * @return the gstin
	 */
	public String getGstin() {
		return gstin;
	}

	/**
	 * Sets the GSTIN of the taxpayer Field Specification: Alphanumeric with 15
	 * characters Sample Data: 29HJKPS9689A8Z4 .
	 *
	 * @param gstin
	 *            the new gstin
	 */
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the Return Period Field Specification: MMYYYY Sample Data: 072016 .
	 *
	 * @return the ret period
	 */
	public String getRetPeriod() {
		return retPeriod;
	}

	/**
	 * Sets the Return Period Field Specification: MMYYYY Sample Data: 072016 .
	 *
	 * @param retPeriod
	 *            the new ret period
	 */
	public void setRetPeriod(String retPeriod) {
		this.retPeriod = retPeriod;
	}

	/**
	 * Gets the Invoice Check sum value Field Specification: string(Max
	 * length:15) Sample Data: AflJufPlFStqKBZ .
	 *
	 * @return the chksum
	 */
	public String getChksum() {
		return chksum;
	}

	/**
	 * Sets the Invoice Check sum value Field Specification: string(Max
	 * length:15) Sample Data: AflJufPlFStqKBZ .
	 *
	 * @param chksum
	 *            the new chksum
	 */
	public void setChksum(String chksum) {
		this.chksum = chksum;
	}

	/**
	 * Gets the summ typ.
	 *
	 * @return the summ typ
	 */
	public String getSummTyp() {
		return summTyp;
	}

	/**
	 * Sets the summ typ.
	 *
	 * @param summTyp
	 *            the new summ typ
	 */
	public void setSummTyp(String summTyp) {
		this.summTyp = summTyp;
	}

	/**
	 * Gets the gstr 1 a section summary.
	 *
	 * @return the gstr 1 a section summary
	 */
	public List<GSTR1ASectionSummary> getGstr1aSectionSummary() {
		return gstr1aSectionSummary;
	}

	/**
	 * Sets the gstr 1 a section summary.
	 *
	 * @param gstr1aSectionSummary
	 *            the new gstr 1 a section summary
	 */
	public void setGstr1aSectionSummary(List<GSTR1ASectionSummary> gstr1aSectionSummary) {
		this.gstr1aSectionSummary = gstr1aSectionSummary;
	}

}
