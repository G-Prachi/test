package com.mind.egsp.gstn.dto.gstr;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.all.GstrRetStatusData;

/**
 * The GetRetStatusResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetRetStatusResponseDTO extends BaseDataResponseDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonIgnore
	private GstrRetStatusData retStatusData;

	public GstrRetStatusData getRetStatusData() {
		return retStatusData;
	}

	public void setRetStatusData(GstrRetStatusData retStatusData) {
		this.retStatusData = retStatusData;
	}

}
