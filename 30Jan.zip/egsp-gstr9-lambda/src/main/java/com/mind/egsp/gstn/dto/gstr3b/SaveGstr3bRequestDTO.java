package com.mind.egsp.gstn.dto.gstr3b;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

/**
 * The Gstr3b Save Data Request DTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class SaveGstr3bRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** HMAC-SHA256 of Base64 data using EK. */
	private String hmac;

	/** Reference id. */
	@JsonProperty("ref_id")
	private String refId;

	/** The gstr 3 b save DTO. */
	@JsonProperty("data")
	private Gstr3bDetailDTO gstr3bDetailDTO;

	/**
	 * Instantiates a new save gstr 3 b request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param gstin
	 *            the gstin
	 * @param retPeriod
	 *            the ret period
	 * @param username
	 *            the username
	 * @param clientId
	 *            the client id
	 * @param businessTypeId
	 *            the business type id
	 */
	public SaveGstr3bRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username, Long clientId, Long businessTypeId) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username, clientId, businessTypeId);
	}

	public SaveGstr3bRequestDTO() {
		super();
	}

	/**
	 * Gets the ref id.
	 *
	 * @return the ref id
	 */
	public String getRefId() {
		return refId;
	}

	/**
	 * Sets the ref id.
	 *
	 * @param refId
	 *            the new ref id
	 */
	public void setRefId(String refId) {
		this.refId = refId;
	}

	/**
	 * Gets the gstr 3 b detail DTO.
	 *
	 * @return the gstr 3 b detail DTO
	 */
	public Gstr3bDetailDTO getGstr3bDetailDTO() {
		return gstr3bDetailDTO;
	}

	/**
	 * Sets the gstr 3 b detail DTO.
	 *
	 * @param gstr3bDetailDTO
	 *            the new gstr 3 b detail DTO
	 */
	public void setGstr3bDetailDTO(Gstr3bDetailDTO gstr3bDetailDTO) {
		this.gstr3bDetailDTO = gstr3bDetailDTO;
	}

	/**
	 * Gets the hmac.
	 *
	 * @return the hmac
	 */
	public String getHmac() {
		return hmac;
	}

	/**
	 * Sets the hmac.
	 *
	 * @param hmac
	 *            the new hmac
	 */
	public void setHmac(String hmac) {
		this.hmac = hmac;
	}

}
