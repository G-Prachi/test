package com.mind.egsp.flatfile.convert;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mind.egsp.gstn.dto.gstr1.SaveGstr1DTO;
import com.mind.egsp.gstn.model.gstr1.B2bInvoice;
import com.mind.egsp.gstn.model.gstr1.HsnSummary;
import com.mind.egsp.gstn.model.gstr1.HsnSummaryDetail;
import com.mind.egsp.gstn.model.gstr1.NilSupplyData;
import com.mind.egsp.gstn.model.gstr1.NilSupply;
import com.amazonaws.services.s3.AmazonS3;
import com.egsp.finalDTOs.*;

public class niljsonConverter {

//	static List<B2bInvoiceDetailFlat> flatB2bDetiallist =  new ArrayList<B2bInvoiceDetailFlat>();		
//	static List<B2bInvoiceFlat>  flatB2blist = new ArrayList<B2bInvoiceFlat>();
//	static List<B2bInvoiceFlatFinal> b2bInvFlatFinal = new ArrayList<B2bInvoiceFlatFinal>();
	
	public static String b2bJsonConverter(SaveGstr1DTO gstriObj,String bucketName,String filePath,String fileName,AmazonS3 s3, String str2)
	{
		//***************************Declaration for B2b*************
		try
		{
				List<NilInvoiceFlat>  flatnillist = new ArrayList<NilInvoiceFlat>();				
				//byte[] jsonData1 = Files.readAllBytes(Paths.get("B2b-sample.json"));
				//create ObjectMapper instance
				//ObjectMapper objectMapper = new ObjectMapper();
				SaveGstr1DTOFlat savedtoflat  = new SaveGstr1DTOFlat();
				//SaveGstr1DTO gstriObj = objectMapper.readValue(jsonData1, SaveGstr1DTO.class);
				savedtoflat.setFp(gstriObj.getFp());
				
				
				NilSupply hsnSummary = new NilSupply();
				          hsnSummary =gstriObj.getNilSupply();
				          
				 // get nillsupplydata list
				      //    List<HsnSummaryDetail> hsnSummaryDetailList = new ArrayList<HsnSummaryDetail>();
				      //    hsnSummaryDetailList = hsnSummary.getHsnSummaryDetails();
				          
				          List<NilInvoiceDetailFlat> hsnInvoiceDetailsFlatList = new ArrayList<NilInvoiceDetailFlat>();
				          
				          
				         // for(HsnSummaryDetail hsnInvDetails : hsnSummaryDetail)
				        	  for (NilSupplyData hsnInvDetail :hsnSummary.getNilSupplyDatas())
				          {
				        	  NilInvoiceDetailFlat hsnInvDetailsFlat = new NilInvoiceDetailFlat();
				        	  
				        	  hsnInvDetailsFlat.setExptAmt(hsnInvDetail.getExptAmt());
				        	  hsnInvDetailsFlat.setNgsupAmt(hsnInvDetail.getNgsupAmt());
				        	  hsnInvDetailsFlat.setNilAmt(hsnInvDetail.getNilAmt());
				        	  //hsnInvDetailsFlat.setVal(hsnInvDetail.getVal());
				        	  //hsnInvDetailsFlat.setTxval(hsnInvDetail.getTxval());
				        	  //hsnInvDetailsFlat.setCamt(hsnInvDetail.getCamt());
				        	  //hsnInvDetailsFlat.setCsamt(hsnInvDetail.getCsamt());
				        	  //hsnInvDetailsFlat.setSamt(hsnInvDetail.getSamt());
				        	  //hsnInvDetailsFlat.setIamt(hsnInvDetail.getIamt());
				        	  hsnInvDetailsFlat.setFp(gstriObj.getFp());
				        	  hsnInvDetailsFlat.setBusinessType("nil");
				        	  hsnInvoiceDetailsFlatList.add(hsnInvDetailsFlat);
				          }
				final ByteArrayOutputStream out = new ByteArrayOutputStream();
			    final ObjectMapper mapper = new ObjectMapper();
			    
			    mapper.writeValue(out, hsnInvoiceDetailsFlatList);
		        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		        StringBuilder tempFile = new StringBuilder();
		        Random rnd = new Random();
		        while (tempFile.length() < 18) { // length of the random string.
		            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
		            tempFile.append(SALTCHARS.charAt(index));
		        }
		        String tempFil = tempFile.toString();
		        File tempFileName = new File(tempFil+".json");
		        //return saltStr;
				mapper.writeValue(tempFileName, hsnInvoiceDetailsFlatList);
				InputStream is = new FileInputStream(tempFileName);
				String contents = new BufferedReader(new InputStreamReader(is)).readLine();
				is.close(); 
				
					String str = contents.substring(1, contents.length()-1);
					String str1=str.replaceAll("},", "}\n");
					System.out.println(str1);
					str2= str2.concat(str1);
					return(str2);
					/*PrintWriter pr = new PrintWriter(new BufferedWriter(new FileWriter(new File(fileName), true)));
					pr.write(str1);
					pr.append("\n");
					pr.close();
					s3.putObject(bucketName, filePath+"/"+fileName, str1);
					System.out.println("sucess");*/
			    
			   
				}
				catch(Exception ex)
				{
					
				}
		return (str2);
	}
}
		
	





