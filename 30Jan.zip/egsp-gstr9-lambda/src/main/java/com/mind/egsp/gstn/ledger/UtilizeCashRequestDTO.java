package com.mind.egsp.gstn.ledger;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseRequestDTO;
import com.mind.egsp.gstn.model.ledger.CashUtilizationTowardsLiablity;

// TODO: Auto-generated Javadoc
/**
 * The Class UtilizeCashRequestDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class UtilizeCashRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The GSTIN of the Tax Payer. */
	private String gstin;

	/** The Month and financial year. */
	@JsonProperty("tax_prd")
	private String taxPrd;

	/** The Return Type. */
	@JsonProperty("ret_type")
	private String retType;

	/** TheUtilization towards Liablities. */
	@JsonProperty("op_liab")
	private List<CashUtilizationTowardsLiablity> utilizationTowardsLiablities;

	/**
	 * Instantiates a new gets the cash ledger details request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param gstin
	 *            the gstin
	 * @param retPeriod
	 *            the ret period
	 * @param username
	 *            the username
	 */
	public UtilizeCashRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
		this.gstin = gstin;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.mind.egsp.gstn.dto.BaseRequestDTO#getGstin()
	 */
	@Override
	public String getGstin() {
		return gstin;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.mind.egsp.gstn.dto.BaseRequestDTO#setGstin(java.lang.String)
	 */
	@Override
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the Month and financial year.
	 *
	 * @return the Month and financial year
	 */
	public String getTaxPrd() {
		return taxPrd;
	}

	/**
	 * Sets the Month and financial year.
	 * 
	 * Field Specifications: String(YYYYMM)
	 *
	 * @param taxPrd
	 *            the new Month and financial year
	 */
	public void setTaxPrd(String taxPrd) {
		this.taxPrd = taxPrd;
	}

	/**
	 * Gets the Return Type.
	 *
	 * @return the Return Type
	 */
	public String getRetType() {
		return retType;
	}

	/**
	 * Sets the Return Type.
	 * 
	 * Field Specifications: String (Max Length : 3)
	 *
	 * @param retType
	 *            the new Return Type
	 */
	public void setRetType(String retType) {
		this.retType = retType;
	}

	/**
	 * Gets the utilization towards liablities.
	 *
	 * @return the utilization towards liablities
	 */
	public List<CashUtilizationTowardsLiablity> getUtilizationTowardsLiablities() {
		return utilizationTowardsLiablities;
	}

	/**
	 * Sets the utilization towards liablities.
	 *
	 * @param utilizationTowardsLiablities
	 *            the new utilization towards liablities
	 */
	public void setUtilizationTowardsLiablities(List<CashUtilizationTowardsLiablity> utilizationTowardsLiablities) {
		this.utilizationTowardsLiablities = utilizationTowardsLiablities;
	}

}
