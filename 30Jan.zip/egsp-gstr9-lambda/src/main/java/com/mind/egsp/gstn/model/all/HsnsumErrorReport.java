package com.mind.egsp.gstn.model.all;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.model.gstr1.HsnSummaryDetail;
import com.mind.egsp.gstn.model.gstr2.Gstr2HsnSummaryDetail;

// TODO: Auto-generated Javadoc
/**
 * The Class HSNErrorReport.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class HsnsumErrorReport implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The Error Message .
	 */
	@JsonProperty("error_msg")
	private String errorMsg;

	/**
	 * The Error_cd .
	 */
	@JsonProperty("error_cd")
	private String errorCd;

	/**
	 * The HSN Summary List .
	 */
	@JsonProperty("det")
	private List<Gstr2HsnSummaryDetail> gstr2HsnSummaryDetails;

	/** The hsn summary details. */
	@JsonProperty("data")
	private List<HsnSummaryDetail> hsnSummaryDetails;

	/**
	 * Gets the error msg.
	 *
	 * @return the error msg
	 */
	public String getErrorMsg() {
		return errorMsg;
	}

	/**
	 * Sets the error msg.
	 *
	 * @param errorMsg
	 *            the new error msg
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	/**
	 * Gets the error cd.
	 *
	 * @return the error cd
	 */
	public String getErrorCd() {
		return errorCd;
	}

	/**
	 * Sets the error cd.
	 *
	 * @param errorCd
	 *            the new error cd
	 */
	public void setErrorCd(String errorCd) {
		this.errorCd = errorCd;
	}

	/**
	 * Gets the gstr 2 hsn summary details.
	 *
	 * @return the gstr 2 hsn summary details
	 */
	public List<Gstr2HsnSummaryDetail> getGstr2HsnSummaryDetails() {
		return gstr2HsnSummaryDetails;
	}

	/**
	 * Sets the gstr 2 hsn summary details.
	 *
	 * @param gstr2HsnSummaryDetails
	 *            the new gstr 2 hsn summary details
	 */
	public void setGstr2HsnSummaryDetails(List<Gstr2HsnSummaryDetail> gstr2HsnSummaryDetails) {
		this.gstr2HsnSummaryDetails = gstr2HsnSummaryDetails;
	}

	/**
	 * Gets the hsn summary details.
	 *
	 * @return the hsn summary details
	 */
	public List<HsnSummaryDetail> getHsnSummaryDetails() {
		return hsnSummaryDetails;
	}

	/**
	 * Sets the hsn summary details.
	 *
	 * @param hsnSummaryDetails
	 *            the new hsn summary details
	 */
	public void setHsnSummaryDetails(List<HsnSummaryDetail> hsnSummaryDetails) {
		this.hsnSummaryDetails = hsnSummaryDetails;
	}

}
