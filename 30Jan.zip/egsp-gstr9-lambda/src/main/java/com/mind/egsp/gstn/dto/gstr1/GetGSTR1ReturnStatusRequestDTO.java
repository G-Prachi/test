package com.mind.egsp.gstn.dto.gstr1;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

/**
 * The Class GetReturnStatusRequestDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetGSTR1ReturnStatusRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The GSTIN of the Tax Payer. */
	private String gstin;

	/** The Transaction ID. */
	@JsonProperty("trans_id")
	private String transId;

	public GetGSTR1ReturnStatusRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	/**
	 * Gets the GSTIN of the taxpayer Field Specification: Alphanumeric with 15
	 * characters Mandatory: Y Sample Data: 29HJKPS9689A8Z4 .
	 *
	 * @return the gstin
	 */
	@Override
	public String getGstin() {
		return gstin;
	}

	/**
	 * Sets the GSTIN of the taxpayer Field Specification: Alphanumeric with 15
	 * characters Mandatory: Y Sample Data: 29HJKPS9689A8Z4 .
	 *
	 * @param gstin
	 *            the new gstin
	 */
	@Override
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	/**
	 * Gets the Transaction ID Field Specification: Alphanumeric with 15
	 * characters Mandatory: Y Sample Data: AD2235345345123 .
	 *
	 * @return the trans id
	 */
	public String getTransId() {
		return transId;
	}

	/**
	 * Sets the Transaction ID Field Specification: Alphanumeric with 15
	 * characters Mandatory: Y Sample Data: AD2235345345123 .
	 *
	 * @param transId
	 *            the new trans id
	 */
	public void setTransId(String transId) {
		this.transId = transId;
	}

}
