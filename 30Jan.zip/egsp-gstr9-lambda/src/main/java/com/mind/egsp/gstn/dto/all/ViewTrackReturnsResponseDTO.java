package com.mind.egsp.gstn.dto.all;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.all.ViewTrackReturnsDTO;


/**
 * The Class ViewReturnsResponseDTO.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)

public class ViewTrackReturnsResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The GSTIN of the taxpayer. */
	@JsonProperty("EFiledlist")
	private List<ViewTrackReturnsDTO> viewTrackReturnsDTOs;


	/**
	 * Gets the view track returns DTos.
	 *
	 * @return the view track returns DTos
	 */
	public List<ViewTrackReturnsDTO> getViewTrackReturnsDTOs() {
		return viewTrackReturnsDTOs;
	}


	/**
	 * Sets the view track returns DTos.
	 *
	 * @param viewTrackReturnsDTOs
	 *            the new view track returns DTos
	 */
	public void setViewTrackReturnsDTOs(List<ViewTrackReturnsDTO> viewTrackReturnsDTOs) {
		this.viewTrackReturnsDTOs = viewTrackReturnsDTOs;
	}

}
