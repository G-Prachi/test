package com.mind.egsp.gstn.dto.gstr1;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr1.AtInvoice;

/**
 * The Class GetAtResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetAtInvoicesResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Advance Tax invoice detail. */
	@JsonProperty("at")
	private List<AtInvoice> atInvoices;

	/**
	 * Gets the Advance Tax invoices.
	 *
	 * @return the Advance Tax invoices
	 */
	public List<AtInvoice> getAtInvoices() {
		return atInvoices;
	}

	/**
	 * Sets the Advance Tax invoices.
	 *
	 * @param atInvoices
	 *            the new Advance Tax invoices
	 */
	public void setAtInvoices(List<AtInvoice> atInvoices) {
		this.atInvoices = atInvoices;
	}

}
