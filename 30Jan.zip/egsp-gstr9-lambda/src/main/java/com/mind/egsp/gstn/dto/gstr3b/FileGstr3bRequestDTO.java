package com.mind.egsp.gstn.dto.gstr3b;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseRequestDTO;


// TODO: Auto-generated Javadoc
/**
 * The File Gstr3b Request DTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class FileGstr3bRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** HMAC-SHA256 of Base64 data using EK. */
	private String hmac;

	/** Reference id. */
	@JsonProperty("ref_id")
	private String refId;


	/** The data. */
	@JsonProperty("data")
	private String data;

	/**
	 * PKCS#7 signature of SHA-256 hash of Base64 of response of getGSTR3BSummary
	 * using private key of Tax Payer (Authorized signatory).
	 */
	private String sign;

	/** Type of signature – DSC or ESIGN. */
	private String st;

	/**
	 * PAN of authorized representative if st = DSC or AADHAR no. of authorized
	 * representative if st=ESIGN .
	 */
	private String sid;

	/**
	 * Instantiates a new save gstr 3 b request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param gstin
	 *            the gstin
	 * @param retPeriod
	 *            the ret period
	 * @param username
	 *            the username
	 * @param clientId
	 *            the client id
	 * @param businessTypeId
	 *            the business type id
	 */
	public FileGstr3bRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username, Long clientId, Long businessTypeId) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username, clientId, businessTypeId);
	}

	/**
	 * Gets the ref id.
	 *
	 * @return the ref id
	 */
	public String getRefId() {
		return refId;
	}

	/**
	 * Sets the ref id.
	 *
	 * @param refId
	 *            the new ref id
	 */
	public void setRefId(String refId) {
		this.refId = refId;
	}


	/**
	 * Gets the hmac.
	 *
	 * @return the hmac
	 */
	public String getHmac() {
		return hmac;
	}

	/**
	 * Sets the hmac.
	 *
	 * @param hmac
	 *            the new hmac
	 */
	public void setHmac(String hmac) {
		this.hmac = hmac;
	}

	/**
	 * Gets the sign.
	 *
	 * @return the sign
	 */
	public String getSign() {
		return sign;
	}

	/**
	 * Sets the sign.
	 *
	 * @param sign
	 *            the new sign
	 */
	public void setSign(String sign) {
		this.sign = sign;
	}

	/**
	 * Gets the st.
	 *
	 * @return the st
	 */
	public String getSt() {
		return st;
	}

	/**
	 * Sets the st.
	 *
	 * @param st
	 *            the new st
	 */
	public void setSt(String st) {
		this.st = st;
	}

	/**
	 * Gets the sid.
	 *
	 * @return the sid
	 */
	public String getSid() {
		return sid;
	}

	/**
	 * Sets the sid.
	 *
	 * @param sid
	 *            the new sid
	 */
	public void setSid(String sid) {
		this.sid = sid;
	}

	/**
	 * Gets the data.
	 *
	 * @return the data
	 */
	public String getData() {
		return data;
	}

	/**
	 * Sets the data.
	 *
	 * @param data the new data
	 */
	public void setData(String data) {
		this.data = data;
	}

	

}
