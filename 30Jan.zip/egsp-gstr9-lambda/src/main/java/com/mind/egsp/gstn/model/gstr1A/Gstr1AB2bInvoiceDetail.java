package com.mind.egsp.gstn.model.gstr1A;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.model.gstr2.Gstr2B2bInvoiceDetail;

/**
 * The Class Gstr2B2BInvoice.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Gstr1AB2bInvoiceDetail extends Gstr2B2bInvoiceDetail implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** counter party Filing Status. */
	@JsonProperty("inv_typ")
	private String invTyp;

	/**
	 * Gets the inv typ.
	 *
	 * @return the inv typ
	 */
	public String getInvTyp() {
		return invTyp;
	}

	/**
	 * Sets the inv typ.
	 *
	 * @param invTyp
	 *            the new inv typ
	 */
	public void setInvTyp(String invTyp) {
		this.invTyp = invTyp;
	}
}
