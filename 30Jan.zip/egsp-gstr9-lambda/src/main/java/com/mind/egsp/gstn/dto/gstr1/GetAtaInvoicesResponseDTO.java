package com.mind.egsp.gstn.dto.gstr1;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr1.AtaInvoice;

/**
 * The Class GetAtaInvoicesResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetAtaInvoicesResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The ata invoice detail. */
	@JsonProperty("ata")
	private List<AtaInvoice> ataInvoices;

	/**
	 * Gets the ata invoices.
	 *
	 * @return the ata invoices
	 */
	public List<AtaInvoice> getAtaInvoices() {
		return ataInvoices;
	}

	/**
	 * Sets the ata invoices.
	 *
	 * @param ataInvoices
	 *            the new ata invoices
	 */
	public void setAtaInvoices(List<AtaInvoice> ataInvoices) {
		this.ataInvoices = ataInvoices;
	}

}
