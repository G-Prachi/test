package com.mind.egsp.gstn.dto.gstr3;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;

/**
 * The Class SubmitGSTR3RefundResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)

public class SubmitRefundResponseDTO extends BaseDataResponseDTO implements Serializable {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The debit id. */
	@JsonProperty("debit_id")
	private String debitId;

	/**
	 * Gets the debit id.
	 *
	 * @return the debit id
	 */
	public String getDebitId() {
		return debitId;
	}

	/**
	 * Sets the debit id.
	 *
	 * @param debitId
	 *            the new debit id
	 */
	public void setDebitId(String debitId) {
		this.debitId = debitId;
	}

}
