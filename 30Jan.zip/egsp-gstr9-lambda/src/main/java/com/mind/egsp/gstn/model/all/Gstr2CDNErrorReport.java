package com.mind.egsp.gstn.model.all;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.model.gstr2.Gstr2CdnInvoiceDetail;

/**
 * The Class Gstr2CDNErrorReport.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Gstr2CDNErrorReport implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Counter party GSTIN. */
	private String ctin;

	/** The CDN detail. */
	@JsonProperty("nt")
	private List<Gstr2CdnInvoiceDetail> cdnInvoiceDetails;

	/**
	 * The Error_cd .
	 */
	@JsonProperty("error_cd")
	private String errorCd;

	/**
	 * The Error Message .
	 */
	@JsonProperty("error_msg")
	private String errorMsg;

	/**
	 * Gets the ctin.
	 *
	 * @return the ctin
	 */
	public String getCtin() {
		return ctin;
	}

	/**
	 * Sets the ctin.
	 *
	 * @param ctin
	 *            the new ctin
	 */
	public void setCtin(String ctin) {
		this.ctin = ctin;
	}

	/**
	 * Gets the cdn invoice details.
	 *
	 * @return the cdn invoice details
	 */
	public List<Gstr2CdnInvoiceDetail> getCdnInvoiceDetails() {
		return cdnInvoiceDetails;
	}

	/**
	 * Sets the cdn invoice details.
	 *
	 * @param cdnInvoiceDetails
	 *            the new cdn invoice details
	 */
	public void setCdnInvoiceDetails(List<Gstr2CdnInvoiceDetail> cdnInvoiceDetails) {
		this.cdnInvoiceDetails = cdnInvoiceDetails;
	}

	/**
	 * Gets the error cd.
	 *
	 * @return the error cd
	 */
	public String getErrorCd() {
		return errorCd;
	}

	/**
	 * Sets the error cd.
	 *
	 * @param errorCd
	 *            the new error cd
	 */
	public void setErrorCd(String errorCd) {
		this.errorCd = errorCd;
	}

	/**
	 * Gets the error msg.
	 *
	 * @return the error msg
	 */
	public String getErrorMsg() {
		return errorMsg;
	}

	/**
	 * Sets the error msg.
	 *
	 * @param errorMsg
	 *            the new error msg
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

}
