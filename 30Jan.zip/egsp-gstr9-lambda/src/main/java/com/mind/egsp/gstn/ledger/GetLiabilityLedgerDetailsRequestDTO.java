package com.mind.egsp.gstn.ledger;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

/**
 * The Class GetITCLedgerDetailsRequestDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetLiabilityLedgerDetailsRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Tax Period. */
	@JsonProperty("tax_prd")
	private String taxPrd;

	/**
	 * Instantiates a new gets the cash ledger details request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param gstin
	 *            the gstin
	 * @param retPeriod
	 *            the ret period
	 * @param username
	 *            the username
	 */
	public GetLiabilityLedgerDetailsRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username, String taxPrd) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
		this.taxPrd = taxPrd;
	}

	/**
	 * Gets the Tax Period.
	 *
	 * @return the Tax Period
	 */
	public String getTaxPrd() {
		return taxPrd;
	}

	/**
	 * Sets the Tax Period. Format: YYYYMM
	 *
	 * @param taxPrd
	 *            the new Tax Period
	 */
	public void setTaxPrd(String taxPrd) {
		this.taxPrd = taxPrd;
	}

}
