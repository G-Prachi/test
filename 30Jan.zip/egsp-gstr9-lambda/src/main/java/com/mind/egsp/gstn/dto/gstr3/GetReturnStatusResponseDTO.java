package com.mind.egsp.gstn.dto.gstr3;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseResponseDTO;

/**
 * The Class GetGSTR3ReturnStatusResponseDTO.
 */
public class GetReturnStatusResponseDTO extends BaseResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The status cd. */
	@JsonProperty("status_cd")
	private String statusCd;

	/**
	 * The Acknowledgement No .
	 */
	@JsonProperty("arn_no")
	private String arnNo;

	/**
	 * The Error Code .
	 */
	@JsonProperty("error_cd")
	private String errorCd;

	/**
	 * The Error Message .
	 */
	@JsonProperty("error_det")
	private String errorDet;

	/**
	 * Gets the Status_code Field Specification: One character(0 or 1) Sample
	 * Data: 0-Failure, 1=Success .
	 *
	 * @return the status cd
	 */
	public String getStatusCd() {
		return statusCd;
	}

	/**
	 * Sets the Status_code Field Specification: One character(0 or 1) Sample
	 * Data: 0-Failure, 1=Success .
	 *
	 * @param statusCd
	 *            the new status cd
	 */
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

	/**
	 * Gets the Acknowledgement No Field Specification: Alphanumeric (Max
	 * length:50) Sample Data: DEABCSR6898M5Z4 .
	 *
	 * @return the arn no
	 */
	public String getArnNo() {
		return arnNo;
	}

	/**
	 * Sets the Acknowledgement No Field Specification: Alphanumeric (Max
	 * length:50) Sample Data: DEABCSR6898M5Z4 .
	 *
	 * @param arnNo
	 *            the new arn no
	 */
	public void setArnNo(String arnNo) {
		this.arnNo = arnNo;
	}

	/**
	 * Gets the Error Code Field Specification: Alphanumeric (Max length:5)
	 * Sample Data: RET300 .
	 *
	 * @return the error cd
	 */
	public String getErrorCd() {
		return errorCd;
	}

	/**
	 * Sets the Error Code Field Specification: Alphanumeric (Max length:5)
	 * Sample Data: RET300 .
	 *
	 * @param errorCd
	 *            the new error cd
	 */
	public void setErrorCd(String errorCd) {
		this.errorCd = errorCd;
	}

	/**
	 * Gets the Error Message Field Specification: Alphanumeric (Max length:50)
	 * Sample Data: .
	 *
	 * @return the error det
	 */
	public String getErrorDet() {
		return errorDet;
	}

	/**
	 * Sets the Error Message Field Specification: Alphanumeric (Max length:50)
	 * Sample Data: .
	 *
	 * @param errorDet
	 *            the new error det
	 */
	public void setErrorDet(String errorDet) {
		this.errorDet = errorDet;
	}

}
