package com.mind.egsp.gstn.dto.auth;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class AuthBaseRequestDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String action;

	@JsonProperty("app_key")
	private String appKey;

	private String username;

	@JsonIgnore
	private String gstin;

	@JsonIgnore
	private String stateCd;

	@JsonIgnore
	private String ipUsr;

	@JsonIgnore
	private String txn;

	/** The client id. */
	@JsonIgnore
	private Long clientId;

	/** The api action. */
	@JsonIgnore
	private String apiAction;

	/** The ret period. */
	@JsonIgnore
	private String retPeriod;

	public AuthBaseRequestDTO(String stateCd, String ipUsr, String txn, String appKey, String username) {
		this.stateCd = stateCd;
		this.ipUsr = ipUsr;
		this.txn = txn;
		this.appKey = appKey;
		this.username = username;
	}

	public AuthBaseRequestDTO(String appKey, String username) {
		super();
		this.appKey = appKey;
		this.username = username;

	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getAppKey() {
		return appKey;
	}

	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getStateCd() {
		return stateCd;
	}

	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}

	public String getIpUsr() {
		return ipUsr;
	}

	public void setIpUsr(String ipUsr) {
		this.ipUsr = ipUsr;
	}

	public String getTxn() {
		return txn;
	}

	public void setTxn(String txn) {
		this.txn = txn;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public Long getClientId() {
		return clientId;
	}

	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}

	public String getApiAction() {
		return apiAction;
	}

	public void setApiAction(String apiAction) {
		this.apiAction = apiAction;
	}

	public String getRetPeriod() {
		return retPeriod;
	}

	public void setRetPeriod(String retPeriod) {
		this.retPeriod = retPeriod;
	}

}
