package com.mind.egsp.gstn.dto.gstr3;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseRequestDTO;
import com.mind.egsp.gstn.model.gstr3.InterestLiability;

/**
 * The Class SubmitGSTR3LiabilitiesInterestDataRequestDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)

public class SubmitLiabInterRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The submit GSTR 3 liabilities interest data DTO. */
	@JsonProperty("data")
	private InterestLiability interestLiability;

	/**
	 * Instantiates a new submit GSTR 3 liabilities interest data request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param gstin
	 *            the gstin
	 * @param retPeriod
	 *            the ret period
	 * @param username
	 *            the username
	 */
	public SubmitLiabInterRequestDTO(String stateCd, String ipUsr, String txn, String gstin,
			String retPeriod, String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	public InterestLiability getInterestLiability() {
		return interestLiability;
	}

	/**
	 * Sets the interest liability.
	 *
	 * @param interestLiability
	 *            the new interest liability
	 */
	public void setInterestLiability(InterestLiability interestLiability) {
		this.interestLiability = interestLiability;
	}

}
