package com.mind.egsp.flatfile.convert;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.Writer;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectId;
import com.egsp.finalDTOs.CdnrInvoiceDetailFlat;
import com.egsp.finalDTOs.CdnrInvoiceFlat;
import com.egsp.finalDTOs.CdnrInvoiceFlatFinal;
import com.egsp.finalDTOs.SaveGstr1DTOFlat;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mind.egsp.gstn.dto.gstr1.SaveGstr1DTO;
import com.mind.egsp.gstn.model.gstr1.CDNRItem;
import com.mind.egsp.gstn.model.gstr1.CdnrInvoice;
import com.mind.egsp.gstn.model.gstr1.CdnrInvoiceDetail;

public class cdnrjsonConverter {

//	static List<CdnrInvoiceDetailFlat> flatCdnrDetiallist =  new ArrayList<CdnrInvoiceDetailFlat>();		
//	static List<CdnrInvoiceFlat>  flatCdnrlist = new ArrayList<CdnrInvoiceFlat>();
//	static List<CdnrInvoiceFlatFinal> cdnrInvFlatFinal = new ArrayList<CdnrInvoiceFlatFinal>();

	public static String cdnrJsonConverter(SaveGstr1DTO gstriObj, String bucketName, String filePath, String fileName,
			AmazonS3 s3, String str2) {
		// ***************************Declaration for Cdnr*************
		try {
			List<CdnrInvoiceFlat> flatCdnrlist = new ArrayList<CdnrInvoiceFlat>();
			// byte[] jsonData1 = Files.readAllBytes(Paths.get("B2b-sample.json"));
			// create ObjectMapper instance
			System.out.println("Message from the bottom of the sea " + bucketName);
			SaveGstr1DTOFlat savedtoflat = new SaveGstr1DTOFlat();
			// SaveGstr1DTO gstriObj = objectMapper.readValue(jsonData1,
			// SaveGstr1DTO.class);
			savedtoflat.setFp(gstriObj.getFp());
			// B2BInvoice================
			List<CdnrInvoice> list = gstriObj.getCdnrInvoices();
			List<CdnrInvoiceDetailFlat> flatCdnrDetiallist = new ArrayList<CdnrInvoiceDetailFlat>();
			// System.out.println(list.size() + "" + list.toString());
			BigDecimal totaltxval = new BigDecimal(0);
			BigDecimal totaliamt = new BigDecimal(0);
			BigDecimal totalcamt = new BigDecimal(0);
			BigDecimal totalsamt = new BigDecimal(0);
			BigDecimal totalcsamt = new BigDecimal(0);
			if (list != null) {
				for (CdnrInvoice item : list) {
					// flatCdnrDetiallist = new ArrayList<CdnrInvoiceDetailFlat>();
					CdnrInvoiceFlat cdnrflat = new CdnrInvoiceFlat();
					cdnrflat.setCtin(item.getCtin());
					for (CdnrInvoiceDetail invDetail : item.getCdnrInvoiceDetails()) {
						CdnrInvoiceDetailFlat cdnrInvoiceDetailFLat = new CdnrInvoiceDetailFlat();
						cdnrInvoiceDetailFLat.setInum(invDetail.getInum());
						cdnrflat.setVal(invDetail.getVal());
						cdnrInvoiceDetailFLat.setIdt(invDetail.getIdt());
						cdnrInvoiceDetailFLat.setNtNum(invDetail.getNtNum());
						cdnrInvoiceDetailFLat.setNtDt(invDetail.getNtDt());
						cdnrInvoiceDetailFLat.setNtty(invDetail.getNtty());
						System.out.println("Message from the bottom of the sea 1 " );
						for (CDNRItem item1 : invDetail.getCdnrItems()) {
							totaltxval = totaltxval.add(item1.getCdnrItemDetails().getTxval());
							totaliamt = totaliamt.add(item1.getCdnrItemDetails().getIamt());
							totalcamt = totalcamt.add(item1.getCdnrItemDetails().getCamt());
							totalsamt = totalsamt.add(item1.getCdnrItemDetails().getSamt());
							totalcsamt = totalcsamt.add(item1.getCdnrItemDetails().getCsamt());
						}
						cdnrInvoiceDetailFLat.setTotaltxval(totaltxval);
						cdnrInvoiceDetailFLat.setTotaliamt(totaliamt);
						cdnrInvoiceDetailFLat.setTotalcamt(totalcamt);
						cdnrInvoiceDetailFLat.setTotalcsamt(totalcsamt);
						cdnrInvoiceDetailFLat.setTotalsamt(totalsamt);
						flatCdnrDetiallist.add(cdnrInvoiceDetailFLat);
					}
					cdnrflat.setCdnrInvoiceDetailFLat(flatCdnrDetiallist);
					flatCdnrlist.add(cdnrflat);
				}
				System.out.println("Message from the bottom of the sea 2" );
//				System.out.println("flatCdnrlist "+flatCdnrlist);
				List<CdnrInvoiceFlatFinal> cdnrfinalList = new ArrayList<CdnrInvoiceFlatFinal>();
				for (CdnrInvoiceFlat flatList : flatCdnrlist) {
					for (CdnrInvoiceDetailFlat cdnrInvoiceFlat : flatList.getCdnrInvoiceDetailFLat()) {
						CdnrInvoiceFlatFinal cdnrInvoiceFlatFinal = new CdnrInvoiceFlatFinal();
						cdnrInvoiceFlatFinal.setFp(gstriObj.getFp());
						cdnrInvoiceFlatFinal.setBusinessType("cdnr");
						cdnrInvoiceFlatFinal.setCtin(flatList.getCtin());

						// cdnrInvoiceFlatFinal.setRchrg(flatList.getRchrg());
						// cdnrInvoiceFlatFinal.setInvTyp(flatList.getInvTyp());
						// ------------------***--------------------------
						cdnrInvoiceFlatFinal.setVal(flatList.getVal());
						cdnrInvoiceFlatFinal.setInum(cdnrInvoiceFlat.getInum());
						cdnrInvoiceFlatFinal.setIdt(cdnrInvoiceFlat.getIdt());
						cdnrInvoiceFlatFinal.setNtDt(cdnrInvoiceFlat.getNtDt());
						cdnrInvoiceFlatFinal.setNtNum(cdnrInvoiceFlat.getNtNum());
						cdnrInvoiceFlatFinal.setNtty(cdnrInvoiceFlat.getNtty());
						cdnrInvoiceFlatFinal.setTotalcamt(cdnrInvoiceFlat.getTotalcamt());
						cdnrInvoiceFlatFinal.setTotalcsamt(cdnrInvoiceFlat.getTotalcsamt());
						cdnrInvoiceFlatFinal.setTotaliamt(cdnrInvoiceFlat.getTotaliamt());
						cdnrInvoiceFlatFinal.setTotalsamt(cdnrInvoiceFlat.getTotalsamt());
						cdnrInvoiceFlatFinal.setTotaltxval(cdnrInvoiceFlat.getTotaltxval());
						cdnrfinalList.add(cdnrInvoiceFlatFinal);
					}
				}

				final ByteArrayOutputStream out = new ByteArrayOutputStream();
				final ObjectMapper mapper = new ObjectMapper();
				System.out.println("Message from the bottom of the sea 3 ");
				mapper.writeValue(out, cdnrfinalList);
				String contents = out.toString();
				String str = contents.substring(1, contents.length() - 1);
				String str1 = str.replaceAll("},", "}\n");
				System.out.println(str1);
				str2 = str2.concat(str1);
				// s3 = AmazonS3ClientBuilder.standard().withRegion(Regions.AP_SOUTH_1).build();
				// s3client.putObject(bucket, key, contents);
				//s3.putObject(bucketName, filePath + "/" + fileName, str2);
				System.out.println("sucess");
				return str2;

			}
		} catch (Exception ex) {

			ex.printStackTrace();
		}
		return str2;
	}
}
