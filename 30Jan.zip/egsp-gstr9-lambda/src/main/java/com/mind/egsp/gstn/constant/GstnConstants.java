package com.mind.egsp.gstn.constant;

/**
 * The Class GstnConstants.
 */
public class GstnConstants {

	/** API action name. */
	public static final String API_ACTION_NAME = "action";

	/** Request for OTP action name. */
	public static final String API_AUTHENTICATION_GET_OTP_ACTION = "OTPREQUEST";

	/** The Constant API_GET_EVC_OTP_ACTION. */
	public static final String API_GET_EVC_OTP_ACTION = "EVCOTP";

	/** Request forAuthorization token action name. */
	public static final String API_AUTHENTICATION_GET_AUTH_TOKEN_ACTION = "AUTHTOKEN";

	/** Request for extension of authorization token action name. */
	public static final String API_AUTHENTICATION_EXTEND_AUTH_TOKEN_ACTION = "REFRESHTOKEN";

	// GSTR Returns APIs action name
	/** Save GSTR data action name. */
	public static final String API_RETURNS_SAVE_GSTR_ACTION = "RETSAVE";

	/** Get B2B Invoices action name. */
	public static final String API_RETURNS_GET_B2B_ACTION = "B2B";

	/** Get B2B Amended Invoices action name. */
	public static final String API_RETURNS_GET_B2BA_ACTION = "B2BA";

	/** Get B2CL Invoices action name. */
	public static final String API_RETURNS_GET_B2CL_ACTION = "B2CL";

	/** Get B2CL Amended Invoices action name. */
	public static final String API_RETURNS_GET_B2CLA_ACTION = "B2CLA";

	/** Get B2CS Invoices action name. */
	public static final String API_RETURNS_GET_B2CS_ACTION = "B2CS";

	/** Get B2CSA Amended Invoices action name. */
	public static final String API_RETURNS_GET_B2CSA_ACTION = "B2CSA";

	/** Get CDN Invoices action name. */
	public static final String API_RETURNS_GET_CDNR_ACTION = "CDNR";

	/** Get CDN Amended Invoices action name. */
	public static final String API_RETURNS_GET_CDNA_ACTION = "CDNA";

	/** Get CDNUR Invoices. */
	public static final String API_RETURNS_GET_CDNUR_ACTION = "CDNUR";

	/** Get CDNURA Invoices. */
	public static final String API_RETURNS_GET_CDNURA_ACTION = "CDNURA";

	/** Get NIL Invoices action name. */
	public static final String API_RETURNS_GET_NIL_ACTION = "NIL";

	/** Get EXP Invoices action name. */
	public static final String API_RETURNS_GET_EXP_ACTION = "EXP";

	/** Get EXP Amended Invoices action name. */
	public static final String API_RETURNS_GET_EXPA_ACTION = "EXPA";

	/** Get AT Invoices action name. */
	public static final String API_RETURNS_GET_AT_ACTION = "AT";

	/** Get AT Amended Invoices action name. */
	public static final String API_RETURNS_GET_ATA_ACTION = "ATA";

	/** Get TXP Invoices action name. */
	public static final String API_RETURNS_GET_TXP_ACTION = "TXP";

	/** Get ECOM Invoices action name. */
	public static final String API_RETURNS_GET_ECOM_ACTION = "ECOM";

	/** Get HSNSUM Invoices action name. */
	public static final String API_RETURNS_GET_HSNSUM_ACTION = "HSNSUM";

	/** GET Return Status. */
	public static final String API_RETURNS_GET_RETURN_STATUS_ACTION = "RETSTATUS";

	/** GET File Details. */
	public static final String API_RETURNS_GET_FILE_DETAILS_ACTION = "FILEDTLS";

	/** Get GSTR Summary action name. */
	public static final String API_RETURNS_GET_GSTR_SUMMARY_ACTION = "RETSUM";

	/** Submit Gstr1 action name. */
	public static final String API_RETURNS_SUBMIT_GSTR_ACTION = "RETSUBMIT";

	/** The Constant API_RETURNS_GET_FILEDET_ACTION. */
	public static final String API_RETURNS_GET_FILEDET_ACTION = "FILEDET";

	/** Get import of goods Invoices action name. */
	public static final String API_RETURNS_GET_IMPG_ACTION = "IMPG";

	/** Get amended imp of goods Invoices action name. */
	public static final String API_RETURNS_GET_IMPGA_ACTION = "IMPGA";

	/** Get import of Service Invoices action name. */
	public static final String API_RETURNS_GET_IMPS_ACTION = "IMPS";

	/** Get amended imp of service Invoices action name. */
	public static final String API_RETURNS_GET_IMPSA_ACTION = "IMPSA";

	/** Get ITC Received action name. */
	public static final String API_RETURNS_GET_ITC_ACTION = "ITC";

	/** Get Tax liability under Reverse charge Summary action name. */
	public static final String API_RETURNS_GET_TXLI_ACTION = "TXLI";

	/** Get Amended Tax liability under Reverse charge Summary action name. */
	public static final String API_RETURNS_GET_ATXLI_ACTION = "ATXLI";

	/** Offset Liability GSTR3B action name. */
	public static final String API_RETURNS_RET_OFFSET = "RETOFFSET";
	// END of GSTR Returns APIs action name

	// Ledger APIs action name
	/** Get Cash Ledger Details action name. */
	public static final String API_LEDGER_GET_CASH_DETAILS_ACTION = "CASHDTL";

	/** Get ITC Ledger Details action name. */
	public static final String API_LEDGER_GET_ITC_DETAILS_ACTION = "ITCDTL";

	/** Utilize Cash action name. */
	public static final String API_LEDGER_UTILIZE_CASH_ACTION = "UTLCSH";

	/** Utilize ITC action name. */
	public static final String API_LEDGER_UTILIZE_ITC_ACTION = "UTLITC";

	/** Get Liability Ledger Details action name. */
	public static final String API_LEDGER_GET_LIABILITY_DETAILS_ACTION = "TAX";

	/** Get Cash Ledger Summary action name. */
	public static final String API_LEDGER_GET_CASH_LEDGER_SUMMARY_ACTION = "CASHSUM";

	/** Get ITC Ledger Summary action name. */
	public static final String API_LEDGER_GET_ITC_LEDGER_SUMMARY_ACTION = "ITCSUM";

	/** Get RetLiab Balance action name. */
	public static final String API_LEDGER_GET_RETLIAB_BALANCE_ACTION = "TAXPAYABLE";

	/** Get Cash ITC Balance action name. */
	public static final String API_LEDGER_GET_CASH_ITC_BALANCE_ACTION = "BAL";
	// End of Ledger APIs action name

	/** File Gstr11 action name. */
	public static final String API_RETURNS_FILE_GSTR_ACTION = "RETFILE";

	/** The Constant APP_KEY. */
	public static final String GSTN_APP_KEY = "gstn_appKey";

	/** The Constant AUTH_TOKEN. */
	public static final String GSTN_AUTH_TOKEN = "gstn_auth_token";

	/** The Constant AUTH_TOKEN_EXPIRY_TIME. */
	public static final String GSTN_AUTH_TOKEN_EXPIRE_TIME = "gstn_auth_token_expire_time";

	/** The Constant SESSION_KEY. */
	public static final String GSTN_SESSION_KEY = "gstn_session_key";

	/** The Constant TRANSACTION_ID. */
	public static final String GSTN_TRANSACTION_ID = "gstn_transaction_id";

	/** The Constant EGSP_FORGOT_PASSWORD_LINK_EXPIRE_TIME. */
	public static final String EGSP_FORGOT_PASSWORD_LINK_EXPIRE_TIME = "1440";

	/** Get CDN Invoices action name. */
	public static final String API_RETURNS_GET_CDN_ACTION = "CDN";

	/** The Constant HOST. */
	public static final String HOST = "host";

	/** The Constant REGION_NAME. */
	public static final String REGION_NAME = "ap-south-1";

	/** The Constant SERVICE_NAME. */
	public static final String SERVICE_NAME = "execute-api";

	/** The Constant X_AMZ_DATE. */
	public static final String X_AMZ_DATE = "x-amz-date";

	/** The Constant AUTHORIZATION. */
	public static final String AUTHORIZATION = "Authorization";

	/** The Constant JSON_MEDIA_TYPE. */
	public static final String JSON_MEDIA_TYPE = "application/json";

	/** The Constant AMPERSAND. */
	public static final String AMPERSAND = "&";

	/** The Constant EQUAL_OPER. */
	public static final String EQUAL_OPER = "=";

	/** The Constant ZERO. */
	public static final int ZERO = 0;

	/** The Constant ONE. */
	public static final int ONE = 1;

	/** The Constant GSTN_SESSION_EXPIRY_TIME. */
	public static final String GSTN_SESSION_EXPIRY_TIME = "gstn_session_expiry_time";

	/** The six hour in ms. */
	public static int SIX_HOUR_IN_MS = 21600000;

	/** API call for GSTR3 Genaret details. */
	public static final String API_RETURNS_GENERATE_ACTION = "GENERATE";

	/** API call for GSTR3- Submit liability & Interest API integration.. */
	public static final String API_RETURNS_SUBMIT_LIAB_INT_ACTION = "RETACCEPT";

	/** Type of signature – DSC or ESIGN. */
	public static final String API_RETURNS_FILE_SIGNATURE = "DSC";


	/** Get CASH Ledger action name. */
	public static final String API_LEDGER_GET_CASH_ACTION = "CASH";

	/** Get Common Authentication action name. */
	public static final String GSTN_COMMON_AUTH_TOKEN = "ACCESSTOKEN";

	/** Get search taxpayer details. */
	public static final String GSTN_COMMON_SEARCH_TAX_PAYER_ACTION = "TP";
	
	/** Get View and Track Returns. */
	public static final String GSTN_VIEW_AND_TRACK_RETURNS_ACTION = "RETTRACK";

	/** GSTN API Success Code. */
	public static final String GSTN_API_SUCCESS = "1";
	
	/** Period(Start time) in which tokens will expire - minutes to add in current time. */
	public static final int TOKEN_EXTEND_START_AFTER_MINUTE = 30;
	
	/** Period(End Time) in which tokens will expire - minutes to add in current time. */
	public static final int TOKEN_EXTEND_END_BEFORE_MIN = 60;

	public static final String API_RETURNS_EVC_FILE_SIGNATURE = "EVC";

	public static final String API_RETURNS_EVC_SIGN_SEPARATOR = "|";

	public static final String API_RETURNS_GET_GSTR9_AUTOCALCULATED_ACTION = "CALRCDS";
	
	public static final String API_RETURNS_GET_GSTR9_DETAILS_ACTION = "RECORDS";
}
