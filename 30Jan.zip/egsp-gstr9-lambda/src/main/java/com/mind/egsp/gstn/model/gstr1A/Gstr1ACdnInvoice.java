package com.mind.egsp.gstn.model.gstr1A;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

// TODO: Auto-generated Javadoc
/**
 * The Class Gstr2CdnInvoice.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Gstr1ACdnInvoice implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Counter party GSTIN. */
	private String ctin;

	/** The counter party Filing Status. */
	private String cfs;

	/** The CDN detail. */
	@JsonProperty("nt")
	private List<Gstr1ACdnInvoiceDetail> cdnInvoiceDetails;

	/**
	 * Gets the Counter party GSTIN.
	 *
	 * Field Specification:Alphanumeric with 15 characters
	 *
	 * @return the ctin
	 */
	public String getCtin() {
		return ctin;
	}

	/**
	 * Sets the Counter party GSTIN.
	 *
	 * Field Specification:Alphanumeric with 15 characters
	 *
	 * @param ctin
	 *            the new ctin
	 */
	public void setCtin(String ctin) {
		this.ctin = ctin;
	}

	/**
	 * Gets the cdn invoice details.
	 *
	 * @return the cdn invoice details
	 */
	public List<Gstr1ACdnInvoiceDetail> getCdnInvoiceDetails() {
		return cdnInvoiceDetails;
	}

	/**
	 * Sets the cdn invoice details.
	 *
	 * @param cdnInvoiceDetails
	 *            the new cdn invoice details
	 */
	public void setCdnInvoiceDetails(List<Gstr1ACdnInvoiceDetail> cdnInvoiceDetails) {
		this.cdnInvoiceDetails = cdnInvoiceDetails;
	}

	/**
	 * Gets the counter party Filing Status.
	 *
	 * @return the counter party Filing Status
	 */
	public String getCfs() {
		return cfs;
	}

	/**
	 * Sets the counter party Filing Status.
	 *
	 * @param cfs
	 *            the new counter party Filing Status
	 */
	public void setCfs(String cfs) {
		this.cfs = cfs;
	}

}
