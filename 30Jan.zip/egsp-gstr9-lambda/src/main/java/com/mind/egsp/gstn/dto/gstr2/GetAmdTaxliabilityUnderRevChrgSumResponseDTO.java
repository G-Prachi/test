package com.mind.egsp.gstn.dto.gstr2;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr2.AmendedTaxliabilityDetail;

/**
 * The Class GetAmdTaxliabilityUnderRevChrgSumResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetAmdTaxliabilityUnderRevChrgSumResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The amended tax liability details. */
	@JsonProperty("atxi")
	private List<AmendedTaxliabilityDetail> amendedTaxliabilityDetails;

	/**
	 * Gets the amended taxliability details.
	 *
	 * @return the amended taxliability details
	 */
	public List<AmendedTaxliabilityDetail> getAmendedTaxliabilityDetails() {
		return amendedTaxliabilityDetails;
	}

	/**
	 * Sets the amended taxliability details.
	 *
	 * @param amendedTaxliabilityDetails
	 *            the new amended taxliability details
	 */
	public void setAmendedTaxliabilityDetails(List<AmendedTaxliabilityDetail> amendedTaxliabilityDetails) {
		this.amendedTaxliabilityDetails = amendedTaxliabilityDetails;
	}

}
