package com.mind.egsp.gstn.dto.gstr8;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr8.Gstr8TcsaInvoicesDetail;

/**
 * The Class Gstr8GetTcsaInvoicesResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Gstr8GetTcsaInvoicesResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The TCSA invoices. */
	@JsonProperty("tcsa")
	private List<Gstr8TcsaInvoicesDetail> tcsaInvoices;

	/**
	 * Gets the tcsa invoices.
	 *
	 * @return the tcsa invoices
	 */
	public List<Gstr8TcsaInvoicesDetail> getTcsaInvoices() {
		return tcsaInvoices;
	}

	/**
	 * Sets the tcsa invoices.
	 *
	 * @param tcsInvoices
	 *            the new tcsa invoices
	 */
	public void setTcsaInvoices(List<Gstr8TcsaInvoicesDetail> tcsaInvoices) {
		this.tcsaInvoices = tcsaInvoices;
	}

}
