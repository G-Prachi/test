package com.mind.egsp.gstn.model.gstr1;

import java.io.Serializable;
import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Class NilSupplyData.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class NilSupplyData implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The nil Total Nil rated outward supplies. */
	@JsonProperty("nil_amt")
	private BigDecimal nilAmt;

	/** The Total Exempted outward supplies. */
	@JsonProperty("expt_amt")
	private BigDecimal exptAmt;

	/** The Total Non GST outward supplies. */
	@JsonProperty("ngsup_amt")
	private BigDecimal ngsupAmt;

	/** The Nature of Supply Type. */
	@JsonProperty("sply_ty")
	private String splyTy;

	/**
	 * Gets the Total Nil rated outward supplies.
	 *
	 * Field Specification:Decimal(15,2)
	 *
	 * @return the nil amt
	 */
	public BigDecimal getNilAmt() {
		return nilAmt;
	}

	/**
	 * Sets the Total Nil rated outward supplies.
	 *
	 * Field Specification:Decimal(15,2)
	 *
	 * @param nilAmt
	 *            the new nil amt
	 */
	public void setNilAmt(BigDecimal nilAmt) {
		this.nilAmt = nilAmt;
	}

	/**
	 * Gets the Total Exempted outward supplies.
	 *
	 * Field Specification:Decimal(15,2)
	 *
	 * @return the expt amt
	 */
	public BigDecimal getExptAmt() {
		return exptAmt;
	}

	/**
	 * Sets the Total Exempted outward supplies.
	 *
	 * Field Specification:Decimal(15,2)
	 *
	 * @param exptAmt
	 *            the new expt amt
	 */
	public void setExptAmt(BigDecimal exptAmt) {
		this.exptAmt = exptAmt;
	}

	/**
	 * Gets the Total Non GST outward supplies.
	 *
	 * Field Specification:Decimal(15,2)
	 *
	 * @return the ngsup amt
	 */
	public BigDecimal getNgsupAmt() {
		return ngsupAmt;
	}

	/**
	 * Sets the Total Non GST outward supplies.
	 *
	 * Field Specification:Decimal(15,2)
	 *
	 * @param ngsupAmt
	 *            the new ngsup amt
	 */
	public void setNgsupAmt(BigDecimal ngsupAmt) {
		this.ngsupAmt = ngsupAmt;
	}

	/**
	 * Gets the Nature of Supply Type.
	 *
	 * Field Specification:String (Length - 8)
	 *
	 * @return the sply ty
	 */
	public String getSplyTy() {
		return splyTy;
	}

	/**
	 * Sets the Nature of Supply Type.
	 *
	 * Field Specification:String (Length - 8)
	 *
	 * Sample Value:INTRB2B / INTRB2C / INTRAB2B / INTRAB2C
	 *
	 * @param splyTy
	 *            the new sply ty
	 */
	public void setSplyTy(String splyTy) {
		this.splyTy = splyTy;
	}
	
	public String toString(){
		StringBuilder builder = new StringBuilder();
		
		builder.append("inv=");
		if (exptAmt != null) {
			builder.append("expt_amt=");
			builder.append(exptAmt);	
			builder.append(",");	
		}
		if (ngsupAmt != null) {
			builder.append("ngsup_amt=");
			builder.append(ngsupAmt);	
			builder.append(",");	
		}
		if (nilAmt != null) {
			builder.append("nil_amt=");
			builder.append(nilAmt);	
			builder.append(",");	
		}
		if (splyTy != null) {
			builder.append("sply_ty=");
			builder.append(splyTy);	
			builder.append(",");	
		}
		if(builder.length() > 1) {
			if (builder.charAt(builder.length() - 1) == ',') {
			builder.setLength(builder.length() - 1);
			}
		}
		return builder.toString(); 
		}


}
