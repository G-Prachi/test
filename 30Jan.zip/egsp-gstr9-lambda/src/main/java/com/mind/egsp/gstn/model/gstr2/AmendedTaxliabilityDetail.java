package com.mind.egsp.gstn.model.gstr2;

import java.io.Serializable;
import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Class AmendedTaxliabilityDetail.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class AmendedTaxliabilityDetail extends TaxliabilityDetail implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The Original Reg Type .
	 */
	@JsonProperty("oreg_type")
	private String oregType;

	/**
	 * The Original Name of Recepient .
	 */
	private String ocpty;

	/**
	 * The Original  Supplier Document Number .
	 */
	private String odnum;

	/**
	 * The Original  Supplier Document Date .
	 */
	private String otdt;

	/** The Total IGST. */
	private BigDecimal iamt;

	/** The Total CGST. */
	private BigDecimal camt;

	/** The Total SGST. */
	private BigDecimal samt;

	/** The Total Cess. */
	private BigDecimal csamt;

	/**
	 * Gets the Original Reg Type Field Specification: String Sample Data:
	 * "REGD/UNREGD" .
	 *
	 * @return the oreg type
	 */
	public String getOregType() {
		return oregType;
	}

	/**
	 * Sets the Original Reg Type Field Specification: String Sample Data:
	 * "REGD/UNREGD" .
	 *
	 * @param oregType
	 *            the new oreg type
	 */
	public void setOregType(String oregType) {
		this.oregType = oregType;
	}

	/**
	 * Gets the Original Name of Recepient Field Specification: string(Max
	 * length :30) Sample Data: ABC125245123412 .
	 *
	 * @return the ocpty
	 */
	public String getOcpty() {
		return ocpty;
	}

	/**
	 * Sets the Original Name of Recepient Field Specification: string(Max
	 * length :30) Sample Data: ABC125245123412 .
	 *
	 * @param ocpty
	 *            the new ocpty
	 */
	public void setOcpty(String ocpty) {
		this.ocpty = ocpty;
	}

	/**
	 * Gets the Original  Supplier Document Number Field Specification:
	 * Alphanumeric (Max length:10) Sample Data: A100052 .
	 *
	 * @return the odnum
	 */
	public String getOdnum() {
		return odnum;
	}

	/**
	 * Sets the Original  Supplier Document Number Field Specification:
	 * Alphanumeric (Max length:10) Sample Data: A100052 .
	 *
	 * @param odnum
	 *            the new odnum
	 */
	public void setOdnum(String odnum) {
		this.odnum = odnum;
	}

	/**
	 * Gets the Original  Supplier Document Date Field Specification: string
	 * (DD-MM-YYYY) Sample Data: 20-05-2016 .
	 *
	 * @return the otdt
	 */
	public String getOtdt() {
		return otdt;
	}

	/**
	 * Sets the Original  Supplier Document Date Field Specification: string
	 * (DD-MM-YYYY) Sample Data: 20-05-2016 .
	 *
	 * @param otdt
	 *            the new otdt
	 */
	public void setOtdt(String otdt) {
		this.otdt = otdt;
	}

	/**
	 * Gets the Total IGST.
	 *
	 * @return the Total IGST
	 */
	public BigDecimal getIamt() {
		return iamt;
	}

	/**
	 * Sets the Total IGST.
	 *
	 * @param iamt
	 *            the new Total IGST
	 */
	public void setIamt(BigDecimal iamt) {
		this.iamt = iamt;
	}

	/**
	 * Gets the Total CGST.
	 *
	 * @return the Total CGST
	 */
	public BigDecimal getCamt() {
		return camt;
	}

	/**
	 * Sets the Total CGST.
	 *
	 * @param camt
	 *            the new Total CGST
	 */
	public void setCamt(BigDecimal camt) {
		this.camt = camt;
	}

	/**
	 * Gets the Total SGST.
	 *
	 * @return the Total SGST
	 */
	public BigDecimal getSamt() {
		return samt;
	}

	/**
	 * Sets the Total SGST.
	 *
	 * @param samt
	 *            the new Total SGST
	 */
	public void setSamt(BigDecimal samt) {
		this.samt = samt;
	}

	/**
	 * Gets the Total Cess.
	 *
	 * @return the Total Cess
	 */
	public BigDecimal getCsamt() {
		return csamt;
	}

	/**
	 * Sets the Total Cess.
	 *
	 * @param csamt
	 *            the new Total Cess
	 */
	public void setCsamt(BigDecimal csamt) {
		this.csamt = csamt;
	}

}
