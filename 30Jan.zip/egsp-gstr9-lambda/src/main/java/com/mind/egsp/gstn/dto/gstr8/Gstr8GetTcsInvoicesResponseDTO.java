package com.mind.egsp.gstn.dto.gstr8;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr8.Gstr8TcsInvoicesDetail;

/**
 * The Class Gstr8GetTcsInvoicesResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Gstr8GetTcsInvoicesResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The TCS invoices. */
	@JsonProperty("tcs")
	private List<Gstr8TcsInvoicesDetail> tcsInvoices;

	/**
	 * Gets the tcs invoices.
	 *
	 * @return the tcs invoices
	 */
	public List<Gstr8TcsInvoicesDetail> getTcsInvoices() {
		return tcsInvoices;
	}

	/**
	 * Sets the tcs invoices.
	 *
	 * @param tcsInvoices
	 *            the new tcs invoices
	 */
	public void setTcsInvoices(List<Gstr8TcsInvoicesDetail> tcsInvoices) {
		this.tcsInvoices = tcsInvoices;
	}

}
