package com.mind.egsp.gstn.model.all;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Class ViewTrackReturnsDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class ViewTrackReturnsDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The ARN Number generated after filing. */
	private String arn;

	/** The Tax Period Selected by user. */
	@JsonProperty("ret_prd")
	private String returnPeriod;
	
	/** The Mode of Filing(OFFLINE/ONLINE). */
	@JsonProperty("mof")
	private String modeOfFiling;
	
	/** The Date of Filing. */
	@JsonProperty("dof")
	private String dateOfFiling;
	
	/** The Return Type. */
	@JsonProperty("rtntype")
	private String returnType;
	
	/** The Status of the Return filed. */
	private String status;
	
	/** The Is Return Valid/Invalid ?. */
	private Character valid;

	/**
	 * Gets the ARN Number generated after filing.
	 * Field Specifications: Alphanumeric (Max length:25)
	 * Sample Value: AA010143556587A
	 *
	 * @return the arn
	 */
	public String getArn() {
		return arn;
	}

	/**
	 * Sets the arn.
	 *
	 * @param arn the new arn
	 */
	public void setArn(String arn) {
		this.arn = arn;
	}

	/**
	 * Gets the Tax Period Selected by user.
	 * Field Specifications: String(MMyyyy)
	 * Sample Value: 022017
	 *
	 * @return the return period
	 */
	public String getReturnPeriod() {
		return returnPeriod;
	}

	/**
	 * Sets the return period.
	 *
	 * @param returnPeriod the new return period
	 */
	public void setReturnPeriod(String returnPeriod) {
		this.returnPeriod = returnPeriod;
	}

	/**
	 * Gets the Mode of Filing(OFFLINE/ONLINE).
	 * Field Specifications: String(10 Character)
	 * Sample Value: ONLINE
	 *
	 * @return the mode of filing
	 */
	public String getModeOfFiling() {
		return modeOfFiling;
	}

	/**
	 * Sets the mode of filing.
	 *
	 * @param modeOfFiling the new mode of filing
	 */
	public void setModeOfFiling(String modeOfFiling) {
		this.modeOfFiling = modeOfFiling;
	}

	/**
	 * Gets the date of filing.
	 * Field Specifications: String(dd-MM-yyyy)
	 * Sample Value: 08-02-2017
	 *
	 * @return the date of filing
	 */
	public String getDateOfFiling() {
		return dateOfFiling;
	}

	/**
	 * Sets the date of filing.
	 *
	 * @param dateOfFiling the new date of filing
	 */
	public void setDateOfFiling(String dateOfFiling) {
		this.dateOfFiling = dateOfFiling;
	}

	/**
	 * Gets the return type.
	 * Field Specifications: String
	 * Sample Value: GSTR1
	 *
	 * @return the return type
	 */
	public String getReturnType() {
		return returnType;
	}

	/**
	 * Sets the return type.
	 *
	 * @param returnType the new return type
	 */
	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}

	/**
	 * Gets the Status of the Return filed.
	 * Field Specifications: String(10 Character)
	 * Sample Value: Filed
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets the Is Return Valid/Invalid?.
	 * Field Specifications: 1 Character
	 * Sample Value: Y/N
	 *
	 * @return the valid
	 */
	public Character getValid() {
		return valid;
	}

	/**
	 * Sets the valid.
	 *
	 * @param valid the new valid
	 */
	public void setValid(Character valid) {
		this.valid = valid;
	}
	
}
