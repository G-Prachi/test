package com.mind.egsp.gstn.dto.gstr2;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr2.Gstr2HsnSummary;

/**
 * The Class GetHsnSummaryOfInwardSuppliesResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetHsnSummaryOfInwardSuppliesResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The tax paid under reverse charge list. */

	@JsonProperty("hsnsum")
	private List<Gstr2HsnSummary> hsnSummaryDetails;

	/**
	 * Gets the hsn summary details.
	 *
	 * @return the hsn summary details
	 */
	public List<Gstr2HsnSummary> getHsnSummaryDetails() {
		return hsnSummaryDetails;
	}

	/**
	 * Sets the hsn summary details.
	 *
	 * @param hsnSummaryDetails
	 *            the new hsn summary details
	 */
	public void setHsnSummaryDetails(List<Gstr2HsnSummary> hsnSummaryDetails) {
		this.hsnSummaryDetails = hsnSummaryDetails;
	}

}
