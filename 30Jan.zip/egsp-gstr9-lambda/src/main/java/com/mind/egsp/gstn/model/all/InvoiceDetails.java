package com.mind.egsp.gstn.model.all;

import java.io.Serializable;
import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Class InvoiceDetails.
 */
public class InvoiceDetails implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The Payment Date .
	 */
	@JsonProperty("pymtDt")
	private String pymt_dt;

	/**
	 * The IGST amount .
	 */
	private BigDecimal igst;

	/**
	 * The CGST amount .
	 */
	private BigDecimal cgst;

	/**
	 * The SGST amount .
	 */
	private BigDecimal sgst;

	/**
	 * The additional tax amount .
	 */
	private BigDecimal atx;

	/**
	 * Gets the Payment Date Field Specification: DD_MM-YYY Sample Data: A10008
	 * .
	 *
	 * @return the pymt dt
	 */
	public String getPymt_dt() {
		return pymt_dt;
	}

	/**
	 * Sets the Payment Date Field Specification: DD_MM-YYY Sample Data: A10008
	 * .
	 *
	 * @param pymt_dt
	 *            the new pymt dt
	 */
	public void setPymt_dt(String pymt_dt) {
		this.pymt_dt = pymt_dt;
	}

	/**
	 * Gets the IGST amount Field Specification: Decimal(p,2) Sample Data:
	 * 08-09-2016 .
	 *
	 * @return the igst
	 */
	public BigDecimal getIgst() {
		return igst;
	}

	/**
	 * Sets the IGST amount Field Specification: Decimal(p,2) Sample Data:
	 * 08-09-2016 .
	 *
	 * @param igst
	 *            the new igst
	 */
	public void setIgst(BigDecimal igst) {
		this.igst = igst;
	}

	/**
	 * Gets the CGST amount Field Specification: Decimal(p,2) Sample Data: 3456
	 * .
	 *
	 * @return the cgst
	 */
	public BigDecimal getCgst() {
		return cgst;
	}

	/**
	 * Sets the CGST amount Field Specification: Decimal(p,2) Sample Data: 3456
	 * .
	 *
	 * @param cgst
	 *            the new cgst
	 */
	public void setCgst(BigDecimal cgst) {
		this.cgst = cgst;
	}

	/**
	 * Gets the SGST amount Field Specification: Decimal(p,2) Sample Data: 1200
	 * .
	 *
	 * @return the sgst
	 */
	public BigDecimal getSgst() {
		return sgst;
	}

	/**
	 * Sets the SGST amount Field Specification: Decimal(p,2) Sample Data: 1200
	 * .
	 *
	 * @param sgst
	 *            the new sgst
	 */
	public void setSgst(BigDecimal sgst) {
		this.sgst = sgst;
	}

	/**
	 * Gets the additional tax amount Field Specification: Decimal(p,2) Sample
	 * Data: 8000 .
	 *
	 * @return the atx
	 */
	public BigDecimal getAtx() {
		return atx;
	}

	/**
	 * Sets the additional tax amount Field Specification: Decimal(p,2) Sample
	 * Data: 8000 .
	 *
	 * @param atx
	 *            the new atx
	 */
	public void setAtx(BigDecimal atx) {
		this.atx = atx;
	}

}
