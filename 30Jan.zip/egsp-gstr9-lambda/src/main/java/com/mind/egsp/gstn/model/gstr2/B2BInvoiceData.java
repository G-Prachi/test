package com.mind.egsp.gstn.model.gstr2;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Class B2BInvoiceData.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class B2BInvoiceData implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The list of B 2 B invoices. */
	@JsonProperty("b2b")
	private List<Gstr2B2bInvoice> listOfB2BInvoices;

	/**
	 * Gets the list of B 2 B invoices.
	 *
	 * @return the list of B 2 B invoices
	 */
	public List<Gstr2B2bInvoice> getListOfB2BInvoices() {
		return listOfB2BInvoices;
	}

	/**
	 * Sets the list of B 2 B invoices.
	 *
	 * @param listOfB2BInvoices
	 *            the new list of B 2 B invoices
	 */
	public void setListOfB2BInvoices(List<Gstr2B2bInvoice> listOfB2BInvoices) {
		this.listOfB2BInvoices = listOfB2BInvoices;
	}

}
