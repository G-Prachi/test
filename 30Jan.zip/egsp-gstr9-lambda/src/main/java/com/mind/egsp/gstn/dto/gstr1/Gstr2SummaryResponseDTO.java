package com.mind.egsp.gstn.dto.gstr1;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr2.Gstr2SummaryData;

/**
 * The Gstr1 Summary Response DTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Gstr2SummaryResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** Invoice Check sum value. */
	private Gstr2SummaryData gstr2SummaryData;

	/**
	 * Gets the gstr 2 summary data.
	 *
	 * @return the gstr 2 summary data
	 */
	public Gstr2SummaryData getGstr2SummaryData() {
		return gstr2SummaryData;
	}

	/**
	 * Sets the gstr 2 summary data.
	 *
	 * @param gstr2SummaryData
	 *            the new gstr 2 summary data
	 */
	public void setGstr2SummaryData(Gstr2SummaryData gstr2SummaryData) {
		this.gstr2SummaryData = gstr2SummaryData;
	}

}
