package com.mind.egsp.gstn.dto.gstr2;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseResponseDTO;

/**
 * The Class GetISDCreditResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetISDCreditResponseDTO extends BaseResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The Invoice Check sum value .
	 */
	private String chksum;

	/**
	 * The Supplier GSTIN_ISD .
	 */
	@JsonProperty("gstin_isd")
	private String gstinIsd;

	/**
	 * The Invoice/Document detail number .
	 */
	@JsonProperty("i_num")
	private String iNum;

	/**
	 * The Invoice/Document detail date .
	 */
	@JsonProperty("i_dt")
	private String iDt;

	/**
	 * The ISD Credit (IGST) .
	 */
	@JsonProperty("ig_cr")
	private String igCr;

	/**
	 * The ISD Credit (CGST) .
	 */
	@JsonProperty("cg_cr")
	private String cgCr;

	/**
	 * The ISD Credit (SGST) .
	 */
	@JsonProperty("sg_cr")
	private String sgCr;

	/**
	 * Gets the Invoice Check sum value Field Specification: string(Max
	 * length:15) Sample Data: AflJufPlFStqKBZ .
	 *
	 * @return the chksum
	 */
	public String getChksum() {
		return chksum;
	}

	/**
	 * Sets the Invoice Check sum value Field Specification: string(Max
	 * length:15) Sample Data: AflJufPlFStqKBZ .
	 *
	 * @param chksum
	 *            the new chksum
	 */
	public void setChksum(String chksum) {
		this.chksum = chksum;
	}

	/**
	 * Gets the Supplier GSTIN_ISD Field Specification: Alphanumeric with 15
	 * characters Sample Data: 02DDDFP3434S2Z3 .
	 *
	 * @return the gstin isd
	 */
	public String getGstinIsd() {
		return gstinIsd;
	}

	/**
	 * Sets the Supplier GSTIN_ISD Field Specification: Alphanumeric with 15
	 * characters Sample Data: 02DDDFP3434S2Z3 .
	 *
	 * @param gstinIsd
	 *            the new gstin isd
	 */
	public void setGstinIsd(String gstinIsd) {
		this.gstinIsd = gstinIsd;
	}

	/**
	 * Gets the Invoice/Document detail number Field Specification: Alphanumeric
	 * (Max length:50) Sample Data: 85619 .
	 *
	 * @return the i num
	 */
	public String getiNum() {
		return iNum;
	}

	/**
	 * Sets the Invoice/Document detail number Field Specification: Alphanumeric
	 * (Max length:50) Sample Data: 85619 .
	 *
	 * @param iNum
	 *            the new i num
	 */
	public void setiNum(String iNum) {
		this.iNum = iNum;
	}

	/**
	 * Gets the Invoice/Document detail date Field Specification: string
	 * (DD-MM-YYYY) Sample Data: 22-3-2016 .
	 *
	 * @return the i dt
	 */
	public String getiDt() {
		return iDt;
	}

	/**
	 * Sets the Invoice/Document detail date Field Specification: string
	 * (DD-MM-YYYY) Sample Data: 22-3-2016 .
	 *
	 * @param iDt
	 *            the new i dt
	 */
	public void setiDt(String iDt) {
		this.iDt = iDt;
	}

	/**
	 * Gets the ISD Credit (IGST) Field Specification: Decimal(p,2) Sample Data:
	 * 0.00 .
	 *
	 * @return the ig cr
	 */
	public String getIgCr() {
		return igCr;
	}

	/**
	 * Sets the ISD Credit (IGST) Field Specification: Decimal(p,2) Sample Data:
	 * 0.00 .
	 *
	 * @param igCr
	 *            the new ig cr
	 */
	public void setIgCr(String igCr) {
		this.igCr = igCr;
	}

	/**
	 * Gets the ISD Credit (CGST) Field Specification: Decimal(p,2) Sample Data:
	 * 682.88 .
	 *
	 * @return the cg cr
	 */
	public String getCgCr() {
		return cgCr;
	}

	/**
	 * Sets the ISD Credit (CGST) Field Specification: Decimal(p,2) Sample Data:
	 * 682.88 .
	 *
	 * @param cgCr
	 *            the new cg cr
	 */
	public void setCgCr(String cgCr) {
		this.cgCr = cgCr;
	}

	/**
	 * Gets the ISD Credit (SGST) Field Specification: Decimal(p,2) Sample Data:
	 * 582.88 .
	 *
	 * @return the sg cr
	 */
	public String getSgCr() {
		return sgCr;
	}

	/**
	 * Sets the ISD Credit (SGST) Field Specification: Decimal(p,2) Sample Data:
	 * 582.88 .
	 *
	 * @param sgCr
	 *            the new sg cr
	 */
	public void setSgCr(String sgCr) {
		this.sgCr = sgCr;
	}

}
