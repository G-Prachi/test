package com.mind.egsp.gstn.dto.gstr9;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr9.Gstr9AutocalculatedDetails;

/**
 * The Class Gstr9GetAutocalculatedDetailsResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Gstr9GetAutocalculatedDetailsResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The autocalculated details. */
	@JsonIgnore
	private Gstr9AutocalculatedDetails autocalculatedDetails;

	/**
	 * Gets the autocalculated details.
	 *
	 * @return the autocalculated details
	 */
	public Gstr9AutocalculatedDetails getAutocalculatedDetails() {
		return autocalculatedDetails;
	}

	/**
	 * Sets the autocalculated details.
	 *
	 * @param autocalculatedDetails the new autocalculated details
	 */
	public void setAutocalculatedDetails(Gstr9AutocalculatedDetails autocalculatedDetails) {
		this.autocalculatedDetails = autocalculatedDetails;
	}
	
	
	
}
