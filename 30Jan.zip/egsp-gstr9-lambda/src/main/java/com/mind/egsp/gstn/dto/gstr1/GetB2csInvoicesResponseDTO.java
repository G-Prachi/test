package com.mind.egsp.gstn.dto.gstr1;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr1.B2csInvoice;

// TODO: Auto-generated Javadoc
/**
 * The Class GetB2csInvoicesResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetB2csInvoicesResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The B2CS invoice detail. */
	@JsonProperty("b2cs")
	private List<B2csInvoice> b2csInvoices;

	/**
	 * Gets the B2CS invoices.
	 *
	 * @return the B2CS invoices
	 */
	public List<B2csInvoice> getB2csInvoices() {
		return b2csInvoices;
	}

	/**
	 * Sets the B2CS invoices.
	 *
	 * @param b2csInvoices
	 *            the new B2CS invoices
	 */
	public void setB2csInvoices(List<B2csInvoice> b2csInvoices) {
		this.b2csInvoices = b2csInvoices;
	}

}
