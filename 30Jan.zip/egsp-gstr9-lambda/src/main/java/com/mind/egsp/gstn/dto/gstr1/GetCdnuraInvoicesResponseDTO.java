package com.mind.egsp.gstn.dto.gstr1;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr1.CdnuraInvoiceDetail;

/**
 * The Class GetCdnuraInvoicesResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetCdnuraInvoicesResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Credit Debit Note Ammend details. */
	@JsonProperty("cdnura")
	private List<CdnuraInvoiceDetail> cdnuraInvoiceDetails;

	public List<CdnuraInvoiceDetail> getCdnuraInvoiceDetails() {
		return cdnuraInvoiceDetails;
	}

	public void setCdnuraInvoiceDetails(List<CdnuraInvoiceDetail> cdnuraInvoiceDetails) {
		this.cdnuraInvoiceDetails = cdnuraInvoiceDetails;
	}

}
