package com.mind.egsp.gstn.dto.gstr2;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseResponseDTO;
import com.mind.egsp.gstn.model.gstr2.TdsCreditDataList;

/**
 * The Class GetTdsCreditResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class GetTdsCreditResponseDTO extends BaseResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The tds credit data list. */
	@JsonProperty("tds_credit")
	private List<TdsCreditDataList> tdsCreditDataList;

	/**
	 * Gets the tds credit data list.
	 *
	 * @return the tds credit data list
	 */
	public List<TdsCreditDataList> getTdsCreditDataList() {
		return tdsCreditDataList;
	}

	/**
	 * Sets the tds credit data list.
	 *
	 * @param tdsCreditDataList
	 *            the new tds credit data list
	 */
	public void setTdsCreditDataList(List<TdsCreditDataList> tdsCreditDataList) {
		this.tdsCreditDataList = tdsCreditDataList;
	}

}
