
package com.mind.egsp.gstn.model.gstr1;
import java.util.Comparator;
import com.mind.egsp.gstn.model.gstr1.ExpItemDetail;

public class ExpItemDetailsComparator implements Comparator<ExpItemDetail> {
//	@Override
	public int compare(ExpItemDetail item1, ExpItemDetail item2) {
/*		if(item1.getNum()<item2.getNum())
			return -1;
		else if(item1.getNum()>item2.getNum())
			return 1;
*/
		return 0;
	}
}