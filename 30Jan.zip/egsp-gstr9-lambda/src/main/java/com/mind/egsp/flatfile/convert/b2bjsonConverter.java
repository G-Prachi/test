package com.mind.egsp.flatfile.convert;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.journaldev.jackson.json.JacksonObjectMapperExample;
import com.mind.egsp.gstn.dto.gstr1.SaveGstr1DTO;
import com.mind.egsp.gstn.model.gstr1.B2bInvoice;
import com.mind.egsp.gstn.model.gstr1.B2bInvoiceDetail;
import com.mind.egsp.gstn.model.gstr1.B2bItem;
import com.mind.egsp.gstn.model.gstr1.B2baInvoice;
import com.mind.egsp.gstn.model.gstr1.*;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.egsp.finalDTOs.*;

public class b2bjsonConverter {

	//	static List<B2bInvoiceDetailFlat> flatB2bDetiallist =  new ArrayList<B2bInvoiceDetailFlat>();		
	//	static List<B2bInvoiceFlat>  flatB2blist = new ArrayList<B2bInvoiceFlat>();
	//	static List<B2bInvoiceFlatFinal> b2bInvFlatFinal = new ArrayList<B2bInvoiceFlatFinal>();

	public static String b2bJsonConverter(SaveGstr1DTO gstriObj,String bucketName,String filePath,String fileName,AmazonS3 s3, String str2)
	{
		//***************************Declaration for B2b*************
		try
		{
			List<B2bInvoiceFlat>  flatB2blist = new ArrayList<B2bInvoiceFlat>();				
			SaveGstr1DTOFlat savedtoflat  = new SaveGstr1DTOFlat();
			//SaveGstr1DTO gstriObj = objectMapper.readValue(jsonData1, SaveGstr1DTO.class);
			savedtoflat.setFp(gstriObj.getFp());
			//B2BInvoice================
			List<B2bInvoice> list = gstriObj.getB2bInvoices();
			List<B2bInvoiceDetailFlat> flatB2bDetiallist = new ArrayList<B2bInvoiceDetailFlat>();

			//System.out.println(list.size() +  "" + list.toString());		
			BigDecimal totaltxval = new BigDecimal(0);
			BigDecimal totaliamt = new BigDecimal(0);;
			BigDecimal totalcamt =new BigDecimal(0);
			BigDecimal totalsamt =new BigDecimal(0);
			BigDecimal totalcsamt = new BigDecimal(0);
			if(list!=null)
			{
				for(B2bInvoice item : list)
				{
					//flatB2bDetiallist = new ArrayList<B2bInvoiceDetailFlat>();
					B2bInvoiceFlat b2bflat = new B2bInvoiceFlat();
					b2bflat.setCtin(item.getCtin());
					for(B2bInvoiceDetail invDetail : item.getB2bInvoiceDetails()) {
						B2bInvoiceDetailFlat b2bInvoiceDetailFLat = new B2bInvoiceDetailFlat();
						b2bInvoiceDetailFLat.setInum(invDetail.getInum());
						b2bflat.setRchrg(invDetail.getRchrg());
						b2bflat.setInvTyp(invDetail.getInvTyp());
						b2bflat.setVal(invDetail.getVal());
						b2bInvoiceDetailFLat.setIdt(invDetail.getIdt());

						for (B2bItem item1 :invDetail.getB2bItems()){
							totaltxval = totaltxval.add(item1.getB2bItemDetail().getTxval());
							totaliamt = totaliamt.add(item1.getB2bItemDetail().getIamt());
							totalcamt = totalcamt.add(item1.getB2bItemDetail().getCamt());
							totalsamt = totalsamt.add(item1.getB2bItemDetail().getSamt());
							totalcsamt = totalcsamt.add(item1.getB2bItemDetail().getCsamt());
						}
						b2bInvoiceDetailFLat.setTotaltxval(totaltxval);
						b2bInvoiceDetailFLat.setTotaliamt(totaliamt);
						b2bInvoiceDetailFLat.setTotalcamt(totalcamt);
						b2bInvoiceDetailFLat.setTotalcsamt(totalcsamt);
						b2bInvoiceDetailFLat.setTotalsamt(totalsamt);
						flatB2bDetiallist.add(b2bInvoiceDetailFLat);
					}
					b2bflat.setB2bInvoiceDetailFLat(flatB2bDetiallist);
					flatB2blist.add(b2bflat);
				}
				//				System.out.println("flatB2blist "+flatB2blist);
				List<B2bInvoiceFlatFinal> b2bfinalList = new ArrayList<B2bInvoiceFlatFinal>();
				for(B2bInvoiceFlat flatList : flatB2blist)
				{
					for(B2bInvoiceDetailFlat b2bInvoiceFlat : flatList.getB2bInvoiceDetailFLat()) {
						B2bInvoiceFlatFinal b2bInvoiceFlatFinal = new B2bInvoiceFlatFinal();
						b2bInvoiceFlatFinal.setFp(gstriObj.getFp());
						b2bInvoiceFlatFinal.setBusinessType("b2b");
						b2bInvoiceFlatFinal.setCtin(flatList.getCtin());
						//b2bInvoiceFlatFinal.setRchrg(flatList.getRchrg());
						b2bInvoiceFlatFinal.setInvTyp(flatList.getInvTyp());
						b2bInvoiceFlatFinal.setVal(flatList.getVal());
						b2bInvoiceFlatFinal.setInum(b2bInvoiceFlat.getInum());
						b2bInvoiceFlatFinal.setIdt(b2bInvoiceFlat.getIdt());
						b2bInvoiceFlatFinal.setTotalcamt(b2bInvoiceFlat.getTotalcamt());
						b2bInvoiceFlatFinal.setTotalcsamt(b2bInvoiceFlat.getTotalcsamt());
						b2bInvoiceFlatFinal.setTotaliamt(b2bInvoiceFlat.getTotaliamt());
						b2bInvoiceFlatFinal.setTotalsamt(b2bInvoiceFlat.getTotalsamt());
						b2bInvoiceFlatFinal.setTotaltxval(b2bInvoiceFlat.getTotaltxval());
						b2bfinalList.add(b2bInvoiceFlatFinal);
					}
				}
				final ByteArrayOutputStream out = new ByteArrayOutputStream();
				final ObjectMapper mapper = new ObjectMapper();

				mapper.writeValue(out, b2bfinalList);
		        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		        StringBuilder tempFile = new StringBuilder();
		        Random rnd = new Random();
		        while (tempFile.length() < 18) { // length of the random string.
		            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
		            tempFile.append(SALTCHARS.charAt(index));
		        }
		        String tempFil = tempFile.toString();
		        File tempFileName = new File(tempFil+".json");
		        //return saltStr;
				mapper.writeValue(tempFileName, b2bfinalList);
				InputStream is = new FileInputStream(tempFileName);
				String contents = new BufferedReader(new InputStreamReader(is)).readLine();
				is.close(); 
				
					String str = contents.substring(1, contents.length()-1);
					String str1=str.replaceAll("},", "}\n");
					System.out.println(str1);
					System.out.println("sucess b2b");
					str2= str2.concat(str1);
					return(str2);
					/*PrintWriter pr = new PrintWriter(new BufferedWriter(new FileWriter(new File(fileName), true)));
					pr.write(str1);
					pr.append("\n");
					pr.close();
					s3.putObject(bucketName, filePath+"/"+fileName, str1);*/
					
					//s3.putObject(new PutObjectRequest(bucketName, filePath+"/"+fileName, fileName));
				}
				

			
		}catch(Exception ex)
		{

		}
		return (str2);
	}
	
}






