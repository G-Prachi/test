package com.mind.egsp.gstn.model.all;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.model.gstr1.TxpdItemDetail;

// TODO: Auto-generated Javadoc
/**
 * The Class TXPDErrorReport.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class TXPDErrorReport implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The Error Message .
	 */
	@JsonProperty("error_msg")
	private String errorMsg;

	/**
	 * The Error_cd .
	 */
	@JsonProperty("error_cd")
	private String errorCd;

	/** The Place of Supply. */
	private String pos;

	/** The Supply Type. */
	@JsonProperty("sply_ty")
	private String splyTy;

	/**
	 * The TXPD Invoice List .
	 */
	@JsonProperty("itms")
	private List<TxpdItemDetail> txpdItemDetails;

	/**
	 * Gets the error msg.
	 *
	 * @return the error msg
	 */
	public String getErrorMsg() {
		return errorMsg;
	}

	/**
	 * Sets the error msg.
	 *
	 * @param errorMsg
	 *            the new error msg
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	/**
	 * Gets the error cd.
	 *
	 * @return the error cd
	 */
	public String getErrorCd() {
		return errorCd;
	}

	/**
	 * Sets the error cd.
	 *
	 * @param errorCd
	 *            the new error cd
	 */
	public void setErrorCd(String errorCd) {
		this.errorCd = errorCd;
	}

	/**
	 * Gets the txpd item details.
	 *
	 * @return the txpd item details
	 */
	public List<TxpdItemDetail> getTxpdItemDetails() {
		return txpdItemDetails;
	}

	/**
	 * Sets the txpd item details.
	 *
	 * @param txpdItemDetails
	 *            the new txpd item details
	 */
	public void setTxpdItemDetails(List<TxpdItemDetail> txpdItemDetails) {
		this.txpdItemDetails = txpdItemDetails;
	}

	/**
	 * Gets the pos.
	 *
	 * @return the pos
	 */
	public String getPos() {
		return pos;
	}

	/**
	 * Sets the pos.
	 *
	 * @param pos
	 *            the new pos
	 */
	public void setPos(String pos) {
		this.pos = pos;
	}

	/**
	 * Gets the sply ty.
	 *
	 * @return the sply ty
	 */
	public String getSplyTy() {
		return splyTy;
	}

	/**
	 * Sets the sply ty.
	 *
	 * @param splyTy
	 *            the new sply ty
	 */
	public void setSplyTy(String splyTy) {
		this.splyTy = splyTy;
	}

}
