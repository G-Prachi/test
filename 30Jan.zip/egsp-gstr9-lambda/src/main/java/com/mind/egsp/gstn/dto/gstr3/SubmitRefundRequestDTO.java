package com.mind.egsp.gstn.dto.gstr3;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseRequestDTO;

/**
 * The Class SubmitGSTR3RefundRequestDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)

public class SubmitRefundRequestDTO extends BaseRequestDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The submit GSTR 3 refund DTO. */
	@JsonProperty("data")
	private SubmitRefundDTO submitGSTR3RefundDTO;

	/**
	 * Instantiates a new submit GSTR 3 refund request DTO.
	 *
	 * @param stateCd
	 *            the state cd
	 * @param ipUsr
	 *            the ip usr
	 * @param txn
	 *            the txn
	 * @param gstin
	 *            the gstin
	 * @param retPeriod
	 *            the ret period
	 * @param username
	 *            the username
	 */
	public SubmitRefundRequestDTO(String stateCd, String ipUsr, String txn, String gstin, String retPeriod,
			String username) {
		super(stateCd, ipUsr, txn, gstin, retPeriod, username);
	}

	/**
	 * Gets the submit GSTR 3 refund DTO.
	 *
	 * @return the submit GSTR 3 refund DTO
	 */
	public SubmitRefundDTO getSubmitGSTR3RefundDTO() {
		return submitGSTR3RefundDTO;
	}

	/**
	 * Sets the submit GSTR 3 refund DTO.
	 *
	 * @param submitGSTR3RefundDTO
	 *            the new submit GSTR 3 refund DTO
	 */
	public void setSubmitGSTR3RefundDTO(SubmitRefundDTO submitGSTR3RefundDTO) {
		this.submitGSTR3RefundDTO = submitGSTR3RefundDTO;
	}

}
