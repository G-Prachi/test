package com.mind.egsp.gstn.dto.gstr8;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseResponseDTO;

// TODO: Auto-generated Javadoc
/**
 * The Class Gstr8FileResponseDTO.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Gstr8FileResponseDTO extends BaseResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Acknowledgement no. */
	@JsonProperty("ack_num")
	private String ackNum;

	/**
	 * Gets the Acknowledgement no
	 * 
	 * Field Specification: Alphanumeric 15 characters
	 * 
	 * Sample Data: AK12415125235 .
	 *
	 * @return the ack num
	 */
	public String getAckNum() {
		return ackNum;
	}

	/**
	 * Sets the Acknowledgement no
	 * 
	 * Field Specification: Alphanumeric 15 characters
	 * 
	 * Sample Data: AK12415125235 .
	 *
	 * @param ackNum
	 *            the new ack num
	 */
	public void setAckNum(String ackNum) {
		this.ackNum = ackNum;
	}
}
