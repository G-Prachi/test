package com.mind.egsp.gstn.dto.gstr8;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mind.egsp.gstn.dto.BaseDataResponseDTO;
import com.mind.egsp.gstn.model.gstr8.Gstr8B2bInvoice;;

/**
 * Get B2B Invoices Response DTO.
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class Gstr8GetB2bInvoicesResponseDTO extends BaseDataResponseDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The B2B invoices. */
	@JsonProperty("b2b")
	private List<Gstr8B2bInvoice> b2bInvoices;

	/** The Token. */
	private String token;

	/** The Estimated Time in minutes. */
	private String est;

	/**
	 * Gets the B2B invoices.
	 *
	 * @return the B2B invoices
	 */
	public List<Gstr8B2bInvoice> getB2bInvoices() {
		return b2bInvoices;
	}

	/**
	 * Sets the B2B invoices.
	 *
	 * @param b2bInvoices
	 *            the new B2B invoices
	 */
	public void setB2bInvoices(List<Gstr8B2bInvoice> b2bInvoices) {
		this.b2bInvoices = b2bInvoices;
	}

	/**
	 * Gets the token.
	 *
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * Sets the token.
	 *
	 * @param token
	 *            the new token
	 */
	public void setToken(String token) {
		this.token = token;
	}

	/**
	 * Gets the Estimated Time in minutes.
	 *
	 * @return the est
	 */
	public String getEst() {
		return est;
	}

	/**
	 * Sets the Estimated Time in minutes.
	 *
	 * @param est
	 *            the new est
	 */
	public void setEst(String est) {
		this.est = est;
	}

}
