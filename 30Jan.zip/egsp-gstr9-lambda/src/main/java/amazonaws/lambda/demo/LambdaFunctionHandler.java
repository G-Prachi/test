package amazonaws.lambda.demo;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.S3Event;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.event.S3EventNotification.S3EventNotificationRecord;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mind.egsp.flatfile.convert.atajsonConverter;
import com.mind.egsp.flatfile.convert.atjsonConverter;
import com.mind.egsp.flatfile.convert.b2bajsonConverter;
import com.mind.egsp.flatfile.convert.b2bjsonConverter;
import com.mind.egsp.flatfile.convert.b2clajsonConverter;
import com.mind.egsp.flatfile.convert.b2cljsonConverter;
import com.mind.egsp.flatfile.convert.b2csajsonConverter;
import com.mind.egsp.flatfile.convert.b2csjsonConverter;
import com.mind.egsp.flatfile.convert.cdnjsonConverter;
import com.mind.egsp.flatfile.convert.cdnrajasonConverter;
import com.mind.egsp.flatfile.convert.cdnrjsonConverter;
import com.mind.egsp.flatfile.convert.expajsonConverter;
import com.mind.egsp.flatfile.convert.expjsonConverter;
import com.mind.egsp.flatfile.convert.hsnjsonConverter;
import com.mind.egsp.flatfile.convert.txpdajsonConverter;
import com.mind.egsp.flatfile.convert.txpdjsonConverter;
import com.mind.egsp.gstn.dto.gstr1.SaveGstr1DTO;
import com.mind.egsp.gstn.dto.gstr2.SaveGstr2DTO;
import com.mind.egsp.utils.UploadToS3;

public class LambdaFunctionHandler implements RequestHandler<S3Event, String> {

	private AmazonS3 s3 = AmazonS3ClientBuilder.standard().build();
	S3Object response;
	String contentType = "";
	InputStream jsonData = null;
	static final String ATHENA_DB = "gstr9flatjsondb";
	static final String ATHENA_TABLE = "gstr9flatjson";
	static final String athenaUrl = "jdbc:awsathena://athena.ap-south-1.amazonaws.com:443";

	public LambdaFunctionHandler() {
	}

	Connection conn = null;
	Statement statement = null;

	// Test purpose only.
	public LambdaFunctionHandler(AmazonS3 s3) {
		this.s3 = s3;
	}

	@Override
	public String handleRequest(S3Event event, Context context) {
		context.getLogger().log("Received event: " + event);

		// create ObjectMapper instance
		ObjectMapper objectMapper = new ObjectMapper();
		S3EventNotificationRecord record = event.getRecords().get(0);
		String srcBucket = record.getS3().getBucket().getName();
		String srcKey = record.getS3().getObject().getKey().replace('+', ' ');

		try {
			srcKey = URLDecoder.decode(srcKey, "UTF-8");
			System.out.println("Source key is" + srcKey);

		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		BasicAWSCredentials credentials = new BasicAWSCredentials("AKIAJWFHZDOBAG2DCQ6A",
				"QornJdnY6YEGYzO7kg5DeKTtrjt4wpgubcVy3Klq");
		AmazonS3 s3 = AmazonS3ClientBuilder.standard().withCredentials(new AWSStaticCredentialsProvider(credentials))
				.withRegion("ap-south-1").build();

		try {
			String finalFilePath = StringUtils.substringBeforeLast(srcKey, "/");
			String finalFileName = StringUtils.substringAfterLast(srcKey, "/");
			context.getLogger().log("final filepath name: " + finalFilePath);
			context.getLogger().log("final file name " + finalFileName);
			context.getLogger().log("key name: " + srcKey);
			response = s3.getObject(new GetObjectRequest(srcBucket, srcKey));
			contentType = response.getObjectMetadata().getContentType();

			String line = "";
			jsonData = response.getObjectContent();
			System.out.println("Json Data is" + jsonData);
			BufferedReader reader = new BufferedReader(new InputStreamReader(jsonData));
			line = reader.readLine();
			byte[] jsonData1 = line.getBytes();
			context.getLogger().log("line content is " + line);
			SaveGstr1DTO gstriObj = objectMapper.readValue(jsonData1, SaveGstr1DTO.class);
			SaveGstr2DTO gstriObj2 = objectMapper.readValue(jsonData1, SaveGstr2DTO.class);

			String finalBucketName = "gstr9-processed-data";
			context.getLogger().log("BEGIN CONVERTER");
			String str = "";
			// TESTEd

			str = b2bjsonConverter.b2bJsonConverter(gstriObj, finalBucketName, finalFilePath, finalFileName, s3, str);
			context.getLogger().log(str);
			str = b2bajsonConverter.b2bJsonConverter(gstriObj, finalBucketName, finalFilePath, finalFileName, s3, str);
			str = expjsonConverter.expJsonConverter(gstriObj, finalBucketName, finalFilePath, finalFileName, s3, str);
			str = cdnjsonConverter.cdnJsonConverter(gstriObj2, finalBucketName, finalFilePath, finalFileName, s3, str);
			str = expajsonConverter.expaJsonConverter(gstriObj, finalBucketName, finalFilePath, finalFileName, s3, str);

			str = b2csjsonConverter.b2bJsonConverter(gstriObj, finalBucketName, finalFilePath, finalFileName, s3, str);
			str = atjsonConverter.atJsonConverter(gstriObj, finalBucketName, finalFilePath, finalFileName, s3, str);
			str = hsnjsonConverter.hsnJsonConverter(gstriObj, finalBucketName, finalFilePath, finalFileName, s3, str);
			str = atajsonConverter.ataJsonConverter(gstriObj, finalBucketName, finalFilePath, finalFileName, s3, str);
			context.getLogger().log("IN THE CONVERTER");
			// TESTED
			str = b2cljsonConverter.b2bJsonConverter(gstriObj, finalBucketName, finalFilePath, finalFileName, s3, str);
			str = b2clajsonConverter.b2bJsonConverter(gstriObj, finalBucketName, finalFilePath, finalFileName, s3, str);
			str = b2csajsonConverter.b2bJsonConverter(gstriObj, finalBucketName, finalFilePath, finalFileName, s3, str);
			str = cdnrajasonConverter.cdnraJasonConverter(gstriObj, finalBucketName, finalFilePath, finalFileName, s3,
					str);
			// str=cdnurjsonConverter.cdnurJsonConverter(gstriObj, finalBucketName,
			// finalFilePath, finalFileName, s3,str);
			// str=cdnurajsonConverter.cdnrJsonConverter(gstriObj, finalBucketName,
			// finalFilePath, finalFileName, s3,str);
			str = txpdjsonConverter.txpdJsonConverter(gstriObj, finalBucketName, finalFilePath, finalFileName, s3, str);
			str = txpdajsonConverter.txpdaJsonConverter(gstriObj, finalBucketName, finalFilePath, finalFileName, s3,
					str);
			// str = niljsonConverter.b2bJsonConverter(gstriObj, finalBucketName,
			// finalFilePath, finalFileName, s3, str);
			str = cdnrjsonConverter.cdnrJsonConverter(gstriObj, finalBucketName, finalFilePath, finalFileName, s3, str);

			s3.putObject(finalBucketName, finalFilePath + "/" + finalFileName, str);
			String[] couple = finalFilePath.split("/");
			Map<String, String> hm = new HashMap<String, String>();
			for (int i = 0; i < couple.length; i++) {
				String[] items = couple[i].split("=");
				hm.put(items[0], items[1]);
			}
			String build = new StringBuilder().append("return_type=" + hm.get("return_type")).append("/")
					.append("gstin=" + hm.get("gstin")).append("/").append("fin_year=" + hm.get("fin_year")).append("/")
					.append("fin_year_month_Upper=" + hm.get("fin_year_month_Upper")).append("/").toString();
			String timeStampCurrent = hm.get("timestamp");

			System.out.println("My Time Stamp is  " + timeStampCurrent);
			boolean status = UploadToS3.uploadFileToS3(s3, build, timeStampCurrent, finalBucketName);
			System.out.println("Final status for the athena " + status);
			System.out.println("parsing done 1");
			// System.out.println(str);
			// context.getLogger().log("END CONVERTER");
			// System.out.println("END code");
			Long id = gstriObj.getCustomId();
			//////////////////////////////// Postgres Update
			//////////////////////////////// /////////////////////////////////////////////////////////////////////////
			String url = "jdbc:postgresql://egspuat1.c6qmlqzk7usk.ap-south-1.rds.amazonaws.com:5432/egsptest";
			String user = "egspuatadmin";
			String pass = "uategsp1#";
			Connection con = null;
			Statement stmt = null;
			try {
				Class.forName("org.postgresql.Driver");
				con = DriverManager.getConnection(url, user, pass);
				stmt = con.createStatement();

				String query = "UPDATE egsp_gstr9_mon_upload_file SET final_processing_status= 'Y' "
						+ "WHERE initial='Y' AND init_status='uploaded_to_s3' AND sts_id='processed' AND id=" + id;
				int updated = stmt.executeUpdate(query);
				System.out.println("Update rows are  " + updated);
				stmt.close();
				con.close();

			} catch (Exception e) {
				e.printStackTrace();

			}
			System.out.println("Opened database successfully");

			if ((!(hm.get("gstin") != null && hm.get("fin_year")!= null) ||(!(hm.get("gstin").isEmpty() && hm.get("fin_year").isEmpty())))) {
				try {
					Class.forName("com.simba.athena.jdbc.Driver");
					Properties info = new Properties();

					// Replace with a s3 bucket in your account
					info.put("s3_staging_dir", "s3://aws-athena-query-results-498443935277-ap-south-1/output/");

					info.put("user", "AKIAIUJJAMQW2TMZFGYQ");
					info.put("password", "mlh6JhX/zLlAlibvloc97cQliqnfJcF6VvGyfvnd");

					System.out.println("Connecting to Athena...");
					conn = DriverManager.getConnection(athenaUrl, info);
					String sql = "";

					if (hm.get("return_type").equalsIgnoreCase("gstr-1")) {
						sql = "ALTER TABLE gstr9flatjsondb.gstr9flatjson ADD PARTITION" + " (gstin='" + hm.get("gstin") + "',fin_year='"
								+ hm.get("fin_year") + "') location 's3://gstr9-processed-data/return_type=GSTR-1/'";
					} else if (hm.get("return_type").equalsIgnoreCase("gstr-2a"))
						sql = "ALTER TABLE gstr9flatjsondb.gstr9flatjson ADD PARTITION" + " (gstin='" + hm.get("gstin") + "',fin_year='"
								+ hm.get("fin_year") + "') location 's3://gstr9-processed-data/return_type=GSTR-2A/'";
					else if (hm.get("return_type").equalsIgnoreCase("gstr-3b"))
						sql = "ALTER TABLE gstr9flatjsondb.gstr9flatjson3b ADD PARTITION" + " (gstin='" + hm.get("gstin")
								+ "',fin_year='" + hm.get("fin_year")
								+ "') location 's3://gstr9-processed-data/return_type=GSTR-3B/'";

					System.out.println("Query: " + sql);
					statement = conn.createStatement();
					if (statement.execute(sql)) {
						System.out.println("Query executed successfully");
					} else {
						System.out.println(
								"Not done with query there is some problem please fix first then execute the query ...");
					}
					// ResultSet rs = statement.executeQuery(sql);
					// rs.next();
					// System.out.println(rs);
					// rs.close();
					conn.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				} finally {
					try {
						if (statement != null)
							statement.close();
					} catch (Exception ex) {

					}
					try {
						if (conn != null)
							conn.close();
					} catch (Exception ex) {

						ex.printStackTrace();
					}
				}
			}
			return contentType;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}
}